# Docker Swarm 入门

## 1. 先用一句话理解它

Docker Swarm 是 Docker 自带的集群编排能力。它能把多台装了 Docker 的机器组织成一个集群，然后统一部署和调度服务。

你可以把它理解成：

- Docker 负责“单机运行容器”
- Swarm 负责“多机管理和调度容器”

## 2. 最核心的几个名词

| 名词 | 含义 | 你可以把它想成什么 |
| --- | --- | --- |
| Node | 集群中的一台机器 | 一台服务器 |
| Manager | 负责管理集群的节点 | 调度和指挥中心 |
| Worker | 负责真正运行任务的节点 | 干活的机器 |
| Service | 你希望集群持续运行的一类服务 | “我要跑一个后端/任务容器” |
| Task | Service 的一个实际执行实例 | 真正被调度出去的一次运行 |
| Replica | Service 想要运行几个副本 | 想跑几个实例 |
| Stack | 一组相关服务的打包部署方式 | 一整套系统 |
| Overlay Network | 跨主机容器网络 | 集群内部网络 |
| Drain | 节点不再接收新任务的状态 | 维护模式 |

最容易搞混的是 `service` 和 `task`：

- `service` 是“期望状态”
- `task` 是“实际被调度出来的执行实例”

如果一个 service 配了 `3 replicas`，通常就会有 `3 个 task`。

## 3. Swarm 中的角色关系

```mermaid
flowchart TD
  Manager[Manager 节点] --> Worker1[Worker 节点 A]
  Manager --> Worker2[Worker 节点 B]
  Manager --> Worker3[Worker 节点 C]
  Service[Service] --> Task1[Task 1]
  Service --> Task2[Task 2]
  Service --> Task3[Task 3]
  Task1 --> Worker1
  Task2 --> Worker2
  Task3 --> Worker3
```

## 4. 最常见的基本命令

### 初始化集群

```bash
docker swarm init --advertise-addr <MANAGER_IP>
```

### 查看加入 token

```bash
docker swarm join-token worker
docker swarm join-token manager
```

### 新节点加入集群

```bash
docker swarm join --token <TOKEN> <MANAGER_IP>:2377
```

### 查看节点

```bash
docker node ls
```

### 创建服务

```bash
docker service create --name demo-nginx --replicas 2 -p 8080:80 nginx:stable
```

### 查看服务

```bash
docker service ls
docker service ps demo-nginx
```

### 删除服务

```bash
docker service rm demo-nginx
```

### 把节点切成维护模式

```bash
docker node update --availability drain worker-1
```

## 5. 如何接入一个新节点

接入新节点通常按这个顺序：

1. 在新机器上安装 Docker。
2. 确保它和 Manager 网络互通。
3. 确保 Swarm 所需端口开放。
4. 在 Manager 上获取 join token。
5. 在新机器上执行 `docker swarm join ...`。
6. 回到 Manager 上用 `docker node ls` 确认加入成功。

Swarm 常见端口：

- `2377/tcp`：集群管理
- `7946/tcp` 和 `7946/udp`：节点通信
- `4789/udp`：overlay 网络

如果节点加不进来，优先查：

- 防火墙
- 云服务器安全组
- Docker 版本差异
- Manager IP 是否写错

## 6. 如何删除一个节点

### 情况 1：节点还活着，想优雅删除

正确做法：

1. 先把节点设置成 `drain`
2. 等任务迁移走
3. 在该节点执行 `docker swarm leave`
4. 在 Manager 执行 `docker node rm <node>`

命令示例：

```bash
docker node update --availability drain worker-1
docker node ls
docker service ps <service-name>
```

然后在 `worker-1` 上：

```bash
docker swarm leave
```

最后在 Manager 上：

```bash
docker node rm worker-1
```

### 情况 2：节点已经坏了或者失联了

这时只能在 Manager 上强制删除：

```bash
docker node rm --force worker-1
```

但要注意，`--force` 只是把这个节点从集群元数据里删掉，不代表它原本运行中的任务能被“平滑保存”。

## 7. 如果删除节点时，它正在运行 task，会发生什么

这是最关键的问题之一。

### 情况 A：先 `drain`，再删除

这是最安全的方式。

会发生的事情通常是：

1. 节点不再接收新 task
2. Swarm 尝试把这个节点上的 service task 迁移或重建到别的可用节点
3. 如果其他节点满足资源和约束条件，新的 task 会在别处启动
4. 原节点上的 task 会被停止

注意，这不是“热迁移虚拟机”那种平滑搬家。更准确地说，是“在别处重新启动一个新的 task”。

### 情况 B：节点突然掉线或被粗暴删除

会发生的事情通常是：

1. 原 task 会中断
2. 这个 task 的进程状态不会被自动保留
3. Swarm 发现副本缺失后，会尝试在别的节点补一个新的 task
4. 如果没有合适节点，新 task 会一直 `pending`

特别要注意：

- 容器内没持久化的数据，可能直接丢
- 写在本机磁盘里的临时文件，通常不会自动带走
- 正在执行中的一次性计算任务，可能直接失败

所以不要把 Swarm 想成“任务永不丢失系统”。它更像“期望副本数恢复系统”。

## 8. 用图看懂“drain 后再删节点”

```mermaid
sequenceDiagram
  participant Admin as 运维/开发
  participant Manager as Swarm Manager
  participant OldNode as 旧 Worker
  participant NewNode as 新 Worker

  Admin->>Manager: 将旧节点设置为 drain
  Manager->>OldNode: 不再分配新 task
  Manager->>NewNode: 重新创建缺失的 task
  NewNode-->>Manager: 新 task 启动成功
  Manager->>OldNode: 停止旧 task
  Admin->>OldNode: docker swarm leave
  Admin->>Manager: docker node rm old-node
```

## 9. 你们最该知道的 5 个现实限制

1. Swarm 管的是服务副本，不是替你保存进程内存状态。
2. 任务能否迁移，取决于别的节点是否满足 CPU、内存、标签、镜像等约束。
3. 如果你把数据写死在本机磁盘，节点一挂，数据大概率跟着挂。
4. `drain` 和 `remove` 不是一回事。`drain` 是先停止接单，`remove` 是把节点移出集群。
5. 真正重要的状态，必须落数据库、对象存储、共享卷，不能只放容器里。

## 10. 适合给团队记住的最小结论

请把下面几句记住：

- `service` 是期望，`task` 是实际执行。
- 加新节点：`join`
- 暂停接任务：`drain`
- 删除节点：`leave + node rm`
- 节点删除时如果正在跑 task，Swarm 会尝试在别处重建，但不会神奇保留内存状态和本地临时文件。

