# 测试为什么重要，以及如何用 Playwright 联调

## 1. 先纠正一个名字

很多人会写成 `Playweight`，正确名字是 `Playwright`。

## 2. 为什么测试在 AI 时代更重要

以前人写代码，改得慢，错得也慢。

现在让 AI 改代码，速度会非常快，但问题也会一起被快速放大。

没有测试时，最常见的结果是：

- 页面能打开，但接口参数偷偷变了
- 一个按钮能点，但状态流转错了
- A 页面修好了，B 页面被顺手改坏
- 登录、权限、重启、删除这类关键流程经常回归

所以测试的价值不是“追求完美”，而是：

- 给 AI 上刹车
- 给团队留底线
- 让你敢重构

## 3. 测试分哪几层

一个正常项目，至少要知道这 3 层：

| 层 | 测什么 | 速度 | 适合发现什么问题 |
| --- | --- | --- | --- |
| 单元测试 | 一个函数、一个类、一个小模块 | 最快 | 业务规则、边界条件 |
| 集成测试 | 多个模块一起工作 | 中等 | 接口、数据库、服务协作 |
| 端到端测试 | 从浏览器点击到后端返回 | 最慢 | 前后端联调、真实用户流程 |

Playwright 主要是做端到端测试，也常用来做前后端联调测试。

## 4. 为什么 Playwright 适合做联调

它的优势很实际：

- 真浏览器执行，不是纯模拟
- 支持 Chromium / Firefox / WebKit
- 能测登录、表单、列表、弹窗、下载、上传
- 能直接等待页面状态，不用写很多脆弱脚本
- 自带截图、录像、trace，失败后好排查

## 5. 前后端联调时，哪些流程必须测

不要妄想第一天就测全站。

先测最关键的主流程：

1. 登录
2. 列表查询
3. 表单提交
4. 创建任务 / 创建订单
5. 查看状态变化
6. 重启 / 停止 / 删除
7. 权限校验

你们这种会频繁让 AI 改代码的团队，至少要把这几条守住。

## 6. 联调测试的基本原则

### 原则 1：核心流程不要 mock 后端

如果你想测“前后端联调”，就不要把关键接口都 mock 掉。

可以 mock 的一般是：

- 短信
- 邮件
- 第三方支付
- 外部地图服务

不该 mock 的一般是：

- 登录
- 核心业务接口
- 状态流转接口
- 任务创建 / 重启 / 删除接口

### 原则 2：给页面加稳定选择器

推荐加：

```html
<button data-testid="restart-task-button">重启</button>
```

不要高度依赖：

- 纯中文文本
- 很长的 CSS 路径
- 动不动就变的 class 名

### 原则 3：不要写固定睡眠

不要动不动：

```ts
await page.waitForTimeout(5000)
```

这种测试极其脆弱。

优先写：

```ts
await expect(page.getByTestId('task-status')).toHaveText('RUNNING')
```

## 7. 最小接入步骤

如果项目里还没有 Playwright，可以按这个最小流程来。

### 安装

```bash
npm install -D @playwright/test
npx playwright install
```

### 初始化目录

推荐结构：

```text
tests/
  e2e/
    auth.spec.ts
    task.spec.ts
playwright.config.ts
```

## 8. 一个最小可用的 `playwright.config.ts`

下面这个配置适合大多数前端项目起步时参考：

```ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  timeout: 30_000,
  expect: {
    timeout: 5_000,
  },
  use: {
    baseURL: 'http://127.0.0.1:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  webServer: {
    command: 'npm run dev',
    url: 'http://127.0.0.1:3000',
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
```

如果你的项目不是 `3000` 端口，或者启动命令不是 `npm run dev`，改成自己的实际值即可。

## 9. 一个前后端联调测试示例

下面是一个“登录后创建任务并查看状态”的示例：

```ts
import { test, expect } from '@playwright/test';

test('user can create task and see running status', async ({ page }) => {
  await page.goto('/login');

  await page.getByLabel('用户名').fill('demo_user');
  await page.getByLabel('密码').fill('demo_password');
  await page.getByTestId('login-submit').click();

  await expect(page).toHaveURL(/dashboard/);

  await page.goto('/tasks/new');
  await page.getByTestId('task-name-input').fill('demo-task');
  await page.getByTestId('task-image-select').click();
  await page.getByRole('option', { name: 'python-basic' }).click();
  await page.getByTestId('task-submit').click();

  await expect(page.getByTestId('task-status')).toHaveText(/CREATED|RUNNING/);
});
```

这个例子里测到的是完整链路：

- 前端表单
- 请求发送
- 后端创建任务
- 页面状态展示

## 10. 更稳的做法：用 API 预置数据

很多联调测试失败，不是页面真有问题，而是环境数据太脏。

推荐用 Playwright 自带的 `request` 能力，先准备测试数据，再开页面：

```ts
import { test, expect } from '@playwright/test';

test('task list shows seeded task', async ({ page, request }) => {
  await request.post('http://127.0.0.1:8000/test/login-as-admin');
  await request.post('http://127.0.0.1:8000/test/tasks/seed', {
    data: {
      name: 'seed-task',
      status: 'RUNNING',
    },
  });

  await page.goto('/tasks');
  await expect(page.getByText('seed-task')).toBeVisible();
});
```

注意：

- 这种 `/test/*` 接口只应该出现在测试环境
- 生产环境不能暴露

## 11. 建议优先补的 6 条测试

如果时间有限，优先补这几条：

1. 登录成功 / 失败
2. 任务列表加载成功 / 失败
3. 创建任务成功
4. 重启任务成功
5. 删除任务成功
6. 无权限用户看不到危险操作按钮

## 12. AI 改代码时，测试应该怎么配合

推荐工作流：

1. 先明确这次改动影响哪个流程
2. 先补或先改对应测试
3. 再让 AI 改业务代码
4. 最后跑测试看有没有回归

尤其是前端改动时，最稳的顺序是：

1. 先补网络层和状态层测试
2. 再补 Playwright 联调测试
3. 最后才接 UI

这和前面文档里的原则完全一致。

## 13. 常见错误

1. 所有接口都 mock，结果测不出联调问题。
2. 只会写 `waitForTimeout`，结果测试非常不稳定。
3. 不加 `data-testid`，定位元素全靠中文文案。
4. 没有固定测试数据，每次跑结果都不一样。
5. 只在本机手点，不进 CI。

## 14. 一句话结论

测试不是“做完后再补”的可选项。

对于会频繁使用 AI 改代码的团队，Playwright 这类自动化联调测试，就是防止系统被悄悄改坏的底线。

