# 01 卖家接入 ComputeNode

版本：V4.0  
日期：2026-03-17

## 1. 文档目标

本文件把“卖家接入 `ComputeNode`”这条流程展开成真实操作脚本。

本版采用最简接入逻辑：

- 卖家不再在网页中填写 `ComputeNode` 登记表单
- 卖家不再在网页中编写上架描述
- 卖家不再手工点击“发布上架”
- 卖家在本地执行一条 bootstrap 命令，就等效于“接入并上架这个节点”
- 网页只负责生成命令、轮询状态、显示自动出现的新节点
- `NodeRentalListing` 的标题、配置摘要、默认描述由后端自动拉取和自动生成

涉及 Docker Swarm 的地方，本文件只抽象到 `Swarm Adapter`。

## 2. 本流程涉及的前后端对象

### 2.1 前端页面

- `SellerWorkbenchPage`
- `ComputeNodeAccessGuidePage`
- `ComputeNodeBootstrapPage`
- `ListingManagePage`

### 2.2 后端模块

- `Auth & Access`
- `ComputeNode Access`
- `Swarm Adapter`
- `PricingEngine`
- `NodeRentalListing Market`

### 2.3 本流程使用的 HTTP 接口

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /seller/compute-nodes` | `ComputeNode Access` | 查询卖家已有节点 |
| `GET /seller/listings` | `NodeRentalListing Market` | 查询卖家已有上架记录 |
| `GET /seller/compute-nodes/access-guide` | `ComputeNode Access` | 获取接入说明 |
| `POST /seller/compute-nodes/bootstrap-sessions` | `ComputeNode Access` | 创建接入会话并返回本地执行命令 |
| `GET /seller/compute-nodes/bootstrap-sessions/{session_id}` | `ComputeNode Access` | 轮询当前接入状态 |
| `POST /seller/compute-nodes/register-self` | `ComputeNode Access` | 由本地 bootstrap 脚本自注册 |
| `GET /seller/compute-nodes/{node_id}` | `ComputeNode Access` | 查询节点详情 |
| `GET /seller/listings/{listing_id}` | `NodeRentalListing Market` | 查询自动生成的上架详情 |
| `POST /seller/listings/{listing_id}/off-shelf` | `NodeRentalListing Market` | 下架自动上架的记录 |
| `POST /seller/listings/{listing_id}/publish` | `NodeRentalListing Market` | 重新上架已下架记录 |
| `POST /seller/compute-nodes/{node_id}/sync` | `ComputeNode Access` | 手动重试同步节点状态 |

## 3. 接入逻辑总览

```mermaid
sequenceDiagram
    actor Seller as Seller
    participant Workbench as SellerWorkbenchPage
    participant Guide as ComputeNodeAccessGuidePage
    participant Bootstrap as ComputeNodeBootstrapPage
    participant NodeAPI as ComputeNode Access
    participant Swarm as Swarm Adapter
    participant Local as Seller Local Bootstrap Script
    participant Pricing as PricingEngine
    participant Market as NodeRentalListing Market
    participant Listing as ListingManagePage

    Seller->>Workbench: 打开卖家工作台
    Seller->>Guide: 查看接入说明
    Seller->>Bootstrap: 点击开始接入
    Bootstrap->>NodeAPI: 创建 bootstrap session
    NodeAPI->>Swarm: 获取 join 信息
    Swarm-->>NodeAPI: 返回 worker join data
    NodeAPI-->>Bootstrap: 返回 bootstrap_command
    Seller->>Local: 在本地执行 bootstrap_command
    Local->>Swarm: 执行 docker swarm join
    Local->>NodeAPI: POST /seller/compute-nodes/register-self
    NodeAPI->>Swarm: 校验 swarm_node_id 已加入
    NodeAPI->>Swarm: 写入 seller 归属标签
    NodeAPI->>Pricing: 生成平台价格
    NodeAPI->>Market: 自动生成并自动上架 listing
    Bootstrap->>NodeAPI: 轮询 bootstrap status
    NodeAPI-->>Bootstrap: 返回 verified + listed
    Bootstrap-->>Seller: 自动返回工作台
    Seller->>Listing: 如需管理再打开详情页
    Listing->>Market: 查询 listing 状态
    Market-->>Listing: 返回 listed + rentable
```

## 4. 主成功流程

### 4.1 第 0 步：卖家进入工作台

**用户操作**

卖家登录后，进入 `SellerWorkbenchPage`。

**前端页面**

`SellerWorkbenchPage`

**后端模块与接口**

- `ComputeNode Access`
  - `GET /seller/compute-nodes`
- `NodeRentalListing Market`
  - `GET /seller/listings`

**请求示例**

```text
GET /seller/compute-nodes?limit=20&offset=0
GET /seller/listings?limit=20&offset=0
```

**响应示例**

```json
{
  "items": [],
  "total": 0
}
```

```json
{
  "items": [],
  "total": 0
}
```

**实现效果**

- 页面显示当前还没有节点
- 页面显示“接入新节点”

**下一步**

卖家点击“接入新节点”，进入 `ComputeNodeAccessGuidePage`。

### 4.2 第 1 步：卖家查看接入说明

**用户操作**

卖家查看说明，理解一件事：本地执行命令后，平台会自动接入并自动上架。

**前端页面**

`ComputeNodeAccessGuidePage`

**后端模块与接口**

- `ComputeNode Access`
  - `GET /seller/compute-nodes/access-guide`

**请求示例**

```text
GET /seller/compute-nodes/access-guide
```

**响应示例**

```json
{
  "steps": [
    "确认本机已安装 Docker Engine",
    "在平台生成一次性 bootstrap 命令",
    "在本地终端执行 bootstrap 命令",
    "等待网页自动发现并自动上架节点"
  ],
  "requirements": {
    "docker_required": true,
    "internet_access_required": true
  },
  "security_notice": "本流程不会向卖家暴露 manager token，只会下发短时有效的 worker bootstrap 信息"
}
```

**实现效果**

- 页面展示接入说明
- 页面明确写出“无需手工登记，无需手工发布”
- 页面显示“开始接入”按钮

**下一步**

卖家点击“开始接入”，进入 `ComputeNodeBootstrapPage`。

### 4.3 第 2 步：网页生成 bootstrap 命令

**用户操作**

卖家点击“生成接入命令”。

**前端页面**

`ComputeNodeBootstrapPage`

**后端模块与接口**

- `ComputeNode Access`
  - `POST /seller/compute-nodes/bootstrap-sessions`
- `Swarm Adapter`
  - 由 `ComputeNode Access` 内部调用：
    - `get_join_token()`
    - `build_worker_join_command()`

**请求示例**

```json
{
  "client_context": {
    "source": "seller_web",
    "locale": "zh-CN"
  }
}
```

**响应示例**

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "registration_token": "reg_6f14ca0b",
  "status": "waiting_local_execution",
  "expires_at": "2026-03-17T23:20:00Z",
  "polling_interval_seconds": 5,
  "bootstrap_command": "curl -fsSL https://platform.example.com/bootstrap-node.sh | bash -s -- --bootstrap-session-id bss_20260317_0001 --registration-token reg_6f14ca0b --manager-addr swarm-manager.platform.local:2377 --worker-join-token SWMTKN-1-xxxxxx"
}
```

**实现效果**

- 页面显示一条可复制的一键命令
- 页面显示当前接入状态：`waiting_local_execution`
- 页面开始轮询 bootstrap session 状态

**下一步**

卖家在本地 Docker 主机终端执行这条命令。

### 4.4 第 3 步：卖家在本地执行 bootstrap 命令

**用户操作**

卖家在本地终端执行网页给出的命令。

**前端页面**

`ComputeNodeBootstrapPage`

**本地脚本做的事情**

本地 bootstrap 脚本自动完成：

1. 执行 `docker swarm join`
2. 读取本机 `swarm_node_id`
3. 读取主机名和硬件信息
4. 调用平台注册接口 `/seller/compute-nodes/register-self`

**本地脚本向后端发送的请求**

- `ComputeNode Access`
  - `POST /seller/compute-nodes/register-self`

**请求示例**

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "registration_token": "reg_6f14ca0b",
  "swarm_node_id": "2k2x5j7l8abcde1234567890f",
  "swarm_hostname": "seller-gpu-01",
  "hardware_profile": {
    "cpu_model": "AMD Ryzen 9 7950X",
    "cpu_cores": 16,
    "memory_mb": 65536,
    "gpu_vendor": "NVIDIA",
    "gpu_model": "RTX 4090",
    "gpu_count": 1,
    "gpu_memory_mb": 24576,
    "bandwidth_mbps": 300
  }
}
```

**后端内部处理**

这一步后端应按下面顺序执行：

1. `ComputeNode Access.validate_registration_token()`
2. `Swarm Adapter.inspect_swarm_node_by_id(swarm_node_id)`
   - **潜在问题**：Swarm节点加入是异步过程，从执行`docker swarm join`到节点完全可用存在1-5秒延迟
   - **解决方案**：实现重试机制，最多重试5次，间隔1/2/3/5/8秒（指数退避），超时后返回明确错误提示
3. `Swarm Adapter.get_node_hardware_info(swarm_node_id)` - **【硬件验证】**从Swarm API独立查询真实硬件信息，与本地上报对比验证(Bug-01-02)
4. `ComputeNode Access.map_swarm_node_to_compute_node()`
5. `Swarm Adapter.claim_swarm_node_labels()`
6. `PricingEngine.price_compute_node()`
7. `NodeRentalListing Market.auto_build_listing_metadata()`
8. `NodeRentalListing Market.create_and_publish_listing_from_compute_node()`

**响应示例**

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "status": "verified",
  "compute_node": {
    "id": 101,
    "swarm_node_id": "2k2x5j7l8abcde1234567890f",
    "runtime_status": "online"
  },
  "listing": {
    "id": 201,
    "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
    "summary": "auto-generated from hardware profile",
    "publish_status": "listed",
    "rentable_status": "rentable",
    "current_price_hourly": 18.6,
    "price_currency": "CNY"
  }
}
```

**实现效果**

- 卖家本地执行一次命令后，平台自动完成节点认领
- 无需卖家再手工填写节点登记表单
- 平台自动生成并自动上架一条 `NodeRentalListing`
- 标题、配置摘要、默认描述由后端自动生成

**下一步**

前端继续轮询 bootstrap session 状态。

### 4.5 第 4 步：网页轮询接入状态并自动回到工作台

**用户操作**

卖家回到网页，无需额外点击提交，只等待状态更新。

**前端页面**

`ComputeNodeBootstrapPage`

**后端模块与接口**

- `ComputeNode Access`
  - `GET /seller/compute-nodes/bootstrap-sessions/{session_id}`

**请求示例**

```text
GET /seller/compute-nodes/bootstrap-sessions/bss_20260317_0001
```

**响应示例**

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "status": "verified",
  "compute_node_id": 101,
  "listing_id": 201,
  "detected_at": "2026-03-17T22:31:40Z",
  "market_visibility": "visible",
  "message": "compute node claimed and listing auto-published successfully"
}
```

**实现效果**

- 页面从 `waiting_local_execution` 切换到 `verified`
- 页面显示“已发现并自动上架新节点”
- 页面自动跳回 `SellerWorkbenchPage`

**下一步**

卖家在工作台中直接看到新节点和新上架记录。

### 4.6 第 5 步：卖家在工作台和管理页中查看自动生成的结果

**用户操作**

卖家返回工作台后，看到新节点；如果要管理，再打开 `ListingManagePage`。

**前端页面**

- `SellerWorkbenchPage`
- `ListingManagePage`

**后端模块与接口**

- `ComputeNode Access`
  - `GET /seller/compute-nodes`
  - `GET /seller/compute-nodes/{node_id}`
- `NodeRentalListing Market`
  - `GET /seller/listings`
  - `GET /seller/listings/{listing_id}`

**请求示例**

```text
GET /seller/compute-nodes?limit=20&offset=0
GET /seller/listings?limit=20&offset=0
GET /seller/compute-nodes/101
GET /seller/listings/201
```

**响应示例：工作台中的 listing**

```json
{
  "items": [
    {
      "id": 201,
      "compute_node_id": 101,
      "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
      "summary": "auto-generated from hardware profile",
      "publish_status": "listed",
      "rentable_status": "rentable",
      "current_price_hourly": 18.6,
      "price_currency": "CNY"
    }
  ],
  "total": 1
}
```

**响应示例：管理页详情**

```json
{
  "id": 201,
  "compute_node_id": 101,
  "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
  "summary": "auto-generated from hardware profile",
  "description": "generated by backend from hostname, hardware profile and default market template",
  "image_policy": "template",
  "publish_status": "listed",
  "rentable_status": "rentable",
  "current_price_hourly": 18.6,
  "price_currency": "CNY",
  "price_source": "pricing_engine"
}
```

**实现效果**

- 卖家不写任何描述，也能直接看到已上架记录
- 展示信息由后端自动拉取和自动生成
- 卖家此时只需要管理，不需要补录

**下一步**

流程结束，进入卖家日常管理或买家浏览市场流程。

## 5. 关键异常分支

### 5.1 异常分支 A：bootstrap session 创建失败

**触发点**

卖家点击“生成接入命令”时失败。

**前端页面**

`ComputeNodeBootstrapPage`

**接口**

- `POST /seller/compute-nodes/bootstrap-sessions`

**响应示例**

```json
{
  "error_code": "bootstrap_session_create_failed",
  "message": "failed to create bootstrap session"
}
```

**前端效果**

- 页面显示局部错误卡片
- 允许重试创建命令

### 5.2 异常分支 B：卖家本地执行了命令，但平台注册时找不到 swarm worker

**触发点**

本地脚本调用 `/register-self` 后，平台未能通过 `Swarm Adapter` 校验到该 `swarm_node_id`。

**接口**

- `POST /seller/compute-nodes/register-self`

**响应示例**

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "status": "failed",
  "error_code": "worker_not_found",
  "message": "swarm worker not found by swarm_node_id"
}
```

**前端效果**

前端轮询 `GET /seller/compute-nodes/bootstrap-sessions/{session_id}` 时看到：

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "status": "failed",
  "error_code": "worker_not_found",
  "message": "local join command finished but platform could not verify this worker"
}
```

- 页面显示“接入失败”
- 提供“重新生成命令”

### 5.3 异常分支 C：节点已认领，但定价暂不可用

**触发点**

本地注册成功，但 `PricingEngine` 无法立即返回价格。

**接口**

- `POST /seller/compute-nodes/register-self`

**响应示例**

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "status": "verified",
  "compute_node": {
    "id": 101,
    "runtime_status": "online"
  },
  "listing": {
    "id": 201,
    "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
    "publish_status": "pending",
    "rentable_status": "unavailable",
    "current_price_hourly": 0.0,
    "price_currency": "CNY",
    "price_source": "pending"
  },
  "warning_code": "pricing_pending"
}
```

**前端效果**

- 节点接入成功
- 工作台里能看到新节点
- 上架记录显示“价格生成中”
- 卖家不需要手工补描述，也不能手工发布

### 5.4 异常分支 D：节点已自动上架，但后续离线

**触发点**

节点成功接入并上架后，后续离线。

**接口**

- `GET /seller/compute-nodes`
- `GET /seller/listings`
- `POST /seller/compute-nodes/{node_id}/sync`

**前端效果**

- 工作台中该节点显示 `offline`
- listing 进入 `unavailable`
- 卖家可以在管理页执行重新同步，而不是重新接入

## 6. 本文档结论

1. 卖家接入不应是“本地 join 一次，再网页手工登记一次”的双重录入流程。
2. 卖家在本地执行 bootstrap 命令，应等效为“我要把这个节点接入并上架”。
3. 平台应在 `register-self` 成功后自动生成 `ComputeNode`、自动生成元数据、自动创建并自动上架 `NodeRentalListing`。
4. 卖家不需要在 onboarding 阶段编写标题、描述或手工点击发布。
5. 卖家在网页侧看到的应该是“自动出现的新节点和可管理的上架记录”，而不是待补录的草稿表单。
