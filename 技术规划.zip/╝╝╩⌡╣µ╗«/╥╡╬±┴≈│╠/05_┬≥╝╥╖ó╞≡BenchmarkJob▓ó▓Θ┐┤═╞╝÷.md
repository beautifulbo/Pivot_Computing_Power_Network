# 05 买家发起 BenchmarkJob 并查看推荐

版本：V2.1
日期：2026-03-18

## 1. 文档目标

本文档只描述买家使用 AI 测算入口时的完整链路：

1. 买家打开 `BenchmarkSubmitPage`。
2. 买家选择两种输入方式之一：
   - 上传完整代码压缩包
   - 提供 `git clone` 链接
3. 平台创建 `BenchmarkJob`。
4. `Benchmark Worker` 中的 `Claude Code Runner` 尝试准备代码、运行、压测并输出结果。
5. 买家在 `BenchmarkResultPage` 查看结果和推荐的 `NodeRentalListing`。

这条流程与直租流程完全独立，不自动下单，不锁定任何节点。

## 2. 本流程涉及的前后端对象

### 2.1 前端页面

- `BenchmarkSubmitPage`
- `BenchmarkResultPage`
- `ListingDetailPage`

### 2.2 后端模块

- `Auth & Access`
- `BenchmarkJob`
- `Swarm Adapter`
- `AI Benchmark Worker`
- `NodeRentalListing Market`

### 2.3 本流程使用的 HTTP 接口

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `POST /benchmark-jobs/code-archive-uploads` | `BenchmarkJob` | 上传完整代码压缩包并返回 `code_archive_token` |
| `POST /benchmark-jobs` | `BenchmarkJob` | 创建测算任务 |
| `GET /benchmark-jobs/{job_id}` | `BenchmarkJob` | 获取任务状态与阶段 |
| `GET /benchmark-jobs/{job_id}/recommendations` | `BenchmarkJob` | 获取推荐结果 |

## 3. Benchmark 流程总览

```mermaid
sequenceDiagram
    actor Buyer as Buyer
    participant Submit as BenchmarkSubmitPage
    participant Result as BenchmarkResultPage
    participant Benchmark as BenchmarkJob Module
    participant Swarm as Swarm Adapter
    participant Worker as Benchmark Worker
    participant Claude as Claude Code Runner
    participant Market as NodeRentalListing Market
    participant Detail as ListingDetailPage

    Buyer->>Submit: 选择输入方式

    alt 上传完整代码压缩包
        Buyer->>Submit: 选择 zip 文件并上传
        Submit->>Benchmark: POST /benchmark-jobs/code-archive-uploads
        Benchmark-->>Submit: 返回 code_archive_token
    else 提供 git clone 链接
        Buyer->>Submit: 填写 git_clone_url 和 git_ref
    end

    Buyer->>Submit: 提交 BenchmarkJob
    Submit->>Benchmark: POST /benchmark-jobs
    Benchmark->>Benchmark: 创建 BenchmarkJob + input manifest
    Benchmark->>Swarm: create_benchmark_service(payload)
    Swarm->>Worker: 调度 benchmark service
    Worker->>Claude: 解压代码或执行 git clone
    Claude->>Claude: 分析项目、尝试运行、轻量压测
    Claude-->>Benchmark: 输出 benchmark_result.json
    Benchmark->>Market: 匹配推荐 listings
    Benchmark-->>Submit: 返回 job_id
    Submit-->>Buyer: 跳转结果页

    Result->>Benchmark: GET /benchmark-jobs/{job_id}
    Benchmark-->>Result: 返回 job_status / current_stage

    alt 测算成功
        Result->>Benchmark: GET /benchmark-jobs/{job_id}/recommendations
        Benchmark-->>Result: 返回推荐结果
        Buyer->>Detail: 点击推荐 listing
    else 测算失败或超时
        Benchmark-->>Result: 返回 failure_reason
    else 仍在运行
        Benchmark-->>Result: 返回 queued / running / analyzing
    end
```

## 4. 主成功流程

### 4.1 第 0 步：买家进入测算提交页

**用户操作**

买家从门户页点击“AI 测算推荐”。

**前端页面**

`BenchmarkSubmitPage`

**页面初始能力**

- 允许买家在 `code_archive` 和 `git_repository` 两种输入方式之间切换。
- 允许填写 `entry_hint`、`expected_project_type`、`notes`。
- 当前阶段不要求买家提供 SSH 凭证。

**下一步**

买家选择一种输入方式。

### 4.2 第 1 步：买家选择输入方式

**用户操作**

买家二选一：

- 方式 A：上传完整代码压缩包
- 方式 B：填写 `git clone` 链接

**前端页面**

`BenchmarkSubmitPage`

**前端本地校验**

- 不能同时选择两种输入方式。
- `code_archive` 模式下必须选择 `.zip` 文件。
- `git_repository` 模式下必须填写合法的 `http/https` 仓库地址。
- `git_ref` 可选。

**实现效果**

- 页面只保留一种有效输入源。
- 无 SSH 模式下，前端明确告知：如果选择 git 仓库，平台会在隔离的 benchmark 容器里执行 `git clone`。

### 4.3 第 2A 步：买家上传完整代码压缩包

**用户操作**

买家在 `code_archive` 模式下选择本地 zip 文件并点击上传。

**前端页面**

`BenchmarkSubmitPage`

**后端模块与接口**

- `BenchmarkJob`
  - `POST /benchmark-jobs/code-archive-uploads`

**安全检查**(Bug-05-01)

上传的zip文件需经过以下安全检查：
- 最大文件大小：50MB
- 解压后最大大小：500MB
- 最大文件数量：10,000个
- 最大目录深度：10层
- 压缩比检查：防止压缩炸弹攻击
- 文件名安全检查：防止路径穿越

**请求示例**

这一步不是 JSON，而是 `multipart/form-data`：

```text
POST /benchmark-jobs/code-archive-uploads
Content-Type: multipart/form-data

file = demo-app.zip
```

**响应 JSON 示例**

```json
{
  "code_archive_token": "upload_abc_001",
  "filename": "demo-app.zip",
  "size_bytes": 1843200,
  "expires_at": "2026-03-18T10:30:00Z"
}
```

**实现效果**

- 前端拿到一个 `code_archive_token`。
- 页面可以继续创建 `BenchmarkJob`。

**下一步**

买家点击“开始测算”。

### 4.4 第 2B 步：买家填写 git clone 链接

**用户操作**

买家在 `git_repository` 模式下填写：

- `git_clone_url`
- 可选 `git_ref`
- 可选 `entry_hint`

**前端页面**

`BenchmarkSubmitPage`

**前端本地校验**

- `git_clone_url` 必须是 `http` 或 `https` 地址。
- 当前阶段默认只支持平台测算容器可直接访问的仓库地址。

**实现效果**

- 页面不需要先上传文件。
- 页面可以直接进入创建 `BenchmarkJob` 的步骤。

### 4.5 第 3 步：前端提交创建 BenchmarkJob 请求

**用户操作**

买家点击“开始测算”。

**前端页面**

`BenchmarkSubmitPage`

**后端模块与接口**

- `BenchmarkJob`
  - `POST /benchmark-jobs`

**请求 JSON 示例 A：压缩包来源**

```json
{
  "source_type": "code_archive",
  "code_archive_token": "upload_abc_001",
  "git_clone_url": null,
  "git_ref": null,
  "entry_hint": "backend/app.py",
  "expected_project_type": "web_service",
  "notes": "prefer conservative estimate"
}
```

**请求 JSON 示例 B：git 仓库来源**

```json
{
  "source_type": "git_repository",
  "code_archive_token": null,
  "git_clone_url": "https://github.com/example/demo-app.git",
  "git_ref": "main",
  "entry_hint": "server/index.js",
  "expected_project_type": "web_service",
  "notes": "benchmark from public repository"
}
```

**后端内部处理顺序**

`BenchmarkJob` 模块收到请求后，按以下顺序处理：

1. 调用 `Auth & Access` 确认当前买家身份。
2. 校验 `source_type` 是否合法，且只提供了一种输入源。
3. 如果是 `code_archive`，校验 `code_archive_token` 是否存在且未过期。
4. 如果是 `git_repository`，校验 `git_clone_url` 格式，记录可选 `git_ref`。
5. 创建 `BenchmarkJob` 记录。
6. 生成统一的 `benchmark input manifest`。
7. 调用 `Swarm Adapter.create_benchmark_service(payload)` 调度 benchmark 容器。
8. **【容器安全配置】**(Bug-05-05)：容器使用严格的资源限制和安全隔离：
   - CPU限制2核、内存限制4GB、进程数限制1024
   - 网络完全隔离(network_mode=none)
   - 根文件系统只读、禁用特权模式
   - 使用seccomp和AppArmor安全配置
9. benchmark 容器启动后：
   - 若来源为压缩包，则先解压代码(已通过安全检查Bug-05-01)；
   - 若来源为 git 仓库，则先执行 `git clone`。
10. 容器内的 `Claude Code Runner` 再执行项目识别、尝试运行、轻量压测和结果输出。
11. `BenchmarkJob` 模块读取 `benchmark_result.json`，匹配推荐的 `NodeRentalListing`，更新任务状态。

**成功响应 JSON 示例**

```json
{
  "benchmark_job_id": "bj_20260318_0001",
  "job_status": "queued",
  "current_stage": "preparing_input",
  "source_type": "git_repository"
}
```

**实现效果**

- 页面拿到新的 `benchmark_job_id`。
- 后端已经开始异步调度 benchmark 容器。
- 前端不等待真实结果，直接进入结果页。

**下一步**

前端跳转到 `BenchmarkResultPage`。

### 4.6 第 4 步：前端跳转到结果页并轮询任务状态

**用户操作**

买家无需再次点击，页面自动跳转。

**前端页面**

- 当前页面：`BenchmarkSubmitPage`
- 目标页面：`BenchmarkResultPage`

**后端模块与接口**

- `BenchmarkJob`
  - `GET /benchmark-jobs/{job_id}`

**请求示例**

```text
GET /benchmark-jobs/bj_20260318_0001
```

**响应 JSON 示例**

```json
{
  "benchmark_job_id": "bj_20260318_0001",
  "job_status": "running",
  "current_stage": "load_testing",
  "mode": "claude_runtime",
  "source_type": "git_repository",
  "source_summary": "https://github.com/example/demo-app.git#main",
  "failure_reason": null
}
```

**实现效果**

- 结果页显示当前阶段，例如 `queued`、`preparing_input`、`deploying`、`running`、`analyzing`。
- 不论底层是 `placeholder` 还是 `claude_runtime`，前端都只按统一状态渲染。

**下一步**

当 `job_status = succeeded` 时，请求推荐结果。

### 4.7 第 5 步：结果页获取推荐结果

**用户操作**

买家停留在 `BenchmarkResultPage`，等待最终结果。

**前端页面**

`BenchmarkResultPage`

**后端模块与接口**

- `BenchmarkJob`
  - `GET /benchmark-jobs/{job_id}/recommendations`

**请求示例**

```text
GET /benchmark-jobs/bj_20260318_0001/recommendations
```

**响应 JSON 示例**

```json
{
  "benchmark_job_id": "bj_20260318_0001",
  "job_status": "succeeded",
  "project_profile": {
    "project_type": "web_service",
    "language": "python",
    "framework": "fastapi"
  },
  "resource_recommendation": {
    "cpu_cores": 4,
    "memory_mb": 4096,
    "gpu_count": 0
  },
  "listing_recommendation": {
    "recommended_listing_ids": [
      201,
      248,
      299
    ],
    "selection_rationale": [
      "CPU recommendation matches 4 cores",
      "memory recommendation fits within 4GB-8GB range",
      "current platform price is competitive"
    ]
  },
  "recommended_listings": [
    {
      "listing_id": 201,
      "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
      "current_price_hourly": 18.6,
      "rentable_status": "rentable"
    },
    {
      "listing_id": 248,
      "title": "L40S x1 / 16C / 64GB / CN-BJ",
      "current_price_hourly": 21.5,
      "rentable_status": "rentable"
    }
  ]
}
```

**实现效果**

- 结果页展示项目类型、资源建议和推荐实例列表。
- 页面不自动下单，只给出推荐。

**下一步**

买家点击推荐项，跳转到 `ListingDetailPage`。

### 4.8 第 6 步：买家从推荐结果跳转到实例详情页

**用户操作**

买家点击某条推荐的 `NodeRentalListing`。

**前端页面**

- 当前页面：`BenchmarkResultPage`
- 目标页面：`ListingDetailPage`

**实现效果**

- 测算流程结束。
- 买家进入后续市场详情与直租流程。

## 5. 关键异常分支

### 5.1 异常分支 A：压缩包上传失败

**触发点**

买家上传 zip 文件时失败，例如文件过大、格式错误或网络中断。

**接口**

- `POST /benchmark-jobs/code-archive-uploads`

**错误响应示例**

```json
{
  "error_code": "code_archive_upload_failed",
  "message": "failed to upload benchmark archive"
}
```

**前端效果**

- 页面停留在 `BenchmarkSubmitPage`。
- 显示局部上传错误。
- 不创建 `BenchmarkJob`。

### 5.2 异常分支 B：未提供有效输入源

**触发点**

买家既没有上传压缩包，也没有填写 git 链接，或同时填写了两种来源。

**接口**

- `POST /benchmark-jobs`

**错误响应示例**

```json
{
  "error_code": "benchmark_source_missing",
  "message": "exactly one benchmark source must be provided"
}
```

**前端效果**

- 页面不跳转。
- 表单顶部显示业务错误。

### 5.3 异常分支 C：git clone 链接不合法或无法访问

**触发点**

买家提供的仓库地址格式不合法，或 benchmark 容器无法访问该仓库。

**接口**

- `POST /benchmark-jobs`
- `GET /benchmark-jobs/{job_id}`

**错误响应示例：创建前校验失败**

```json
{
  "error_code": "invalid_git_clone_url",
  "message": "git clone url is invalid"
}
```

**错误响应示例：运行中 clone 失败**

```json
{
  "benchmark_job_id": "bj_20260318_0001",
  "job_status": "failed",
  "current_stage": "preparing_input",
  "failure_reason": "git clone failed in benchmark workspace"
}
```

**前端效果**

- 如果是创建前校验失败，停留提交页。
- 如果是容器运行时 clone 失败，结果页显示失败原因和重新提交入口。

### 5.4 异常分支 D：测算仍在运行中

**触发点**

结果页轮询时，任务仍处于队列中、启动中或分析中。

**接口**

- `GET /benchmark-jobs/{job_id}`

**响应示例**

```json
{
  "benchmark_job_id": "bj_20260318_0001",
  "job_status": "running",
  "current_stage": "project_detecting",
  "source_type": "code_archive",
  "source_summary": "demo-app.zip"
}
```

**前端效果**

- 结果页显示阶段状态，不报错。
- 买家可以停留等待，也可以稍后回来继续看。

### 5.5 异常分支 E：测算失败或超时

**触发点**

`Claude Code Runner` 无法成功识别、启动或压测项目，或者总超时到达上限。

**接口**

- `GET /benchmark-jobs/{job_id}`

**响应示例**

```json
{
  "benchmark_job_id": "bj_20260318_0001",
  "job_status": "failed",
  "current_stage": "service_starting",
  "failure_reason": "project start command could not be inferred"
}
```

**前端效果**

- 结果页显示失败卡片。
- 提供“重新提交测算”入口。
- 不影响买家继续直接去市场选购实例。

### 5.6 异常分支 F：推荐结果已经过期

**触发点**

买家看到的推荐结果是历史快照，等点击时市场状态已经变化。

**接口**

- `GET /benchmark-jobs/{job_id}/recommendations`

**响应示例**

```json
{
  "benchmark_job_id": "bj_20260318_0001",
  "job_status": "succeeded",
  "recommendation_stale": true,
  "recommended_listings": [
    {
      "listing_id": 201,
      "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
      "rentable_status": "unavailable"
    }
  ]
}
```

**前端效果**

- 结果页仍可展示推荐快照。
- 但要明确提示“推荐结果可能已过期，请以详情页最新状态为准”。

## 6. 本文档结论

1. `BenchmarkJob` 的输入源必须明确分成两种：`code_archive` 和 `git_repository`。
2. 压缩包上传和 git 链接提交只是前端两条不同入口，最终都会被后端整理成统一的 `benchmark input manifest`。
3. `Swarm Adapter` 只负责创建 benchmark service，不负责理解前端表单；真正的输入源解析由 `BenchmarkJob` 模块完成。
4. benchmark 容器里的 `Claude Code Runner` 必须先把代码准备到工作区，再进行项目识别、尝试运行和压测。
5. 测算流程只输出推荐结果，不自动下单；最终购买入口仍然是 `ListingDetailPage`。

## 7. 推荐结果实时状态校验

### 7.1 推荐策略

采用**乐观展示 + 实时状态标注**：
- 推荐结果是快照，不锁定节点
- 前端展示时并行查询每个 listing 的当前状态
- 在 UI 上标注：✅ 可租用 / ⚠️ 已被占用 / ❌ 已下架

### 7.2 下单时二次校验

买家点击推荐项跳转到 `ListingDetailPage` 后：
- 详情页显示最新的 `rentable_status` 和 `current_price_hourly`
- 买家提交订单时，后端再次校验 listing 是否可租
- 如果已被占用，返回 `ORDER_011` 错误码

### 7.3 用户提示

在推荐列表顶部显示：
```
💡 推荐结果仅供参考，实际可租状态以下单时为准
```

