# 02 买家浏览 NodeRentalListing 市场并查看详情

版本：V2.0  
日期：2026-03-17

## 1. 文档目标

本文件把“买家浏览 `NodeRentalListing` 市场并查看详情”这条流程展开成真实操作脚本。

写法统一按下面顺序：

1. 用户做了什么
2. 这一步发生在哪个前端页面
3. 调用了哪个后端模块的哪个接口
4. 传了什么参数或 JSON
5. 后端返回了什么 JSON
6. 页面呈现出什么结果
7. 下一步去哪里

说明：  
这一条流程只涉及市场浏览和详情查看，不进入下单，不进入 `Deployment` 创建，也不涉及更底层 Docker Swarm 细节。

## 2. 本流程涉及的前后端对象

### 2.1 前端页面

- `PortalPage`
- `MarketListPage`
- `ListingDetailPage`

### 2.2 后端模块

- `Auth & Access`
- `NodeRentalListing Market`
- `ComputeNode Access`
- `PricingEngine`

### 2.3 本流程使用的 HTTP 接口

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /market/listings/filters` | `NodeRentalListing Market` | 获取筛选器配置 |
| `GET /market/listings` | `NodeRentalListing Market` | 获取市场列表 |
| `GET /market/listings/{listing_id}` | `NodeRentalListing Market` | 获取某条上架详情 |

## 3. 浏览逻辑总览

```mermaid
sequenceDiagram
    actor Buyer as Buyer
    participant Portal as PortalPage
    participant Market as MarketListPage
    participant Detail as ListingDetailPage
    participant MarketAPI as NodeRentalListing Market
    participant Pricing as PricingEngine
    participant Node as ComputeNode Access

    Buyer->>Portal: 点击进入市场
    Portal->>Market: 跳转市场列表页
    Market->>MarketAPI: GET /market/listings/filters
    Market->>MarketAPI: GET /market/listings
    MarketAPI-->>Market: 返回筛选条件和列表
    Buyer->>Market: 修改筛选条件 / 排序 / 搜索
    Market->>MarketAPI: GET /market/listings?filters...
    MarketAPI-->>Market: 返回筛选结果
    Buyer->>Detail: 点击某个 listing 卡片
    Detail->>MarketAPI: GET /market/listings/{listing_id}
    MarketAPI->>Pricing: 读取最新价格与解释
    MarketAPI->>Node: 读取节点当前状态摘要
    MarketAPI-->>Detail: 返回 listing 详情
```

## 4. 主成功流程

### 4.1 第 0 步：买家从平台首页进入市场

**用户操作**

买家在 `PortalPage` 点击“浏览算力市场”。

**前端页面**

- 当前页：`PortalPage`
- 目标页：`MarketListPage`

**后端模块与接口**

这一步只是前端路由跳转，不发生业务接口请求。

**实现效果**

- 浏览器跳转到市场列表页
- 列表页开始准备首屏数据

**下一步**

`MarketListPage` 请求筛选器和首屏列表。

### 4.2 第 1 步：市场列表页加载筛选器和首屏列表

**用户操作**

买家进入 `MarketListPage`，页面自动加载数据。

**前端页面**

`MarketListPage`

**后端模块与接口**

- `NodeRentalListing Market`
  - `GET /market/listings/filters`
  - `GET /market/listings`

**请求示例：筛选器**

```text
GET /market/listings/filters
```

**响应示例：筛选器**

```json
{
  "gpu_models": [
    "RTX 4090",
    "A100",
    "L40S"
  ],
  "regions": [
    "CN-SH",
    "CN-BJ",
    "US-WEST"
  ],
  "price_ranges": [
    {
      "label": "0-10",
      "min": 0,
      "max": 10
    },
    {
      "label": "10-30",
      "min": 10,
      "max": 30
    }
  ],
  "sort_options": [
    "price_asc",
    "price_desc",
    "gpu_desc",
    "latest"
  ]
}
```

**请求示例：首屏列表**

```text
GET /market/listings?limit=20&offset=0&sort=latest
```

**响应示例：首屏列表**

```json
{
  "items": [
    {
      "id": 201,
      "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
      "summary": "auto-generated from hardware profile",
      "region_code": "CN-SH",
      "gpu_model": "RTX 4090",
      "gpu_count": 1,
      "cpu_cores": 16,
      "memory_mb": 65536,
      "current_price_hourly": 18.6,
      "price_currency": "CNY",
      "publish_status": "listed",
      "rentable_status": "rentable",
      "price_updated_at": "2026-03-17T22:31:35Z"
    },
    {
      "id": 202,
      "title": "A100 x1 / 32C / 128GB / US-WEST",
      "summary": "auto-generated from hardware profile",
      "region_code": "US-WEST",
      "gpu_model": "A100",
      "gpu_count": 1,
      "cpu_cores": 32,
      "memory_mb": 131072,
      "current_price_hourly": 39.9,
      "price_currency": "CNY",
      "publish_status": "listed",
      "rentable_status": "rentable",
      "price_updated_at": "2026-03-17T22:30:10Z"
    }
  ],
  "total": 2
}
```

**实现效果**

- 页面渲染筛选器
- 页面渲染 listing 卡片列表
- 每张卡片显示核心配置、价格、当前可租状态

**下一步**

买家可以直接点击卡片，或继续筛选。

### 4.3 第 2 步：买家修改筛选条件、搜索词和排序

**用户操作**

买家在 `MarketListPage` 中：

- 选择 GPU 型号
- 选择价格区间
- 输入搜索词
- 切换排序方式

**前端页面**

`MarketListPage`

**后端模块与接口**

- `NodeRentalListing Market`
  - `GET /market/listings`

**请求示例**

```text
GET /market/listings?limit=20&offset=0&gpu_model=RTX%204090&region_code=CN-SH&price_min=10&price_max=30&keyword=4090&sort=price_asc
```

**响应示例**

```json
{
  "items": [
    {
      "id": 201,
      "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
      "summary": "auto-generated from hardware profile",
      "region_code": "CN-SH",
      "gpu_model": "RTX 4090",
      "gpu_count": 1,
      "cpu_cores": 16,
      "memory_mb": 65536,
      "current_price_hourly": 18.6,
      "price_currency": "CNY",
      "publish_status": "listed",
      "rentable_status": "rentable",
      "price_updated_at": "2026-03-17T22:31:35Z"
    }
  ],
  "total": 1
}
```

**实现效果**

- 页面局部刷新卡片列表
- 筛选器状态保留
- 排序变化立即体现在卡片顺序中

**下一步**

买家点击某个卡片，进入详情页。

### 4.4 第 3 步：买家打开某个 listing 的详情页

**用户操作**

买家点击某条 `NodeRentalListing` 卡片。

**前端页面**

- 当前页：`MarketListPage`
- 目标页：`ListingDetailPage`

**后端模块与接口**

- `NodeRentalListing Market`
  - `GET /market/listings/{listing_id}`
- `PricingEngine`
  - 由 `NodeRentalListing Market` 内部读取当前价格解释
- `ComputeNode Access`
  - 由 `NodeRentalListing Market` 内部读取节点在线状态摘要

**请求示例**

```text
GET /market/listings/201
```

**响应示例**

```json
{
  "id": 201,
  "compute_node_id": 101,
  "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
  "summary": "auto-generated from hardware profile",
  "description": "generated by backend from hostname, hardware profile and default market template",
  "hardware_profile": {
    "region_code": "CN-SH",
    "cpu_model": "AMD Ryzen 9 7950X",
    "cpu_cores": 16,
    "memory_mb": 65536,
    "gpu_vendor": "NVIDIA",
    "gpu_model": "RTX 4090",
    "gpu_count": 1,
    "gpu_memory_mb": 24576,
    "bandwidth_mbps": 300
  },
  "image_policy": "template",
  "current_price_hourly": 18.6,
  "price_currency": "CNY",
  "price_source": "pricing_engine",
  "price_explanation": "platform price generated from recent market references",
  "price_updated_at": "2026-03-17T22:31:35Z",
  "publish_status": "listed",
  "rentable_status": "rentable",
  "compute_node_runtime_status": "online",
  "min_duration_minutes": 60,
  "max_duration_minutes": 1440,
  "default_duration_minutes": 120
}
```

**实现效果**

- 详情页展示完整硬件信息
- 展示平台价格和价格说明
- 展示当前可租状态
- 页面允许买家进入下一条“直租”流程

**下一步**

买家可以返回列表继续浏览，或者进入“买家直租”流程。

## 5. 关键异常分支

### 5.1 异常分支 A：筛选器加载失败

**触发点**

买家进入 `MarketListPage` 时，`GET /market/listings/filters` 失败。

**接口**

- `GET /market/listings/filters`

**响应示例**

```json
{
  "error_code": "market_filters_unavailable",
  "message": "market filters are temporarily unavailable"
}
```

**前端效果**

- 页面仍保留基础壳子
- 筛选器区显示局部错误卡片
- 若列表还能加载，则仍可浏览默认列表

### 5.2 异常分支 B：列表返回空结果

**触发点**

筛选后的查询没有匹配项。

**接口**

- `GET /market/listings?...`

**响应示例**

```json
{
  "items": [],
  "total": 0
}
```

**前端效果**

- 页面进入空状态
- 显示当前筛选条件摘要
- 提供“清空筛选”

### 5.3 异常分支 C：详情页打开时记录已不可租

**触发点**

买家点击详情时，这条 listing 已被租出、下架或节点离线。

**接口**

- `GET /market/listings/{listing_id}`

**响应示例**

```json
{
  "id": 201,
  "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
  "publish_status": "listed",
  "rentable_status": "unavailable",
  "compute_node_runtime_status": "offline",
  "current_price_hourly": 18.6,
  "price_currency": "CNY",
  "availability_message": "compute node is offline, listing is temporarily unavailable"
}
```

**前端效果**

- 详情页仍然允许查看
- “立即租用”按钮禁用
- 页面顶部显示当前不可租提示

### 5.4 异常分支 D：价格信息过期

**触发点**

列表或详情中的价格不是最新快照。

**接口**

- `GET /market/listings`
- `GET /market/listings/{listing_id}`

**响应示例**

```json
{
  "id": 201,
  "title": "RTX4090 x1 / 16C / 64GB / CN-SH",
  "current_price_hourly": 18.6,
  "price_currency": "CNY",
  "price_updated_at": "2026-03-17T21:00:00Z",
  "price_stale": true,
  "price_explanation": "displaying last available price snapshot"
}
```

**前端效果**

- 页面继续展示旧价格
- 明确显示“价格可能已过期”
- 不允许把旧价格静默当成最新价格

### 5.5 异常分支 E：详情记录不存在

**触发点**

买家通过旧链接或错误链接打开详情页。

**接口**

- `GET /market/listings/{listing_id}`

**响应示例**

```json
{
  "error_code": "listing_not_found",
  "message": "listing does not exist"
}
```

**前端效果**

- 页面跳转到 `NotFoundPage`

## 6. 本文档结论

1. 市场浏览流程只涉及 `NodeRentalListing Market`，不应提前进入订单或部署逻辑。
2. 列表页至少需要两个接口：一个拉筛选器，一个拉列表。
3. 详情页必须同时返回市场信息、价格信息和节点在线状态摘要，这样前端才能正确决定是否允许继续租用。
4. 价格过期、节点离线、listing 不可租都不应直接把详情页做成 404，而应优先返回可查看但不可租的详情态。
5. 这条流程的输出是“买家理解市场并选中一个目标 listing”，不是下单成功。
