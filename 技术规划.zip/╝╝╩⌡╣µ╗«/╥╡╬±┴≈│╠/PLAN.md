# 业务流程实施计划

## 1. 目录目标

本目录用于把平台的主业务链路落成可编码、可测试、可验收的实现计划。

本目录当前覆盖 7 条核心流程：

1. 卖家接入 `ComputeNode` 并自动生成 `NodeRentalListing`
2. 买家浏览 `NodeRentalListing` 市场并查看详情
3. 买家直租 `NodeRentalListing` 并创建 `RentalOrder + Deployment`
4. 买家在控制台查看实例状态并申请网页连接
5. 买家发起 `BenchmarkJob` 并查看推荐
6. 运行态轮询与 `Runtime Reconcile`
7. 管理员查看平台 `Dashboard`

这些流程不是孤立页面说明，而是平台交易主链路与运营链路的串联：

- `01 卖家接入` 为市场供给入口
- `02 市场浏览` 为买家选品入口
- `03 直租下单` 为交易主写路径
- `04 控制台与网页连接` 为租后使用路径
- `05 Benchmark` 为辅助推荐路径
- `06 Runtime Reconcile` 为运行态兜底与异常发现路径
- `07 Dashboard` 为平台运营观察路径

本目录的 `PLAN.md` 目标是明确：

- 每条流程需要实现什么
- 每条流程在当前项目中的代码落点
- 每条流程的前后端边界和依赖关系
- 每条流程如何测试
- 哪些流程必须先做，哪些流程可以后补

本目录尤其要强调：业务流程文档中的 Mermaid 时序图和接口表，就是流程设计本身的一部分。

- Mermaid 图用于固定“谁先调谁、谁依赖谁、成功路径怎么串、异常从哪里分叉”
- 表格用于固定每条流程对应的页面、模块、HTTP 接口和输入输出清单

如果后续修改了主成功路径、异常分支、页面跳转、接口集合或角色参与对象，必须同步修改相应 Mermaid 图和表格，否则应视为流程设计未更新完成。

---

## 2. 统一实现原则

业务流程实现时，必须同时遵守以下约束：

- 后端为权威事实源：
  - 可租状态
  - 价格快照
  - 订单状态
  - 部署状态
  - 网页入口状态
  - Benchmark 状态
- Docker Swarm 的所有底层操作只允许通过 `Swarm Adapter` 访问，业务流程不直接依赖 Docker CLI/SDK。
- 前端主实现固定为独立 `platform-frontend`，当前阶段不要求新后端兼容旧 `system-template/system-vue`。
- 前端页面数量、页面职责、跳转关系必须严格遵循 `技术规划\前端\前端页面规划文档.md`。
- 前端必须分层实现：
  - `views/platform` 负责 UI
  - `page-models/platform` 负责页面编排
  - `store/modules/platform*` 负责状态
  - `api/platform` 负责网络层
  - `services/platform` 负责业务规则
- 页面 UI 不得直接写 `axios/fetch`、复杂业务规则、token 刷新、统一重试逻辑。
- 所有主写路径默认必须考虑：
  - 事务边界
  - 幂等
  - 并发冲突
  - 失败补偿
- 所有“状态展示页面”默认必须考虑状态滞后，关键动作前做实时二次校验。

---

## 3. 当前项目中的建议落点

## 3.1 后端

建议统一落到：

- `../../Pivot_Computing_Power_Network/platform-backend/app/modules/compute_nodes/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/modules/listings/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/modules/orders/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/modules/deployments/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/modules/benchmark/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/modules/admin_dashboard/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/integrations/swarm/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/application/`

建议 API 路由按业务域拆分：

- `app/api/seller/compute_nodes/`
- `app/api/seller/listings/`
- `app/api/market/listings/`
- `app/api/rental_orders/`
- `app/api/benchmark_jobs/`
- `app/api/admin/dashboard/`

## 3.2 Worker

建议统一落到：

- `../../Pivot_Computing_Power_Network/platform-worker/app/tasks/orders/`
- `../../Pivot_Computing_Power_Network/platform-worker/app/tasks/benchmark/`
- `../../Pivot_Computing_Power_Network/platform-worker/app/tasks/reconcile/`
- `../../Pivot_Computing_Power_Network/platform-worker/app/tasks/metrics/`

## 3.3 前端

建议统一落到独立新前端工程：

- `../../Pivot_Computing_Power_Network/platform-frontend/src/views/platform/`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/page-models/platform/`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/api/platform/`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/services/platform/`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/store/modules/`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/router/modules/platform.js`

## 3.4 测试

建议统一落到：

- `../../Pivot_Computing_Power_Network/platform-backend/tests/`
- `../../Pivot_Computing_Power_Network/platform-worker/tests/`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/__tests__/platform/`
- `../../Pivot_Computing_Power_Network/platform-frontend/tests/e2e/`
- `../../test/`

---

## 4. 实施优先级

### P0：必须先完成

1. `01 卖家接入 ComputeNode`
2. `02 买家浏览市场并查看详情`
3. `03 买家直租并创建 Deployment`
4. `04 买家控制台与网页连接`
5. `06 Runtime Reconcile`

原因：

- 这 5 条流程才能形成“供给 -> 浏览 -> 下单 -> 使用 -> 异常发现”的最小闭环。

### P1：主链路跑通后补齐

1. `05 BenchmarkJob`
2. `07 Admin Dashboard`

原因：

- 它们重要，但不应阻塞交易闭环。
- Benchmark 是辅助推荐，不自动下单。
- Dashboard 是运营视图，不是交易主链路。

---

## 5. 逐流程实施方案

## 5.1 流程 01：卖家接入 ComputeNode

依据：

- `00_业务流程综述.md`
- `01_卖家接入ComputeNode.md`

### 需要实现的内容

- 卖家工作台展示已有节点与已有 listing
- 接入说明页返回固定步骤和安全说明
- 创建 `bootstrap_session`
- 生成本地 bootstrap 命令
- 本地脚本执行 `register-self`
- 后端通过 `Swarm Adapter` 校验 worker 已加入
- 自动认领节点、写入标签、生成价格、自动创建并自动上架 `NodeRentalListing`
- 工作台轮询接入状态，成功后自动返回卖家工作台
- listing 管理页支持下架、重新上架、手动同步

### 代码位置

- 后端：
  - `platform-backend/app/modules/compute_nodes/`
  - `platform-backend/app/modules/listings/`
  - `platform-backend/app/modules/pricing/`
  - `platform-backend/app/integrations/swarm/`
- 前端：
  - `platform-frontend/src/views/platform/SellerWorkbenchPage/`
  - `platform-frontend/src/views/platform/ComputeNodeAccessGuidePage/`
  - `platform-frontend/src/views/platform/ComputeNodeBootstrapPage/`
  - `platform-frontend/src/views/platform/ListingManagePage/`
  - `platform-frontend/src/page-models/platform/seller/`
  - `platform-frontend/src/api/platform/seller.js`
  - `platform-frontend/src/services/platform/seller-service.js`

### 达成要求

- 卖家无需网页登记表单
- 卖家无需手工填写 listing 标题和描述
- 卖家无需手工点击发布
- `register-self` 成功后自动出现：
  - `ComputeNode`
  - 自动生成的 listing
- Swarm 识别失败、定价待生成、节点离线等异常有明确状态返回

### 测试方法

- API 测试：
  - 创建 bootstrap session
  - register-self 成功
  - 重复注册幂等
  - worker not found
  - pricing pending
- 集成测试：
  - mock Swarm 接入成功后自动建 node 和 listing
  - 节点离线后 listing 状态联动
- 前端测试：
  - Bootstrap 状态轮询
  - 局部错误展示
  - 自动回工作台
- E2E：
  - 卖家生成命令 -> 模拟接入 -> 工作台出现新节点和新 listing

### 测试位置

- `platform-backend/tests/api/test_compute_node_access_flow.py`
- `platform-backend/tests/integration/test_compute_node_auto_listing.py`
- `platform-frontend/src/__tests__/platform/seller-bootstrap.spec.js`
- `platform-frontend/tests/e2e/business-flow-seller-access.spec.ts`

## 5.2 流程 02：买家浏览市场并查看详情

依据：

- `00_业务流程综述.md`
- `02_买家浏览NodeRentalListing市场并查看详情.md`

### 需要实现的内容

- 从 `PortalPage` 进入 `MarketListPage`
- 列表页并行拉取筛选器与首屏列表
- 列表页支持：
  - GPU、区域、价格区间筛选
  - 搜索词
  - 排序
- 详情页返回：
  - listing 基本信息
  - 完整硬件摘要
  - 当前价格与价格解释
  - `publish_status`
  - `rentable_status`
  - 节点在线状态摘要
  - 默认租用时长范围

### 代码位置

- 后端：
  - `platform-backend/app/modules/listings/`
  - `platform-backend/app/modules/pricing/`
  - `platform-backend/app/modules/compute_nodes/`
- 前端：
  - `platform-frontend/src/views/platform/PortalPage/`
  - `platform-frontend/src/views/platform/MarketListPage/`
  - `platform-frontend/src/views/platform/ListingDetailPage/`
  - `platform-frontend/src/page-models/platform/market/`
  - `platform-frontend/src/api/platform/market.js`
  - `platform-frontend/src/services/platform/market-service.js`

### 达成要求

- 列表页筛选器失败时，列表仍可在降级模式下工作
- 列表空结果与错误态明确区分
- 详情页在 listing 不可租或节点离线时仍可查看
- 价格过期必须显式标注 `price_stale`
- 详情页只能在后端确认 `rentable_status = rentable` 时允许进入下单

### 测试方法

- API 测试：
  - filters 接口
  - 列表筛选、搜索、排序
  - 详情页状态组合
  - stale price 展示字段
- 前端测试：
  - 筛选条件保留
  - filters 局部失败降级
  - 空状态和错误态区分
  - 详情页按钮禁用逻辑
- E2E：
  - 首页进入市场
  - 应用筛选
  - 打开详情
  - 不可租状态下按钮禁用

### 测试位置

- `platform-backend/tests/api/test_market_listing_browse.py`
- `platform-backend/tests/api/test_market_listing_detail.py`
- `platform-frontend/src/__tests__/platform/market-list.spec.js`
- `platform-frontend/src/__tests__/platform/listing-detail.spec.js`
- `platform-frontend/tests/e2e/business-flow-market-browse.spec.ts`

## 5.3 流程 03：买家直租并创建 Deployment

依据：

- `00_业务流程综述.md`
- `03_买家直租NodeRentalListing并创建Deployment.md`

### 需要实现的内容

- `ListingDetailPage` 填写租用参数
- 前端本地校验：
  - duration
  - image source
  - command
  - env vars
  - exposed port
- `POST /rental-orders`
- 后端在同一主链路内完成：
  - 锁定 listing
  - 校验当前可租
  - 重新计算权威价格
  - 比较客户端价格与当前价格快照
  - 冻结余额
  - 创建 `RentalOrder`
  - 创建 `Deployment`
  - 事务外调用 `Swarm Adapter.deploy_runtime_service()`
  - 失败退款和状态回写
- 前端跳转 `RentalOrderDetailPage`
- 详情页轮询订单与部署状态
- “我的实例”列表出现新订单

### 代码位置

- 后端：
  - `platform-backend/app/modules/orders/`
  - `platform-backend/app/modules/deployments/`
  - `platform-backend/app/modules/listings/`
  - `platform-backend/app/modules/pricing/`
  - `platform-backend/app/integrations/swarm/`
  - `platform-worker/app/tasks/orders/`
- 前端：
  - `platform-frontend/src/views/platform/ListingDetailPage/`
  - `platform-frontend/src/views/platform/RentalOrderDetailPage/`
  - `platform-frontend/src/views/platform/RentalOrderListPage/`
  - `platform-frontend/src/page-models/platform/orders/`
  - `platform-frontend/src/api/platform/orders.js`
  - `platform-frontend/src/services/platform/order-service.js`

### 达成要求

- 主写入口固定为 `POST /rental-orders`
- listing 并发下单不能超售
- 请求超时或重复提交时，必须依赖 `idempotency_key`
- 价格变动、余额不足、listing 不可租、部署失败都有明确分支
- 订单详情页必须显式支持：
  - `starting`
  - `running`
  - `failed`
- 释放与结算要预留：
  - 主动释放
  - 自动到期释放
  - 按实际运行时长结算

### 测试方法

- 单元测试：
  - 订单状态机
  - 部署状态机
  - 金额计算
- API 测试：
  - 下单成功
  - listing 不可租
  - price changed
  - insufficient balance
  - idempotency retry
- 集成测试：
  - 行锁防并发超售
  - 事务失败自动回滚
  - 部署失败自动退款
- 前端测试：
  - 表单本地校验
  - 失败后保留输入
  - 价格变化后重算预计冻结金额
- E2E：
  - 详情页下单 -> 详情页等待启动 -> 成功显示运行中

### 测试位置

- `platform-backend/tests/unit/test_order_state_machine.py`
- `platform-backend/tests/unit/test_deployment_state_machine.py`
- `platform-backend/tests/api/test_rental_order_create.py`
- `platform-backend/tests/integration/test_order_locking.py`
- `platform-backend/tests/integration/test_order_refund_on_deploy_failure.py`
- `platform-frontend/src/__tests__/platform/rental-order-submit.spec.js`
- `platform-frontend/tests/e2e/business-flow-rental-order.spec.ts`

## 5.4 流程 04：买家控制台查看容器与网页连接

依据：

- `00_业务流程综述.md`
- `04_买家控制台查看容器与网页连接.md`

### 需要实现的内容

- “我的实例”列表页
- 实例详情页
- 根据后端字段渲染：
  - `order_status`
  - `runtime_status`
  - `web_entry_status`
  - `workspace_mode`
  - `workspace_capabilities`
- 通过 `POST /rental-orders/{order_id}/web-connect` 申请短时 `connect_url`
- 后端在申请连接时实时校验 Swarm 运行状态与网页入口状态
- 前端按 `connect_mode` 打开新标签页或嵌入面板
- 明确不支持 SSH，只支持：
  - 浏览器上传文件
  - 浏览器终端 `git clone`

### 代码位置

- 后端：
  - `platform-backend/app/modules/orders/`
  - `platform-backend/app/modules/deployments/`
  - `platform-backend/app/integrations/swarm/`
  - `platform-backend/app/application/deployments/`
- 前端：
  - `platform-frontend/src/views/platform/RentalOrderListPage/`
  - `platform-frontend/src/views/platform/RentalOrderDetailPage/`
  - `platform-frontend/src/page-models/platform/orders/`
  - `platform-frontend/src/api/platform/orders.js`
  - `platform-frontend/src/services/platform/order-service.js`

### 达成要求

- 控制台展示的是 `RentalOrder + Deployment` 组合视图，而不是误导性的“裸 container”
- 网页连接必须走临时 `connect_url`
- 按后端返回字段决定按钮可用性，不允许前端猜状态
- `web_app` 与 `code_server / jupyterlab` 这类工作区能力必须区分显示
- `connect_url` 获取前必须做实时运行态校验

### 测试方法

- API 测试：
  - 列表与详情查询
  - web-connect 成功
  - deployment_not_running
  - connect_prepare_failed
- 集成测试：
  - Swarm 状态变化后 web-connect 失败分支
  - connect session 过期
- 前端测试：
  - 按 `web_entry_status` 控制按钮启用
  - 非开发工作区能力提示
  - 连接失败可重试
- E2E：
  - 从实例列表进入详情
  - 申请网页连接
  - 启动中或已丢失状态下按钮/提示正确

### 测试位置

- `platform-backend/tests/api/test_rental_order_console.py`
- `platform-backend/tests/integration/test_web_connect_flow.py`
- `platform-frontend/src/__tests__/platform/order-console.spec.js`
- `platform-frontend/tests/e2e/business-flow-console-web-connect.spec.ts`

## 5.5 流程 05：买家发起 BenchmarkJob 并查看推荐

依据：

- `00_业务流程综述.md`
- `05_买家发起BenchmarkJob并查看推荐.md`

### 需要实现的内容

- `BenchmarkSubmitPage` 支持两种输入方式二选一：
  - code archive
  - git repository
- 压缩包上传接口
- 创建 BenchmarkJob 接口
- 统一生成 benchmark input manifest
- 调度 benchmark service
- 结果页轮询任务状态
- 结果页读取推荐列表
- 从推荐结果跳转到 `ListingDetailPage`

### 代码位置

- 后端：
  - `platform-backend/app/modules/benchmark/`
  - `platform-backend/app/integrations/swarm/`
  - `platform-worker/app/tasks/benchmark/`
  - `platform-benchmark/`
- 前端：
  - `platform-frontend/src/views/platform/BenchmarkSubmitPage/`
  - `platform-frontend/src/views/platform/BenchmarkResultPage/`
  - `platform-frontend/src/page-models/platform/benchmark/`
  - `platform-frontend/src/api/platform/benchmarks.js`
  - `platform-frontend/src/services/platform/benchmark-service.js`

### 达成要求

- 输入源只能二选一
- zip 上传必须做大小、解压后大小、文件数、目录深度、压缩比、路径安全检查
- 容器隔离必须有资源限制和最小权限
- 前端只按统一状态渲染，不感知底层 placeholder / runtime 模式差异
- 推荐结果只做辅助决策，不自动下单
- 推荐结果必须显式标注“可能过期，以详情页为准”

### 测试方法

- API 测试：
  - 上传压缩包
  - 创建 job
  - 任务状态查询
  - 推荐结果查询
- 集成测试：
  - code archive 路径
  - git repository 路径
  - git clone failed
  - timeout / result parse failed
- 前端测试：
  - 输入源二选一校验
  - 轮询状态展示
  - 推荐 stale 提示
- E2E：
  - 提交 benchmark -> 查看结果 -> 点击推荐进入详情

### 测试位置

- `platform-backend/tests/api/test_benchmark_job_api.py`
- `platform-worker/tests/integration/test_benchmark_job_flow.py`
- `platform-worker/tests/integration/test_benchmark_job_failure_cases.py`
- `platform-frontend/src/__tests__/platform/benchmark-submit.spec.js`
- `platform-frontend/src/__tests__/platform/benchmark-result.spec.js`
- `platform-frontend/tests/e2e/business-flow-benchmark.spec.ts`

## 5.6 流程 06：Runtime Reconcile

依据：

- `00_业务流程综述.md`
- `技术规划\复杂独立模块专项文档\轮询状态与 Runtime Reconcile 专项设计文档.md`

### 需要实现的内容

- 周期扫描 deployment 与 runtime service 实际状态
- 对比数据库状态与 Swarm 状态
- 生成 `runtime_events`
- 自动修正常见异常
- 对高风险异常标记人工介入
- 将风险结果反馈到：
  - 买家实例详情
  - 卖家节点状态
  - 管理员风险区

### 代码位置

- 后端：
  - `platform-backend/app/modules/runtime_events/`
  - `platform-backend/app/application/reconcile/`
  - `platform-backend/app/integrations/swarm/`
- Worker：
  - `platform-worker/app/tasks/reconcile/`
- 前端：
  - `platform-frontend/src/views/platform/RentalOrderDetailPage/`
  - `platform-frontend/src/views/platform/AdminDashboardPage/`

### 达成要求

- 异常发现来源固定为后端主动轮询
- 前端轮询只读取后端结果，不自行推断真实容器状态
- 常见偏差可自动修正
- 高风险异常可审计、可告警、可人工处理
- 重试次数、最后尝试时间、人工介入标志必须可追踪

### 测试方法

- 单元测试：
  - 对账规则
  - 状态修正规则
- 集成测试：
  - 数据库与 Swarm 状态不一致
  - 节点离线
  - service missing
  - web entry missing
- Worker 测试：
  - 定时任务扫描
  - 重试与人工介入标记
- 前端测试：
  - 订单详情展示最新异常状态
  - Dashboard 风险区展示事件流

### 测试位置

- `platform-worker/tests/unit/test_reconcile_rules.py`
- `platform-worker/tests/integration/test_reconcile_flow.py`
- `platform-worker/tests/integration/test_reconcile_retry_policy.py`
- `platform-frontend/src/__tests__/platform/runtime-risk-display.spec.js`

## 5.7 流程 07：管理员查看平台 Dashboard

依据：

- `00_业务流程综述.md`
- `07_管理员查看平台Dashboard.md`

### 需要实现的内容

- `AdminDashboardPage` 首屏骨架
- 7 组接口的分块并行请求：
  - 总览与 KPI
  - 节点监控区
  - 市场与价格区
  - 订单与部署区
  - Benchmark 区
  - 风险与异常区
  - 审计区
- 节点详情抽屉
- 区块独立刷新
- 区块独立失败、独立重试

### 代码位置

- 后端：
  - `platform-backend/app/modules/admin_dashboard/`
  - `platform-worker/app/tasks/metrics/`
  - `platform-backend/app/modules/runtime_events/`
- 前端：
  - `platform-frontend/src/views/platform/AdminDashboardPage/`
  - `platform-frontend/src/page-models/platform/admin/`
  - `platform-frontend/src/api/platform/admin.js`
  - `platform-frontend/src/services/platform/admin-service.js`

### 达成要求

- 所有管理接口默认 admin 权限保护
- 大盘默认只读快照或缓存，不现场拼大 SQL
- 不依赖单一大总览接口
- 每个 widget 可独立加载、独立失败、独立重试
- 快照延迟必须以 `generated_at` 明确展示
- 前端所有刷新定时器在页面卸载时必须清理

### 测试方法

- API 测试：
  - 各类 overview / distribution / trend / ranking / timeline 接口
  - admin 权限拦截
- 集成测试：
  - 采集任务写快照
  - dashboard 读取缓存/快照结果
- 前端测试：
  - widget 并行加载
  - 单区块失败不影响全页
  - 定时器清理
  - 空数据与错误态区分
- E2E：
  - 管理员打开 dashboard
  - 节点详情抽屉
  - 单 widget 错误重试

### 测试位置

- `platform-backend/tests/api/test_admin_dashboard_api.py`
- `platform-worker/tests/integration/test_metric_snapshot_pipeline.py`
- `platform-frontend/src/__tests__/platform/admin-dashboard.spec.js`
- `platform-frontend/tests/e2e/business-flow-admin-dashboard.spec.ts`

---

## 6. 推荐开发顺序

必须按下面顺序推进：

1. 流程 01：卖家接入 ComputeNode
2. 流程 02：买家浏览市场并查看详情
3. 流程 03：买家直租并创建 Deployment
4. 流程 04：买家控制台查看容器与网页连接
5. 流程 06：Runtime Reconcile
6. 流程 05：BenchmarkJob
7. 流程 07：Admin Dashboard

原因：

- 流程 01 到 04 才能形成最小业务闭环。
- 流程 06 是租后稳定性的兜底，不应放到最后。
- 流程 05 和 07 在主链路跑通后更容易稳定落地。

---

## 7. 测试覆盖要求

本目录对应的每条流程，至少都要覆盖 4 类测试：

1. 单元测试：
   - 状态机
   - 业务规则
   - 参数校验
2. API / 契约测试：
   - 成功响应
   - 错误响应
   - 权限与幂等
3. 集成测试：
   - 后端模块联动
   - 数据库与 worker / adapter 协作
4. 前端或 E2E 测试：
   - 页面跳转
   - 状态展示
   - 关键异常分支

额外刚性要求：

- 每个 P0 流程至少 1 条完整 E2E
- 每个已知业务 bug 都必须补回归测试
- 每个页面必须明确区分：
  - loading
  - empty
  - partial error
  - page error
  - permission error

---

## 8. 完成标准

当以下条件满足时，本目录可以认为达到可交付状态：

- 流程 01 到 04 可串成完整交易闭环
- Runtime Reconcile 可以发现并回写关键异常
- Benchmark 可独立提交并产出推荐
- Admin Dashboard 能稳定读取快照并按 widget 渲染
- 所有前端页面都基于独立 `platform-frontend` 落地
- 所有流程都有对应自动化测试骨架

---

## 9. 当前阶段结论

本目录的核心价值不是“多几个页面”，而是把平台最重要的 7 条行为链路固定下来。

如果不先把这些流程按模块边界、页面边界、状态边界和测试边界写死，后续实现会出现以下问题：

- 市场、订单、部署逻辑串线
- 前端页面直接承担后端决策
- Swarm 细节污染业务模块
- 异常分支没有落到自动化测试
- 管理后台与交易主链路脱节

因此本目录建议作为：

- 后端模块开发顺序的直接依据
- 前端页面接入顺序的直接依据
- E2E 回归矩阵的直接依据
