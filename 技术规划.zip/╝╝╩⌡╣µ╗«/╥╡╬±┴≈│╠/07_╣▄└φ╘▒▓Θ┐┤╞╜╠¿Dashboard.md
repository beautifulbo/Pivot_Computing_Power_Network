# 07 管理员查看平台 Dashboard

版本：V2.0  
日期：2026-03-18

## 1. 文档目标

本文档只描述一件事：管理员进入 `AdminDashboardPage` 后，前端如何通过大量只读接口并行拉取平台统计数据，并把这些数据渲染成可自由发挥的大屏式 dashboard。

这里固定 4 个前提：

1. 管理员已经登录，且具备 `admin` 权限。
2. **【权限保护】**(Bug-07-03)：所有管理接口使用统一权限装饰器或路由级别依赖,确保只有admin角色可访问。
3. `Admin Dashboard` 默认只读 `Metric Snapshot / Cache`，不在页面请求路径上现场拼大 SQL。
4. 前端不依赖单一超大接口，而是按 widget 分组并行请求。
5. 某个 widget 失败时，只影响该 widget，不影响整页其他区块。

## 2. 本流程涉及的前后端对象

### 2.1 前端页面

- `AdminDashboardPage`

### 2.2 后端模块

- `Auth & Access`
- `Admin Dashboard`
- `Metric Collector + Snapshot / Cache`

### 2.3 本流程使用的 HTTP 接口

为了给前端留下足够大的发挥空间，管理员大屏按 7 组接口拆分。

#### A. 总览与顶部 KPI

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /admin/dashboard/overview` | `Admin Dashboard` | 获取首屏组合数据 |
| `GET /admin/dashboard/kpi-summary` | `Admin Dashboard` | 获取顶部 KPI 条 |
| `GET /admin/dashboard/platform-health` | `Admin Dashboard` | 获取平台健康度摘要 |
| `GET /admin/dashboard/platform-load` | `Admin Dashboard` | 获取平台平均负载 |
| `GET /admin/dashboard/resource-capacity` | `Admin Dashboard` | 获取平台总容量 |
| `GET /admin/dashboard/resource-utilization-trend` | `Admin Dashboard` | 获取资源利用率趋势 |
| `GET /admin/dashboard/activity-timeline` | `Admin Dashboard` | 获取首页时间线 |

#### B. 节点监控区

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /admin/nodes/overview` | `Admin Dashboard` | 获取节点概况 |
| `GET /admin/nodes/status-distribution` | `Admin Dashboard` | 获取节点状态分布 |
| `GET /admin/nodes/load-matrix` | `Admin Dashboard` | 获取单机负载矩阵 |
| `GET /admin/nodes/top-cpu` | `Admin Dashboard` | 获取 CPU 负载 Top |
| `GET /admin/nodes/top-memory` | `Admin Dashboard` | 获取内存负载 Top |
| `GET /admin/nodes/top-gpu` | `Admin Dashboard` | 获取 GPU 负载 Top |
| `GET /admin/nodes/top-network-in` | `Admin Dashboard` | 获取网络入流量 Top |
| `GET /admin/nodes/top-network-out` | `Admin Dashboard` | 获取网络出流量 Top |
| `GET /admin/nodes/top-idle` | `Admin Dashboard` | 获取最空闲节点排行 |
| `GET /admin/nodes/risk-ranking` | `Admin Dashboard` | 获取风险节点排行 |
| `GET /admin/nodes/heartbeat-latency` | `Admin Dashboard` | 获取心跳延迟统计 |
| `GET /admin/nodes/{node_id}/detail` | `Admin Dashboard` | 获取单节点详情抽屉数据 |

#### C. 市场与价格区

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /admin/market/overview` | `Admin Dashboard` | 获取市场概况 |
| `GET /admin/market/listing-status-distribution` | `Admin Dashboard` | 获取上架状态分布 |
| `GET /admin/market/gpu-distribution` | `Admin Dashboard` | 获取 GPU 型号分布 |
| `GET /admin/market/cpu-tier-distribution` | `Admin Dashboard` | 获取 CPU 档位分布 |
| `GET /admin/market/region-distribution` | `Admin Dashboard` | 获取区域分布 |
| `GET /admin/market/price-trend` | `Admin Dashboard` | 获取价格趋势 |
| `GET /admin/market/top-hot-listings` | `Admin Dashboard` | 获取热门上架排行 |
| `GET /admin/market/top-expensive-listings` | `Admin Dashboard` | 获取高价上架排行 |
| `GET /admin/market/top-cheap-listings` | `Admin Dashboard` | 获取低价上架排行 |

#### D. 订单与部署区

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /admin/orders/overview` | `Admin Dashboard` | 获取订单概况 |
| `GET /admin/orders/status-distribution` | `Admin Dashboard` | 获取订单状态分布 |
| `GET /admin/orders/create-trend` | `Admin Dashboard` | 获取订单创建趋势 |
| `GET /admin/orders/release-type-distribution` | `Admin Dashboard` | 获取释放类型占比 |
| `GET /admin/orders/expiring-soon` | `Admin Dashboard` | 获取即将到期订单 |
| `GET /admin/orders/high-value` | `Admin Dashboard` | 获取高价值订单排行 |
| `GET /admin/deployments/overview` | `Admin Dashboard` | 获取部署概况 |
| `GET /admin/deployments/runtime-distribution` | `Admin Dashboard` | 获取部署运行态分布 |
| `GET /admin/deployments/web-entry-distribution` | `Admin Dashboard` | 获取网页入口状态分布 |
| `GET /admin/deployments/runtime-failure-top` | `Admin Dashboard` | 获取部署失败原因排行 |

#### E. Benchmark 区

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /admin/benchmarks/overview` | `Admin Dashboard` | 获取测算总览 |
| `GET /admin/benchmarks/status-distribution` | `Admin Dashboard` | 获取测算状态分布 |
| `GET /admin/benchmarks/mode-distribution` | `Admin Dashboard` | 获取测算模式分布 |
| `GET /admin/benchmarks/source-type-distribution` | `Admin Dashboard` | 获取输入来源分布 |
| `GET /admin/benchmarks/duration-trend` | `Admin Dashboard` | 获取测算耗时趋势 |
| `GET /admin/benchmarks/failure-top` | `Admin Dashboard` | 获取测算失败排行 |

#### F. 风险与异常区

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /admin/risk/overview` | `Admin Dashboard` | 获取风险概况 |
| `GET /admin/risk/runtime-events` | `Admin Dashboard` | 获取运行异常事件流 |
| `GET /admin/risk/severity-distribution` | `Admin Dashboard` | 获取严重级别分布 |
| `GET /admin/risk/event-type-distribution` | `Admin Dashboard` | 获取异常类型分布 |
| `GET /admin/risk/refund-compensation-stats` | `Admin Dashboard` | 获取退款与补偿统计 |
| `GET /admin/risk/risk-nodes` | `Admin Dashboard` | 获取高风险节点列表 |

#### G. 审计区

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /admin/audit/timeline` | `Admin Dashboard` | 获取审计时间线 |
| `GET /admin/audit/action-type-distribution` | `Admin Dashboard` | 获取审计动作分布 |
| `GET /admin/audit/recent-admin-logins` | `Admin Dashboard` | 获取最近管理员登录记录 |

## 3. Dashboard 页面总览流程

```mermaid
sequenceDiagram
    actor Admin as Admin User
    participant Page as AdminDashboardPage
    participant API as Admin Dashboard
    participant Cache as Metric Snapshot / Cache

    Admin->>Page: 打开 AdminDashboardPage

    par 顶部与总览区
        Page->>API: GET /admin/dashboard/kpi-summary
        Page->>API: GET /admin/dashboard/platform-health
        Page->>API: GET /admin/dashboard/platform-load
        Page->>API: GET /admin/dashboard/resource-capacity
        Page->>API: GET /admin/dashboard/resource-utilization-trend
    and 节点区
        Page->>API: GET /admin/nodes/load-matrix
        Page->>API: GET /admin/nodes/top-cpu
        Page->>API: GET /admin/nodes/top-gpu
        Page->>API: GET /admin/nodes/risk-ranking
    and 市场区
        Page->>API: GET /admin/market/overview
        Page->>API: GET /admin/market/price-trend
        Page->>API: GET /admin/market/top-hot-listings
    and 订单与部署区
        Page->>API: GET /admin/orders/overview
        Page->>API: GET /admin/orders/status-distribution
        Page->>API: GET /admin/deployments/runtime-distribution
    and 测算区
        Page->>API: GET /admin/benchmarks/overview
        Page->>API: GET /admin/benchmarks/failure-top
    and 风险与审计区
        Page->>API: GET /admin/risk/overview
        Page->>API: GET /admin/risk/runtime-events
        Page->>API: GET /admin/audit/timeline
    end

    API->>Cache: 读取快照或缓存
    Cache-->>API: 返回聚合结果
    API-->>Page: 分块返回 widget 数据
    Page-->>Admin: 渲染大屏

    Admin->>Page: 点击某个区块继续钻取
    Page->>API: 请求该区块的细分接口
    API-->>Page: 返回细分数据
```

## 4. 主成功流程

### 4.1 第 0 步：管理员打开 Dashboard 页面

**用户操作**

管理员点击后台入口，进入平台 dashboard。

**前端页面**

`AdminDashboardPage`

**前端行为**

- 页面先渲染 dashboard 骨架
- 每个大区块先显示独立 skeleton
- 不等待所有接口返回后再统一渲染

**实现效果**

- 页面可以快速出现布局
- 后续每个 widget 独立进入加载态

**下一步**

前端发起第一批并行请求。

### 4.2 第 1 步：前端并行请求顶部 KPI 和总览区

**用户操作**

管理员刚进入页面，无需额外点击。

**前端页面**

`AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/dashboard/kpi-summary`
  - `GET /admin/dashboard/platform-health`
  - `GET /admin/dashboard/platform-load`
  - `GET /admin/dashboard/resource-capacity`
  - `GET /admin/dashboard/resource-utilization-trend`

**请求示例**

```text
GET /admin/dashboard/kpi-summary?time_window=24h
GET /admin/dashboard/platform-health
GET /admin/dashboard/platform-load?time_window=1h&bucket=5m
GET /admin/dashboard/resource-capacity
GET /admin/dashboard/resource-utilization-trend?time_window=24h&bucket=30m
```

**响应 JSON 示例：`GET /admin/dashboard/kpi-summary`**

```json
{
  "generated_at": "2026-03-18T11:00:00Z",
  "items": [
    { "key": "total_users", "label": "总用户数", "value": 1280, "delta_24h": 38 },
    { "key": "online_compute_nodes", "label": "在线节点", "value": 136, "delta_24h": -2 },
    { "key": "running_orders", "label": "运行中订单", "value": 42, "delta_24h": 7 },
    { "key": "running_benchmark_jobs", "label": "运行中测算", "value": 8, "delta_24h": 1 },
    { "key": "open_runtime_events", "label": "未关闭异常", "value": 11, "delta_24h": 3 }
  ]
}
```

**响应 JSON 示例：`GET /admin/dashboard/platform-load`**

```json
{
  "generated_at": "2026-03-18T11:00:00Z",
  "time_window": "1h",
  "bucket": "5m",
  "summary": {
    "avg_cpu_load_pct": 61.3,
    "avg_memory_load_pct": 58.1,
    "avg_gpu_load_pct": 54.2
  },
  "series": [
    {
      "metric": "cpu_load_pct",
      "points": [
        { "ts": "2026-03-18T10:05:00Z", "value": 57.2 },
        { "ts": "2026-03-18T10:10:00Z", "value": 60.4 }
      ]
    }
  ]
}
```

**实现效果**

- 顶部数字翻牌有足够的数据源
- 平台健康卡、仪表盘、折线趋势图可以分别独立渲染
- 前端不需要从一个总览接口里自己切数据

**下一步**

节点区、市场区、订单区、测算区、风险区开始并行拉取。

### 4.3 第 2 步：前端请求节点监控区

**用户操作**

管理员观看节点区，不需要先点击。

**前端页面**

`AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/nodes/overview`
  - `GET /admin/nodes/status-distribution`
  - `GET /admin/nodes/load-matrix`
  - `GET /admin/nodes/top-cpu`
  - `GET /admin/nodes/top-memory`
  - `GET /admin/nodes/top-gpu`
  - `GET /admin/nodes/top-network-in`
  - `GET /admin/nodes/top-network-out`
  - `GET /admin/nodes/top-idle`
  - `GET /admin/nodes/risk-ranking`
  - `GET /admin/nodes/heartbeat-latency`

**请求示例**

```text
GET /admin/nodes/load-matrix?limit=100
GET /admin/nodes/top-cpu?limit=10
GET /admin/nodes/top-gpu?limit=10
GET /admin/nodes/risk-ranking?limit=10
GET /admin/nodes/heartbeat-latency?time_window=15m
```

**响应 JSON 示例：`GET /admin/nodes/load-matrix`**

```json
{
  "generated_at": "2026-03-18T11:00:00Z",
  "items": [
    {
      "compute_node_id": 101,
      "title": "RTX4090-01",
      "cpu_load_pct": 88.1,
      "memory_load_pct": 64.2,
      "gpu_load_pct": 91.5,
      "network_in_kbps": 2310,
      "network_out_kbps": 1988,
      "runtime_status": "online",
      "running_order_count": 1,
      "open_runtime_event_count": 0
    }
  ]
}
```

**实现效果**

- 前端可以做热力矩阵、节点卡片墙、Top 排行、风险排行
- 节点区和其他区完全解耦

**下一步**

如果管理员点击某个节点卡片，进入节点详情抽屉。

### 4.4 第 3 步：管理员点击节点卡片，打开详情抽屉

**用户操作**

管理员点击节点矩阵中的某一台节点。

**前端页面**

`AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/nodes/{node_id}/detail`

**请求示例**

```text
GET /admin/nodes/101/detail
```

**响应 JSON 示例**

```json
{
  "compute_node_id": 101,
  "title": "RTX4090-01",
  "seller_user_id": 3001,
  "runtime_status": "online",
  "last_heartbeat_at": "2026-03-18T10:59:50Z",
  "current_load": {
    "cpu_load_pct": 88.1,
    "memory_load_pct": 64.2,
    "gpu_load_pct": 91.5
  },
  "listing_summary": {
    "listing_id": 201,
    "listing_status": "listed",
    "current_price_hourly": 18.6
  },
  "runtime_summary": {
    "running_order_count": 1,
    "open_runtime_event_count": 0
  }
}
```

**实现效果**

- 前端可以做右侧抽屉、悬浮详情面板、节点小窗
- 不需要离开 dashboard 主页面

### 4.5 第 4 步：前端请求市场与价格区

**用户操作**

管理员继续查看市场和价格区域。

**前端页面**

`AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/market/overview`
  - `GET /admin/market/listing-status-distribution`
  - `GET /admin/market/gpu-distribution`
  - `GET /admin/market/cpu-tier-distribution`
  - `GET /admin/market/region-distribution`
  - `GET /admin/market/price-trend`
  - `GET /admin/market/top-hot-listings`
  - `GET /admin/market/top-expensive-listings`
  - `GET /admin/market/top-cheap-listings`

**响应 JSON 示例：`GET /admin/market/price-trend`**

```json
{
  "generated_at": "2026-03-18T11:00:00Z",
  "time_window": "7d",
  "series": [
    {
      "group_key": "RTX4090",
      "points": [
        { "ts": "2026-03-12T00:00:00Z", "avg_price_hourly": 17.8 },
        { "ts": "2026-03-13T00:00:00Z", "avg_price_hourly": 18.1 }
      ]
    }
  ]
}
```

**实现效果**

- 前端可以做价格趋势图、供给分布图、热门上架榜、高低价榜

### 4.6 第 5 步：前端请求订单与部署区

**用户操作**

管理员查看交易与运行态区域。

**前端页面**

`AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/orders/overview`
  - `GET /admin/orders/status-distribution`
  - `GET /admin/orders/create-trend`
  - `GET /admin/orders/release-type-distribution`
  - `GET /admin/orders/expiring-soon`
  - `GET /admin/orders/high-value`
  - `GET /admin/deployments/overview`
  - `GET /admin/deployments/runtime-distribution`
  - `GET /admin/deployments/web-entry-distribution`
  - `GET /admin/deployments/runtime-failure-top`

**响应 JSON 示例：`GET /admin/orders/status-distribution`**

```json
{
  "generated_at": "2026-03-18T11:00:00Z",
  "items": [
    { "status": "running", "count": 42 },
    { "status": "released", "count": 933 },
    { "status": "abnormal", "count": 17 },
    { "status": "refunded", "count": 9 }
  ]
}
```

**实现效果**

- 前端可以做状态环图、趋势图、到期预警表、高价值订单榜

### 4.7 第 6 步：前端请求 Benchmark 区

**用户操作**

管理员查看测算区域。

**前端页面**

`AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/benchmarks/overview`
  - `GET /admin/benchmarks/status-distribution`
  - `GET /admin/benchmarks/mode-distribution`
  - `GET /admin/benchmarks/source-type-distribution`
  - `GET /admin/benchmarks/duration-trend`
  - `GET /admin/benchmarks/failure-top`

**响应 JSON 示例：`GET /admin/benchmarks/failure-top`**

```json
{
  "generated_at": "2026-03-18T11:00:00Z",
  "items": [
    { "reason": "git_clone_failed", "count": 12 },
    { "reason": "benchmark_timeout", "count": 7 },
    { "reason": "entry_detection_failed", "count": 5 }
  ]
}
```

**实现效果**

- 前端可以做失败原因榜、模式分布图、输入来源分布图、耗时折线图

### 4.8 第 7 步：前端请求风险与审计区

**用户操作**

管理员查看风险滚动流和审计区。

**前端页面**

`AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/risk/overview`
  - `GET /admin/risk/runtime-events`
  - `GET /admin/risk/severity-distribution`
  - `GET /admin/risk/event-type-distribution`
  - `GET /admin/risk/refund-compensation-stats`
  - `GET /admin/risk/risk-nodes`
  - `GET /admin/audit/timeline`
  - `GET /admin/audit/action-type-distribution`
  - `GET /admin/audit/recent-admin-logins`

**请求示例**

```text
GET /admin/risk/runtime-events?severity=critical&limit=20
GET /admin/audit/timeline?limit=30
```

**响应 JSON 示例：`GET /admin/risk/runtime-events`**

```json
{
  "generated_at": "2026-03-18T11:00:00Z",
  "items": [
    {
      "runtime_event_id": 5001,
      "event_type": "node_offline",
      "severity": "critical",
      "event_status": "compensated",
      "compute_node_id": 101,
      "rental_order_id": 9001,
      "detected_at": "2026-03-18T10:30:08Z"
    }
  ]
}
```

**实现效果**

- 前端可以做滚动告警流、异常分布环图、风险节点榜、时间线瀑布流

### 4.9 第 8 步：Dashboard 周期刷新

**用户操作**

管理员停留在页面中，不进行额外操作。

**前端页面**

`AdminDashboardPage`

**前端刷新策略建议**

- 高频区块每 10 到 30 秒刷新：
  - `kpi-summary`
  - `platform-health`
  - `platform-load`
  - `risk/overview`
  - `risk/runtime-events`
- 中频区块每 30 到 60 秒刷新：
  - `nodes/load-matrix`
  - `market/overview`
  - `orders/overview`
  - `deployments/runtime-distribution`
  - `benchmarks/overview`
- 低频区块每 5 到 15 分钟刷新：
  - `market/price-trend`
  - `resource-utilization-trend`
  - `audit/timeline`

**实现效果**

- 页面具有明显的动态感
- 每个区块独立刷新，不需要整页重刷

## 5. 关键异常路径

### 5.1 快照存在延迟

**现象**

接口返回 `generated_at` 较旧。

**前端表现**

- 区块右上角显示“数据有延迟”
- 继续展示最近一次可用快照

### 5.2 某个 widget 接口失败

**现象**

例如 `GET /admin/nodes/top-gpu` 失败，但其他接口成功。

**前端表现**

- 只让对应区块进入错误态
- 其他区块继续渲染
- 区块内显示“点击重试”

### 5.3 管理员权限失效

**现象**

接口返回 401 或 403。

**前端表现**

- 停止后续轮询
- 跳转登录页或无权限页

### 5.4 某些接口没有数据

**现象**

例如当前没有运行中的 Benchmark 或没有未处理异常。

**前端表现**

- 区块显示空状态，不显示报错
- 允许前端做空态插画、静态网格或占位动画

## 6. 本流程对前端的直接结论

管理员 dashboard 不应只依赖一个大总览接口。  
更适合前端发挥的方式是：

1. 保留 `GET /admin/dashboard/overview` 作为首屏快速回显。
2. 每个视觉区块再有自己的细分接口。
3. 每个榜单、矩阵、趋势、时间线都可以独立请求。
4. 每个区块独立刷新、独立失败、独立重试。

这样前端就能更自由地做：

- 数字翻牌
- 负载仪表盘
- 节点热力矩阵
- GPU/CPU Top 榜
- 价格趋势图
- 风险滚动流
- 审计时间线
