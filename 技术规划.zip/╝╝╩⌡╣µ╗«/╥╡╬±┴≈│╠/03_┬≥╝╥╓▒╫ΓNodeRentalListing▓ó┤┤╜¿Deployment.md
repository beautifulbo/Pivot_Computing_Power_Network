# 03 买家直租 NodeRentalListing 并创建 Deployment

版本：V2.1
日期：2026-03-18

## 1. 文档目标

本文档只描述一件事：买家已经在 `ListingDetailPage` 看中了一个可租的 `NodeRentalListing`，现在直接下单，后端创建 `RentalOrder`，并继续创建 `Deployment`。

本文档不再重复解释整个平台背景，只固定 4 个前提：

1. 当前买家已经登录。
2. 当前 `NodeRentalListing` 已经存在，且详情页已打开。
3. Docker Swarm 的底层操作全部抽象到 `Swarm Adapter`，业务流程不直接展开更底层细节。
4. mock 钱包冻结、解冻、退款逻辑仍归属 `RentalOrder & Deployment` 模块，不在本流程里拆独立钱包流程。

## 2. 本流程涉及的前后端对象

### 2.1 前端页面

- `ListingDetailPage`
- `RentalOrderDetailPage`
- `RentalOrderListPage`

### 2.2 后端模块

- `Auth & Access`
- `NodeRentalListing Market`
- `PricingEngine`
- `RentalOrder & Deployment`
- `Swarm Adapter`

### 2.3 本流程使用的 HTTP 接口

| 接口 | 后端模块 | 作用 |
|---|---|---|
| `GET /market/listings/{listing_id}` | `NodeRentalListing Market` | 在下单失败后回刷详情状态 |
| `POST /rental-orders` | `RentalOrder & Deployment` | 创建租用订单并发起部署 |
| `GET /rental-orders/{order_id}` | `RentalOrder & Deployment` | 获取订单详情 |
| `GET /rental-orders/{order_id}/deployment` | `RentalOrder & Deployment` | 获取部署与运行状态 |
| `GET /rental-orders` | `RentalOrder & Deployment` | 获取买家自己的实例列表 |

## 3. 直租流程总览

```mermaid
sequenceDiagram
    actor Buyer as Buyer
    participant Detail as ListingDetailPage
    participant OrderAPI as RentalOrder & Deployment
    participant Market as NodeRentalListing Market
    participant Pricing as PricingEngine
    participant Swarm as Swarm Adapter
    participant OrderDetail as RentalOrderDetailPage
    participant OrderList as RentalOrderListPage

    Buyer->>Detail: 填写租用时长和运行参数
    Buyer->>Detail: 点击立即租用
    Detail->>OrderAPI: POST /rental-orders
    OrderAPI->>Market: 校验 listing 当前可租
    OrderAPI->>Pricing: 计算本次冻结金额（租期×单价）
    OrderAPI->>OrderAPI: 冻结 mock 余额并创建 RentalOrder
    OrderAPI->>OrderAPI: 创建 Deployment（设置 business_completed=TRUE）
    OrderAPI->>Swarm: 发起 runtime service 部署
    Swarm-->>OrderAPI: 返回部署结果或启动中状态
    OrderAPI-->>Detail: 返回 order_id 和预估费用范围
    Detail-->>Buyer: 跳转实例详情页
    OrderDetail->>OrderAPI: GET /rental-orders/{order_id}
    OrderDetail->>OrderAPI: GET /rental-orders/{order_id}/deployment
    OrderAPI-->>OrderDetail: 返回 running / starting / failed
    Buyer->>OrderList: 打开我的实例
    OrderList->>OrderAPI: GET /rental-orders
    OrderAPI-->>OrderList: 返回新创建订单
```

## 4. 主成功流程

### 4.1 第 0 步：买家停留在可租的详情页

**用户操作**

买家已经从市场列表进入 `ListingDetailPage`，并看到当前实例可租。

**前端页面**

`ListingDetailPage`

**本步页面上已经有的信息**

- `listing_id`
- `title`
- `current_price_hourly`
- `price_currency`
- `publish_status`
- `rentable_status`
- `min_duration_minutes`
- `max_duration_minutes`
- `default_duration_minutes`
- `image_policy`

**进入下一步的前提**

- `publish_status = listed`
- `rentable_status = rentable`
- 页面上的“立即租用”按钮可点击

### 4.2 第 1 步：买家填写直租参数

**用户操作**

买家在 `ListingDetailPage` 中填写或选择：

- 租用时长
- 镜像来源类型
- 模板镜像或自定义镜像
- 启动命令
- 环境变量
- 对外暴露端口

**前端页面**

`ListingDetailPage`

**前端本地校验**

前端先做不依赖后端的表单校验：

- `duration_minutes` 必须在页面允许范围内
- `image_source_type = template` 时必须选择 `template_image_id`
- `image_source_type = custom` 时必须填写 `custom_image`
- `start_command` 不能为空
- `env_vars` 必须是键值对数组
- `exposed_port` 如果填写则必须是合法端口

**实现效果**

- 校验通过后，前端解锁“立即租用”
- 页面本地根据 `current_price_hourly` 粗略展示“预计冻结金额”
- 这个前端展示金额只用于提示，后端仍然重新计算权威金额

**下一步**

买家点击“立即租用”。

### 4.3 第 2 步：前端提交创建订单请求

**用户操作**

买家点击“立即租用”按钮。

**前端页面**

`ListingDetailPage`

**后端模块与接口**

- `RentalOrder & Deployment`
  - `POST /rental-orders`

**请求 JSON 示例**

```json
{
  "listing_id": 201,
  "duration_minutes": 120,
  "image_source_type": "template",
  "template_image_id": 301,
  "custom_image": null,
  "start_command": "python main.py",
  "env_vars": [
    {
      "key": "APP_ENV",
      "value": "prod"
    }
  ],
  "exposed_port": 7860,
  "client_display_price_hourly": 18.6,
  "client_price_updated_at": "2026-03-17T22:31:35Z"
}
```

**后端内部处理顺序**

`RentalOrder & Deployment` 收到请求后，内部按以下顺序处理：

1. 调用 `Auth & Access` 识别当前买家身份。
2. **【加锁】** 调用 `NodeRentalListing Market` 使用行锁(SELECT FOR UPDATE)锁定 `listing_id`，检查是否存在、是否 `listed`、是否 `rentable`(Bug-03-04防止并发超售)。
3. 调用 `PricingEngine.calculate_runtime_total()` 根据当前平台价格和 `duration_minutes` 计算权威冻结金额。
4. 比较前端提交的 `client_display_price_hourly` 与当前价格快照；如果价格变化超过5%容忍度，则拒绝本次下单(Bug-03-01已解决：使用价格容忍度机制)。
5. **【事务开始】** 以下操作在同一数据库事务中执行(Bug-03-02保证原子性)：
6. 执行 `freeze_mock_balance()`，冻结余额。
7. 执行 `create_rental_order()`，创建 `RentalOrder`。
8. 执行 `create_deployment()`，创建 `Deployment` 记录。
9. **【事务提交】** 如果任一步骤失败，事务回滚，余额不会被冻结。
10. **【事务外】** 调用 `Swarm Adapter.deploy_runtime_service()`，请求创建运行实例。
11. 将部署结果写回 `Deployment`(如果失败，立即触发退款流程Bug-03-03)。

**成功响应 JSON 示例**

```json
{
  "rental_order": {
    "id": 9001,
    "order_no": "RO202603180001",
    "listing_id": 201,
    "compute_node_id": 101,
    "order_status": "pending_deploy",
    "payment_status": "frozen",
    "duration_minutes": 120,
    "unit_price_hourly": 18.6,
    "frozen_amount": 37.2,
    "created_at": "2026-03-18T09:15:00Z"
  },
  "deployment": {
    "id": 9101,
    "runtime_status": "starting",
    "access_url": null,
    "swarm_status": "service_creating"
  }
}
```

**实现效果**

- 页面拿到新的 `order_id`
- 订单已经创建
- mock 余额已经冻结
- `Deployment` 记录已经存在
- Swarm 侧运行实例可能还在启动中

**下一步**

前端立即跳转到 `RentalOrderDetailPage`。

### 4.4 第 3 步：前端跳转到实例详情页

**用户操作**

买家不需要再次点击任何按钮，页面自动跳转。

**前端页面**

- 当前页面：`ListingDetailPage`
- 目标页面：`RentalOrderDetailPage`

**前端路由行为**

```text
/buyer/rental-orders/9001
```

**实现效果**

- 买家从“下单页”进入“实例详情页”
- 页面顶部显示订单号、冻结金额、当前状态
- 详情页进入轮询状态，等待 `Deployment` 真正运行起来

**下一步**

`RentalOrderDetailPage` 拉取订单详情与部署状态。

### 4.5 第 4 步：实例详情页轮询订单详情和部署状态

**用户操作**

买家停留在 `RentalOrderDetailPage`，等待实例启动。

**前端页面**

`RentalOrderDetailPage`

**后端模块与接口**

- `RentalOrder & Deployment`
  - `GET /rental-orders/{order_id}`
  - `GET /rental-orders/{order_id}/deployment`

**请求示例**

```text
GET /rental-orders/9001
GET /rental-orders/9001/deployment
```

**订单响应示例**

```json
{
  "id": 9001,
  "order_no": "RO202603180001",
  "listing_id": 201,
  "listing_title": "RTX4090 x1 / 16C / 64GB / CN-SH",
  "order_status": "running",
  "payment_status": "frozen",
  "duration_minutes": 120,
  "unit_price_hourly": 18.6,
  "frozen_amount": 37.2,
  "created_at": "2026-03-18T09:15:00Z",
  "started_at": "2026-03-18T09:15:35Z",
  "expire_at": "2026-03-18T11:15:35Z"
}
```

**部署响应示例**

```json
{
  "id": 9101,
  "rental_order_id": 9001,
  "runtime_status": "running",
  "access_url": "https://runtime.platform.example.com/dpl_9101/",
  "container_image": "platform/python311-cuda:latest",
  "started_at": "2026-03-18T09:15:35Z",
  "last_runtime_sync_at": "2026-03-18T09:15:40Z"
}
```

**实现效果**

- 页面从 `starting` 切换到 `running`
- 页面显示容器访问入口
- 页面显示剩余时长、订单状态、部署状态
- 买家可以继续停留在详情页，或进入后续“控制台查看全部容器”流程

**下一步**

买家可以：

- 停留在当前页查看状态
- 进入后续流程 `04 买家在自己的控制台查看全部容器`

### 4.6 第 5 步：新订单出现在“我的实例”列表中

**用户操作**

买家打开自己的实例列表页。

**前端页面**

`RentalOrderListPage`

**后端模块与接口**

- `RentalOrder & Deployment`
  - `GET /rental-orders`

**请求示例**

```text
GET /rental-orders?limit=20&offset=0
```

**响应示例**

```json
{
  "items": [
    {
      "id": 9001,
      "order_no": "RO202603180001",
      "listing_title": "RTX4090 x1 / 16C / 64GB / CN-SH",
      "order_status": "running",
      "runtime_status": "running",
      "frozen_amount": 37.2,
      "created_at": "2026-03-18T09:15:00Z",
      "expire_at": "2026-03-18T11:15:35Z"
    }
  ],
  "total": 1
}
```

**实现效果**

- 买家在“我的实例”列表中能看到这次新租用的实例
- 该订单已经成为后续控制台管理入口

## 5. 关键异常分支

### 5.1 异常分支 A：表单本地校验失败

**触发点**

买家点击“立即租用”前，表单参数不完整或格式错误。

**前端页面**

`ListingDetailPage`

**前端效果**

- 直接在表单项下方显示错误
- 不发送 `POST /rental-orders`
- “立即租用”按钮保持禁用或提交后立即恢复

### 5.2 异常分支 B：提交时实例已经不可租

**触发点**

买家点下“立即租用”时，这条 `NodeRentalListing` 已被别人租走，或已经下架。

**接口**

- `POST /rental-orders`

**错误响应示例**

```json
{
  "error_code": "listing_not_rentable",
  "message": "listing is no longer rentable",
  "listing_status": {
    "publish_status": "listed",
    "rentable_status": "unavailable"
  }
}
```

**前端效果**

- 页面不跳转
- 详情页顶部显示业务错误提示
- “立即租用”按钮变为禁用
- 页面触发一次 `GET /market/listings/{listing_id}` 刷新详情状态

### 5.3 异常分支 C：价格已变化，前端显示价格过期

**触发点**

买家停留在详情页过久，当前平台价格已经刷新。

**接口**

- `POST /rental-orders`

**错误响应示例**

```json
{
  "error_code": "price_changed",
  "message": "listing price changed since detail page was loaded",
  "current_price_hourly": 19.4,
  "price_currency": "CNY",
  "price_updated_at": "2026-03-18T09:14:58Z"
}
```

**前端效果**

- 页面不跳转
- 详情页刷新显示新的单价
- 预计冻结金额重新计算
- 买家必须重新确认后才能再次点击“立即租用”

### 5.4 异常分支 D：余额不足

**触发点**

后端准备冻结金额时，mock 钱包可用余额不足。

**接口**

- `POST /rental-orders`

**错误响应示例**

```json
{
  "error_code": "insufficient_balance",
  "message": "available balance is not enough for this rental order",
  "available_balance": 20.0,
  "required_frozen_amount": 37.2,
  "price_currency": "CNY"
}
```

**前端效果**

- 页面不跳转
- 详情页显示“余额不足”
- 当前表单内容保留，不强制清空

### 5.5 异常分支 E：订单已创建，但实例仍在启动中

**触发点**

这是正常的异步状态，不算业务失败；只是 `Deployment` 还没真正进入 `running`。

**接口**

- `POST /rental-orders`
- `GET /rental-orders/{order_id}/deployment`

**响应特征**

```json
{
  "runtime_status": "starting",
  "access_url": null
}
```

**前端效果**

- 页面已经跳到 `RentalOrderDetailPage`
- 状态显示为“启动中”
- 轮询继续进行
- 连接入口区域显示骨架屏或“正在启动”

### 5.6 异常分支 F：订单已创建，但部署失败

**触发点**

`RentalOrder` 已经创建，冻结金额也已经成功，但 `Swarm Adapter` 返回部署失败。

**涉及接口**

- `POST /rental-orders`
- `GET /rental-orders/{order_id}`
- `GET /rental-orders/{order_id}/deployment`

**后端内部处理**(Bug-03-03)

1. **【立即执行】** 捕获`Swarm Adapter.deploy_runtime_service()`异常
2. **【立即执行】** 标记`Deployment.runtime_status = failed`
3. **【立即执行】** 标记`RentalOrder.order_status = failed`
4. **【立即执行】** 执行退款：解冻余额，更新`payment_status = refunded`
5. 记录失败原因到`Deployment.failure_reason`
6. 返回失败响应给前端

**详情页响应示例**

```json
{
  "id": 9001,
  "order_no": "RO202603180001",
  "order_status": "failed",
  "payment_status": "refunded",
  "frozen_amount": 37.2,
  "refund_amount": 37.2
}
```

```json
{
  "id": 9101,
  "runtime_status": "failed",
  "failure_reason": "runtime service creation failed"
}
```

**前端效果**

- 详情页显示“部署失败”
- 显示退款结果
- 不展示连接入口
- 允许买家返回市场重新选择其他实例

### 5.7 异常分支 G：前端请求超时，买家不确定是否下单成功

**触发点**

买家点击”立即租用”后，浏览器请求超时或网络中断，导致前端没有收到成功/失败响应。

**解决方案**(Bug-03-05)

- 前端生成唯一的`idempotency_key`并随请求发送
- 后端使用该key进行去重,相同key的重复请求返回相同结果
- 如果未提供key,后端检查5分钟内是否有相同listing_id+buyer_id的订单作为兜底

**前端页面**

`ListingDetailPage`

**前端效果**

- 页面进入”提交结果未知”状态
- 使用相同的`idempotency_key`重试,不会创建重复订单
- 页面提示买家前往”我的实例”检查是否已生成新订单

**恢复动作**

买家打开：

- `RentalOrderListPage`
- 调用 `GET /rental-orders?limit=20&offset=0`

如果列表中已经出现新订单，则继续进入详情页；如果没有，再允许买家重新发起租用。

## 6. 本文档结论

1. 直租流程的真正业务写入口只有一个：`POST /rental-orders`。
2. 订单创建时必须同时处理 4 件事：校验可租、计算权威价格、冻结余额、创建部署。
3. Docker Swarm 细节不应出现在业务流程里，业务层只通过 `Swarm Adapter.deploy_runtime_service()` 获得部署结果。
4. `RentalOrderDetailPage` 不能假设下单即运行成功，必须显式处理 `starting`、`running`、`failed` 三种部署结果。
5. “余额不足””价格变化””实例已不可租””请求结果未知”都必须在直租流程里有明确分支，否则前端交互会出现断层。

## 7. 释放与结算流程

### 7.1 释放触发方式

- **主动释放**：买家在 `RentalOrderDetailPage` 点击”释放”
- **自动到期**：系统定时任务检测 `expire_at` 并自动释放

### 7.2 结算公式

- **冻结金额**：`frozen_amount = (duration_minutes / 60) × unit_price_hourly`
- **实际费用**：`actual_amount = (actual_runtime_minutes / 60) × unit_price_hourly`
- **退款金额**：`refund_amount = frozen_amount - actual_amount`

### 7.3 结算时机

在 `Deployment` 释放完成后，系统自动：
1. 计算实际运行时长
2. 按实际时长结算费用
3. 退还多冻结的金额到可用余额
4. 设置 `order_status = released`

