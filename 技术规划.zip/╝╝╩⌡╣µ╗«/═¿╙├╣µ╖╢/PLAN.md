# 通用规范实施计划

## 1. 目录目标

本目录当前覆盖两类全局规范：

- 错误码与错误响应规范
- 时间格式与时区处理规范

这两类规范不属于任何单独业务模块，但会影响：

- 所有后端 API
- 所有前端页面
- 日志、审计、追踪
- 倒计时、轮询、剩余时长、时间线和管理员大盘展示

因此必须在项目最早阶段统一落地，而不是由各模块自行实现。

本目录中的 Mermaid 图和表格也必须被视为规范本体的一部分：

- Mermaid 图用于固定跨前后端的错误流、时间流、请求追踪流等统一方向
- 表格用于固定错误码映射、时间字段语义、时区规则、展示规范和测试矩阵

后续如果修改了错误响应结构、时间字段语义、trace_id 规则或前端展示规范，必须同步修改相关 Mermaid 图和表格，不能只改一段说明文字。

---

## 2. 当前项目中的建议实现位置

## 2.1 后端

建议统一放到：

- `../../Pivot_Computing_Power_Network/platform-backend/app/core/errors/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/core/time/`
- `../../Pivot_Computing_Power_Network/platform-backend/app/schemas/common.py`

## 2.2 前端

建议统一放到：

- `../../Pivot_Computing_Power_Network/platform-frontend/src/utils/platform-errors.js`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/utils/platform-datetime.js`
- `../../Pivot_Computing_Power_Network/platform-frontend/src/api/platform/client.js`

前端规范类实现同样必须遵守两条约束：

- 当前阶段优先落地到独立 `platform-frontend`，不要求为了旧门户兼容而保留双套错误处理和时间工具
- 页面侧使用这些公共能力时，仍需服从 `../前端/前端页面规划文档.md` 的页面职责与跳转边界
- 网络层与通用错误处理必须沉淀在 `src/api/platform/**`、`src/api/platform/client.js`、`src/utils/platform-*.js` 中，页面 UI 层不得自行复制一套请求和错误处理逻辑

---

## 3. 错误码规范实施方案

依据 [错误码规范.md](./错误码规范.md)，所有 API 错误响应必须统一为：

```json
{
  "success": false,
  "error_code": "ERR_4001",
  "message": "余额不足",
  "details": {},
  "timestamp": "2026-03-18T10:30:00+00:00"
}
```

## 3.1 后端实现要求

需要做：

- 定义统一错误码枚举
- 定义统一业务异常基类
- 定义 FastAPI 全局异常处理器
- 未知异常统一映射到系统错误
- API 成功响应与错误响应结构统一
- 成功响应必须能区分“空数据”和“错误”
- 所有响应都要带 `timestamp`
- 跨模块请求与日志统一带 `request_id / trace_id`

建议实现：

- `app/core/errors/codes.py`
- `app/core/errors/exceptions.py`
- `app/core/errors/handlers.py`
- `app/schemas/common.py`

## 3.2 前端实现要求

需要做：

- 定义错误码到中文提示的映射表
- 识别认证错误并触发重新登录
- 页面级错误与局部错误分层处理
- 将后端 `error_code` 作为唯一分支依据，不依赖临时文案
- 基于 `success` 字段区分空数据与失败
- 对 `ERR_2001` / 认证失效类错误走统一会话恢复流程

建议实现：

- `src/utils/platform-errors.js`
- `src/api/platform/client.js`
- `src/components/platform/PageErrorState.vue`

## 3.3 测试方法

- 后端 API 契约测试：所有错误响应字段齐全
- 枚举测试：错误码无重复
- 前端单元测试：错误码映射正确
- E2E：401 自动回登录、403 进入无权限页、业务错误展示正确

测试位置：

- `platform-backend/tests/api/test_error_contract.py`
- `platform-backend/tests/unit/test_error_code_uniqueness.py`
- `platform-frontend/src/__tests__/platform/error-mapping.spec.js`
- `platform-frontend/tests/e2e/platform-error-handling.spec.ts`

---

## 4. 时间格式规范实施方案

依据 [时间格式规范.md](./时间格式规范.md)，所有时间必须：

- 后端统一 UTC 存储和传输
- 前端统一转换为用户本地时区展示
- 使用 ISO 8601 作为传输格式

## 4.1 后端实现要求

需要做：

- 禁止使用无时区 `datetime`
- 统一使用 `datetime.now(timezone.utc)`
- 所有响应时间字段输出 ISO 8601 带时区
- 倒计时、剩余时长等基础字段尽量由后端提供原始秒数
- 订单、deployment、benchmark 等剩余时长统一输出 `remaining_seconds`

建议实现：

- `app/core/time/clock.py`
- `app/core/time/serializers.py`
- `app/core/time/constants.py`

## 4.2 前端实现要求

需要做：

- 创建统一时间格式化工具
- 自动识别浏览器时区
- 支持完整时间、相对时间、剩余时长、倒计时四类格式
- 所有页面统一使用同一格式化方法，禁止各页面手写时间拼接
- 倒计时优先基于服务器下发的 `remaining_seconds`，而不是本地自己推导 `expire_at - Date.now()`

建议实现：

- `src/utils/platform-datetime.js`
- `src/components/platform/TimeText.vue`
- `src/components/platform/CountdownText.vue`

## 4.3 测试方法

- 后端单元测试：UTC 时间生成与序列化
- 前端单元测试：不同时区下的格式化结果
- E2E：倒计时、剩余时长、本地时间显示正确
- 回归测试：管理员时间线、订单详情、benchmark 结果页时间显示一致

测试位置：

- `platform-backend/tests/unit/test_time_serialization.py`
- `platform-frontend/src/__tests__/platform/datetime.spec.js`
- `platform-frontend/tests/e2e/platform-time-display.spec.ts`

---

## 5. 推荐执行顺序

本目录规范必须在以下模块之前落地：

1. `Auth & Access`
2. `RentalOrder & Deployment`
3. `BenchmarkJob`
4. `Runtime Reconcile`
5. `Admin Dashboard`

原因：

- 这些模块都会直接依赖统一错误响应
- 它们都大量使用时间字段、倒计时、时区转换和日志时间

同时根据 `问题` 目录补充：

- `trace_id` 规范应与错误响应和日志规范一起实现，而不是后补
- 空数据与错误态区分要先于 Dashboard 和市场页联调落地

---

## 6. 完成标准

当以下条件满足时，可认为本目录规范已正式落地：

- 所有 API 错误响应结构完全一致
- 前端有统一错误码映射层
- 所有时间字段后端均为 UTC ISO 8601
- 前端所有页面通过统一工具格式化时间
- 倒计时和剩余时长计算可稳定复用
- 请求与日志可通过 `trace_id` 串起来
- 空数组与失败响应在前端表现不同

---

## 7. 当前阶段结论

本目录内容虽然少，但属于“全局硬规范”。如果不先落地，后续最容易出现：

- 接口错误结构不一致
- 前端错误提示到处特判
- 时区错乱
- 倒计时和剩余时长不准确
- 管理员时间线和用户页时间显示不一致

因此本目录应作为平台公共基础设施的一部分优先实现。
