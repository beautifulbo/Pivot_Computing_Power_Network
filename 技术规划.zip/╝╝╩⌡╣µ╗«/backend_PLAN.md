# backend_PLAN

版本：V1.0  
日期：2026-03-21

## 1. 文档目标

本文件用于指导当前项目的：

- 数据库搭建
- 底层框架搭建
- 后端主服务搭建
- worker / adapter / benchmark / dashboard 支撑层搭建

与总 `PLAN.md` 不同，这份文档只关心后端主线。  
当前阶段的执行口径也进一步收紧为：

- 先不构建真实前端
- 直接以 [REPORT.md](./前端/REPORT.md) 里的“虚拟前端”作为后端契约来源
- 后端优先实现虚拟前端要求的接口、状态、错误码、轮询兼容性和数据字段
- 每个阶段结束都必须建立检查点，方法与总 [PLAN.md](./PLAN.md) 一致

本文件是“后端与基础设施阶段实施手册”，不是产品说明书，也不是页面文档替代物。

---

## 2. 依据文档

本文件基于以下文档收敛：

- `技术规划/综述/00_全局总述文档.md`
- `技术规划/后端/` 下的模块文档和 `PLAN.md`
- `技术规划/底层框架+数据库/` 下的数据库、状态机、错误码相关文档和 `PLAN.md`
- `技术规划/通用规范/` 下的时间/错误规范和 `PLAN.md`
- `技术规划/前端/REPORT.md`

其中当前阶段最重要的 5 条约束是：

1. 平台卖的是“浏览器可访问运行环境”，不是 SSH 裸机器。
2. 卖家接入方式是 `bootstrap + register-self + 自动认领 + 自动生成 listing`。
3. `ComputeNode` 和 `NodeRentalListing` 必须分层。
4. 所有 Swarm 操作只能经由 `Swarm Adapter`。
5. 虚拟前端已经固定了后端需要提供的接口、字段、错误类型和轮询条件。

---

## 3. 当前执行口径

## 3.1 虚拟前端代替真实前端

当前阶段不要求先落地真实 `platform-frontend`。  
后端的“前端需求来源”统一改为：

- [REPORT.md](./前端/REPORT.md)

这意味着：

- 后端接口是否正确，不以页面是否已经写出来判断
- 后端接口是否正确，以虚拟前端要求的：
  - 页面入口
  - 页面动作
  - 接口路径
  - 最少字段
  - 状态集合
  - 错误类型
  - 轮询行为
  为验收标准

## 3.2 当前阶段先跳过真实前端构建

当前阶段可以先不做：

- 真实路由页面
- 真实组件实现
- 真实前端状态管理
- 真实前端 E2E

当前阶段必须先做：

- 数据库
- 迁移
- 统一响应与错误码
- 认证
- 节点接入
- listing 市场读写
- 订单与 deployment
- benchmark
- reconcile
- metrics / admin 读接口

## 3.3 阶段验收方式

每一阶段的验收，默认采用 4 组证据：

1. 自动化测试
2. 测试日志
3. 开发日志
4. 检查点快照

---

## 4. 虚拟前端驱动的后端范围

当前后端必须覆盖的虚拟前端页面与后端域映射如下：

| 虚拟页面 | 后端域 | 当前是否必须优先支持 |
|---|---|---|
| `AuthPage` | `Auth & Access` | 是 |
| `MarketListPage` | `NodeRentalListing Market` | 是 |
| `ListingDetailPage` | `Market + RentalOrder` | 是 |
| `RentalOrderListPage` | `RentalOrder` | 是 |
| `RentalOrderDetailPage` | `RentalOrder + Deployment + Runtime` | 是 |
| `SellerWorkbenchPage` | `ComputeNode + Seller Listings` | 是 |
| `ComputeNodeAccessGuidePage` | `ComputeNode Access` | 是 |
| `ComputeNodeBootstrapPage` | `ComputeNode Access + Swarm Adapter` | 是 |
| `ListingManagePage` | `Seller Listings + Pricing` | 是 |
| `BenchmarkSubmitPage` | `BenchmarkJob` | 是 |
| `BenchmarkResultPage` | `BenchmarkJob + Market` | 是 |
| `AdminDashboardPage` | `Metric Collector + Snapshot / Cache + Admin APIs` | 是，但可放最后 |
| `PortalPage` | `Portal Summary` | 否，可作为只读聚合增强 |
| 4 个系统页 | `错误码 / 维护态 / 权限态` | 是 |

因此当前后端不是只做“核心交易接口”，而是要做一整套可供虚拟前端消费的完整后端契约。

---

## 5. 后端总体设计原则

## 5.1 模块原则

- 只做模块化单体，不拆微服务
- `platform-backend` 提供主 API
- `platform-worker` 提供异步任务和巡检
- `platform-benchmark` 提供 benchmark 执行环境
- `Swarm Adapter` 是唯一 Swarm 操作入口

## 5.2 数据原则

- 数据库目标为 `MySQL 8`
- 迁移使用 `Alembic`
- 所有关键表必须有：
  - `created_at`
  - `updated_at`
  - `version`
- 所有时间统一 UTC 存储和传输
- 所有关键写路径都必须考虑：
  - 事务
  - 幂等
  - 并发冲突
  - 失败补偿

## 5.3 接口原则

- 所有 API 返回统一响应格式
- 所有错误返回统一 `error_code`
- 所有请求带 `request_id / trace_id`
- 接口字段命名和状态命名优先对齐 [REPORT.md](./前端/REPORT.md)

## 5.4 验收原则

- 以虚拟前端的接口和字段需求验收后端
- 以自动化测试验收每个阶段
- 以检查点固化每个阶段结果

---

## 6. 阶段依赖图

```mermaid
flowchart TD
    B0[阶段 B0<br/>公共基线] --> B1[阶段 B1<br/>数据库与迁移]
    B1 --> B2[阶段 B2<br/>认证与能力]
    B2 --> B3[阶段 B3<br/>Swarm基础契约与Adapter]
    B3 --> B4[阶段 B4<br/>节点接入 + Pricing + Seller Listing]
    B4 --> B5[阶段 B5<br/>市场只读接口]
    B5 --> B6[阶段 B6<br/>订单 + Deployment + Web Connect]
    B6 --> B7[阶段 B7<br/>BenchmarkJob]
    B6 --> B8[阶段 B8<br/>Runtime Reconcile]
    B8 --> B9[阶段 B9<br/>Metrics + Admin Dashboard]
```

说明：

- `B0-B6` 是必须优先完成的主链路
- `B7-B9` 建立在主链路事实数据之上
- 每个阶段完成后必须立即创建检查点，不能等到全部做完再回补

---

## 7. 阶段总表

| 阶段 | 目标 | 核心输出 | 对应虚拟前端 | 优先级 |
|---|---|---|---|---|
| `B0` | 公共基线 | 响应格式、错误码、时间规范、trace_id、测试骨架 | 全部 | P0 |
| `B1` | 数据库与迁移 | MySQL schema、Alembic、基础仓储 | 全部 | P0 |
| `B2` | 认证与能力 | `/auth/*`、能力模型、refresh token | `AuthPage` | P0 |
| `B3` | Swarm 契约与适配层 | Swarm Infra 契约、Mock/Real Adapter | `ComputeNodeBootstrapPage` | P0 |
| `B4` | 节点接入与卖家供给 | bootstrap session、register-self、auto listing、pricing | `SellerWorkbenchPage`、`ComputeNode*`、`ListingManagePage` | P0 |
| `B5` | 市场只读层 | listing filters/list/detail | `MarketListPage`、`ListingDetailPage` | P0 |
| `B6` | 交易与运行实例 | order、deployment、web-connect、release | `ListingDetailPage`、`RentalOrder*` | P0 |
| `B7` | Benchmark | 上传、job、recommendations | `Benchmark*` | P1 |
| `B8` | Runtime Reconcile | runtime events、巡检、异常写回 | `RentalOrderDetailPage` | P0 |
| `B9` | 指标与管理员大盘 | snapshot/cache、admin APIs | `AdminDashboardPage` | P1 |

---

## 8. 分阶段实施方案

## 8.1 阶段 B0：公共基线

### 直接参考计划

- 主参考：[通用规范/PLAN.md](./通用规范/PLAN.md)
- 主参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)
- 补充参考：[后端/PLAN.md](./后端/PLAN.md)
- 补充参考：[前端/REPORT.md](./前端/REPORT.md)

本阶段若与其他文档冲突，以 `通用规范/PLAN.md` 和 `底层框架+数据库/PLAN.md` 为准。

### 要做什么

- 建立 `platform-backend` / `platform-worker` 最小工程骨架
- 建立统一响应结构
- 建立统一错误码与异常处理
- 建立 UTC 时间工具
- 建立 `request_id / trace_id`
- 建立 pytest 测试骨架

### 如何执行

1. 创建：
   - `platform-backend/app/core/errors/`
   - `platform-backend/app/core/time/`
   - `platform-backend/app/middlewares/`
   - `platform-backend/app/schemas/common.py`
2. 定义成功响应和失败响应结构。
3. 接入全局异常处理器。
4. 统一用 UTC ISO 8601 输出时间。
5. 在请求链路中注入 `request_id`。
6. 建立 backend / worker 的基础 smoke 测试入口。

### 代码位置

- `platform-backend/app/core/errors/`
- `platform-backend/app/core/time/`
- `platform-backend/app/middlewares/`
- `platform-backend/app/schemas/common.py`
- `platform-backend/tests/`
- `platform-worker/tests/`

### 测试方法

- API 契约测试：
  - 成功响应结构一致
  - 失败响应结构一致
- 单元测试：
  - 错误码注册无重复
  - UTC 时间序列化正确
- smoke：
  - `/health` 返回成功
  - worker 能启动

### 测试位置

- `platform-backend/tests/api/test_common_response.py`
- `platform-backend/tests/api/test_error_contract.py`
- `platform-backend/tests/unit/test_error_code_uniqueness.py`
- `platform-backend/tests/unit/test_time_serialization.py`
- `platform-backend/tests/smoke/test_health.py`
- `platform-worker/tests/smoke/test_worker_boot.py`

### 完成标准

- 所有 API 都能返回统一结构
- 错误响应统一带 `error_code`
- 所有时间字段统一为 UTC ISO 8601
- 请求日志可串出 `request_id`

### 检查点

阶段完成后建立：

- `checkpoints/B0_pass_yyyyMMdd_HHmmss/`

并保存：

- `CHANGE.md`
- `code_snapshot/`
- `test_logs/`

---

## 8.2 阶段 B1：数据库与迁移

### 直接参考计划

- 主参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)
- 补充参考：[通用规范/PLAN.md](./通用规范/PLAN.md)
- 补充参考：[后端/PLAN.md](./后端/PLAN.md)
- 补充参考：[前端/REPORT.md](./前端/REPORT.md)

本阶段若与其他文档冲突，以 `底层框架+数据库/PLAN.md` 为准。

### 要做什么

- 将数据库设计文档落实为模型和迁移
- 建立 MySQL 8 + Alembic 迁移体系
- 落实体、索引、唯一键、外键、版本号
- 落 `refresh_tokens`、钱包流水、幂等键等基础表/基础能力

### 如何执行

1. 按数据域拆分模型文件：
   - users
   - compute_nodes
   - listings
   - orders
   - deployments
   - benchmark
   - runtime_events
   - metrics
2. 为关键表补：
   - `version`
   - 唯一键
   - 高查询索引
3. 初始化 Alembic。
4. 生成首批迁移并验证空库升级。
5. 加入测试库初始化和回滚流程。

### 代码位置

- `platform-backend/app/models/`
- `platform-backend/app/repositories/`
- `platform-backend/alembic/`
- `platform-backend/tests/integration/`

### 测试方法

- 迁移测试：
  - 空库升级到最新版本
  - 关键迁移可回滚
- schema 约束测试：
  - 唯一键
  - 外键
  - `version`
  - `swarm_node_id`
  - `idempotency_key`
- repository 测试：
  - 增删改查
  - 乐观锁冲突

### 测试位置

- `platform-backend/tests/integration/test_migrations.py`
- `platform-backend/tests/integration/test_schema_constraints.py`
- `platform-backend/tests/integration/test_repository_users.py`
- `platform-backend/tests/integration/test_repository_compute_nodes.py`
- `platform-backend/tests/integration/test_repository_orders.py`
- `platform-backend/tests/integration/test_idempotency.py`
- `platform-backend/tests/integration/test_optimistic_locking.py`

### 完成标准

- MySQL 模型与迁移可稳定运行
- 关键约束全部落库
- repository 层能支撑后续业务域开发

### 检查点

阶段完成后建立：

- `checkpoints/B1_pass_yyyyMMdd_HHmmss/`

---

## 8.3 阶段 B2：认证与能力

### 直接参考计划

- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[通用规范/PLAN.md](./通用规范/PLAN.md)
- 补充参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)
- 补充参考：[前端/REPORT.md](./前端/REPORT.md)

本阶段若与其他文档冲突，以 `后端/PLAN.md` 和 `通用规范/PLAN.md` 为准。

### 要做什么

- 实现：
  - `/auth/register`
  - `/auth/login`
  - `/auth/me`
  - `/auth/capabilities`
  - `/auth/logout`
- 实现 `access_token + refresh_token`
- 建 buyer / seller / admin 能力体系

### 如何执行

1. 建 `auth` 模块和 API。
2. 建 refresh token 持久化与轮换机制。
3. 建当前用户依赖注入。
4. 建能力判断和权限 guard。
5. 将 `AuthPage` 需要的字段固定输出。

### 代码位置

- `platform-backend/app/api/auth/`
- `platform-backend/app/modules/auth/`
- `platform-backend/app/repositories/user_repository.py`
- `platform-backend/app/repositories/token_repository.py`

### 测试方法

- API 测试：
  - 注册
  - 登录
  - 获取当前用户
  - 获取能力
  - 登出
  - 刷新
- 权限测试：
  - buyer/seller/admin 能力边界
- 安全测试：
  - token 过期
  - refresh 轮换
  - 旧 refresh token 作废

### 测试位置

- `platform-backend/tests/api/test_auth_flow.py`
- `platform-backend/tests/api/test_auth_capabilities.py`
- `platform-backend/tests/unit/test_access_guard.py`
- `platform-backend/tests/integration/test_refresh_token_rotation.py`

### 完成标准

- `AuthPage` 依赖的全部后端接口可用
- 401 / 403 语义稳定
- refresh token 可轮换、可撤销

### 检查点

阶段完成后建立：

- `checkpoints/B2_pass_yyyyMMdd_HHmmss/`

---

## 8.4 阶段 B3：Swarm 基础契约与 Adapter

### 直接参考计划

- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[复杂独立模块专项文档/PLAN.md](./复杂独立模块专项文档/PLAN.md)
- 补充参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)
- 补充参考：[前端/REPORT.md](./前端/REPORT.md)

本阶段若与其他文档冲突，以 `后端/PLAN.md` 和 `复杂独立模块专项文档/PLAN.md` 为准。

### 要做什么

- 固化 Swarm Infra 约束
- 建立 `Swarm Adapter` 抽象
- 提供 mock adapter
- 定义 real adapter 契约和异常映射

### 如何执行

1. 建 `contracts.py`、`schemas.py`、`exceptions.py`。
2. 抽象：
   - join token / join command
   - inspect node / service
   - label update
   - availability update
   - runtime service create/remove
   - benchmark service create/remove
3. 提供 mock provider。
4. 补统一 `SWARM_*` 错误码。

### 代码位置

- `platform-backend/app/integrations/swarm/`
- `platform-worker/app/integrations/swarm/`
- `tests/contracts/`

### 测试方法

- 契约测试：
  - mock 与 real adapter 返回结构一致
- 集成测试：
  - service 参数翻译
  - node inspect
- 故障测试：
  - node missing
  - node offline
  - label update failed
  - pending service

### 测试位置

- `platform-backend/tests/contracts/test_swarm_adapter_contract.py`
- `platform-backend/tests/integration/test_swarm_adapter_real_or_mock.py`
- `tests/contracts/test_swarm_infra_contract.py`

### 完成标准

- 业务域后续只依赖 adapter，不直接碰 Docker CLI/SDK
- mock 模式可支撑本地开发

### 检查点

阶段完成后建立：

- `checkpoints/B3_pass_yyyyMMdd_HHmmss/`

---

## 8.5 阶段 B4：节点接入、自动上架与定价

### 直接参考计划

- 主参考：[业务流程/PLAN.md](./业务流程/PLAN.md)
- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[前端/REPORT.md](./前端/REPORT.md)
- 补充参考：[复杂独立模块专项文档/PLAN.md](./复杂独立模块专项文档/PLAN.md)
- 补充参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)

本阶段若与其他文档冲突，以 `业务流程/PLAN.md`、`后端/PLAN.md` 和 `前端/REPORT.md` 为准。

### 要做什么

- 实现卖家节点接入主链路
- 自动认领 `ComputeNode`
- 自动生成 `NodeRentalListing`
- 自动生成平台价格
- 支撑虚拟前端的：
  - `SellerWorkbenchPage`
  - `ComputeNodeAccessGuidePage`
  - `ComputeNodeBootstrapPage`
  - `ListingManagePage`

### 如何执行

1. 实现：
   - `GET /seller/compute-nodes`
   - `GET /seller/compute-nodes/access-guide`
   - `POST /seller/compute-nodes/bootstrap-sessions`
   - `POST /seller/compute-nodes/register-self`
   - `GET /seller/compute-nodes/bootstrap-sessions/{session_id}`
   - `POST /seller/compute-nodes/{node_id}/sync`
2. 接入 bootstrap session 状态机。
3. 落 compute node 认领、重复注册幂等。
4. 接入 `PricingEngine` 生成初始价格。
5. 落卖家 listing 查询/详情/更新/上下架接口。

### 代码位置

- `platform-backend/app/api/seller/compute_nodes/`
- `platform-backend/app/api/seller/listings/`
- `platform-backend/app/modules/compute_nodes/`
- `platform-backend/app/modules/listings/`
- `platform-backend/app/modules/pricing/`
- `platform-worker/app/tasks/compute_nodes/`
- `platform-worker/app/tasks/pricing/`

### 测试方法

- API 测试：
  - bootstrap session 创建与查询
  - register-self
  - 卖家节点列表
  - 卖家 listing 列表/详情/更新/上下架
- 集成测试：
  - mock Swarm 接入成功后自动建 node 和 listing
  - 重复注册幂等
  - 跨卖家抢注拒绝
  - 节点已发现但价格待生成
- 单元测试：
  - bootstrap retry policy
  - 定价规则

### 测试位置

- `platform-backend/tests/api/test_compute_node_access_api.py`
- `platform-backend/tests/api/test_seller_listing_api.py`
- `platform-backend/tests/integration/test_register_self_flow.py`
- `platform-backend/tests/integration/test_compute_node_auto_listing.py`
- `platform-backend/tests/integration/test_listing_rentable_sync.py`
- `platform-backend/tests/unit/test_bootstrap_retry_policy.py`
- `platform-backend/tests/unit/test_pricing_service.py`

### 完成标准

- 卖家接入链路可从 session 创建走到 verified
- 新节点自动生成 listing 和价格
- 卖家工作台和 listing 管理页依赖的接口可用

### 检查点

阶段完成后建立：

- `checkpoints/B4_pass_yyyyMMdd_HHmmss/`

---

## 8.6 阶段 B5：市场只读接口

### 直接参考计划

- 主参考：[业务流程/PLAN.md](./业务流程/PLAN.md)
- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[前端/REPORT.md](./前端/REPORT.md)
- 补充参考：[复杂独立模块专项文档/PLAN.md](./复杂独立模块专项文档/PLAN.md)
- 补充参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)

本阶段若与其他文档冲突，以 `业务流程/PLAN.md`、`后端/PLAN.md` 和 `前端/REPORT.md` 为准。

### 要做什么

- 实现虚拟前端市场浏览和详情读取接口
- 支持筛选、排序、cursor 分页、价格 stale 标记

### 如何执行

1. 实现：
   - `GET /market/listings/filters`
   - `GET /market/listings`
   - `GET /market/listings/{listing_id}`
2. 将 listing 列表和筛选器解耦。
3. 返回虚拟前端要求的最少字段。
4. 对价格过期、节点离线、不可租状态做稳定表达。

### 代码位置

- `platform-backend/app/api/market/listings/`
- `platform-backend/app/modules/listings/`
- `platform-backend/app/modules/pricing/`
- `platform-backend/app/repositories/listing_repository.py`

### 测试方法

- API 测试：
  - filters
  - list
  - detail
  - search
  - sort
- 分页测试：
  - cursor 翻页无重复无遗漏
- 状态测试：
  - `publish_status`
  - `rentable_status`
  - `price_stale`

### 测试位置

- `platform-backend/tests/api/test_market_listing_api.py`
- `platform-backend/tests/api/test_market_listing_filters.py`
- `platform-backend/tests/integration/test_listing_cursor_pagination.py`
- `platform-backend/tests/integration/test_market_listing_status_cases.py`

### 完成标准

- `MarketListPage` 与 `ListingDetailPage` 的读接口完整可用
- 市场读接口可直接供虚拟前端消费

### 检查点

阶段完成后建立：

- `checkpoints/B5_pass_yyyyMMdd_HHmmss/`

---

## 8.7 阶段 B6：订单、Deployment、网页连接、释放

### 直接参考计划

- 主参考：[业务流程/PLAN.md](./业务流程/PLAN.md)
- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)
- 主参考：[前端/REPORT.md](./前端/REPORT.md)
- 补充参考：[通用规范/PLAN.md](./通用规范/PLAN.md)
- 补充参考：[复杂独立模块专项文档/PLAN.md](./复杂独立模块专项文档/PLAN.md)

本阶段若与其他文档冲突，以 `业务流程/PLAN.md`、`后端/PLAN.md`、`底层框架+数据库/PLAN.md` 和 `前端/REPORT.md` 为准。

### 要做什么

- 实现交易主链路
- 支撑虚拟前端：
  - `ListingDetailPage`
  - `RentalOrderListPage`
  - `RentalOrderDetailPage`

### 如何执行

1. 实现：
   - `POST /rental-orders`
   - `GET /rental-orders`
   - `GET /rental-orders/{order_id}`
   - `GET /rental-orders/{order_id}/deployment`
   - `POST /rental-orders/{order_id}/web-connect`
   - `POST /rental-orders/{order_id}/release`
2. 同一事务内完成：
   - listing 加锁
   - 余额冻结
   - 订单创建
   - deployment 记录创建
3. 事务外触发部署。
4. 部署失败立即退款。
5. 连接前实时校验 runtime 状态。
6. 返回 `remaining_seconds`、`web_entry_status`、`workspace_capabilities`。

### 代码位置

- `platform-backend/app/api/orders/`
- `platform-backend/app/modules/orders/`
- `platform-backend/app/modules/deployments/`
- `platform-backend/app/modules/wallet/`
- `platform-worker/app/tasks/orders/`

### 测试方法

- API 测试：
  - 下单成功
  - listing 不可租
  - 价格变化
  - 余额不足
  - 列表/详情
  - web-connect
  - release
- 集成测试：
  - 行锁防超售
  - 幂等下单
  - 部署失败退款
  - 释放后状态收敛
- 单元测试：
  - 订单状态机
  - deployment 状态机
  - 金额计算

### 测试位置

- `platform-backend/tests/api/test_rental_order_api.py`
- `platform-backend/tests/api/test_rental_order_console.py`
- `platform-backend/tests/integration/test_order_atomicity.py`
- `platform-backend/tests/integration/test_listing_locking.py`
- `platform-backend/tests/integration/test_order_refund_on_deploy_failure.py`
- `platform-backend/tests/unit/test_rental_order_state_machine.py`
- `platform-backend/tests/unit/test_deployment_state_machine.py`
- `platform-backend/tests/unit/test_order_billing.py`

### 完成标准

- 虚拟前端的下单、列表、详情、网页连接、释放链路全部可被后端支撑
- 订单与 deployment 状态可稳定轮询

### 检查点

阶段完成后建立：

- `checkpoints/B6_pass_yyyyMMdd_HHmmss/`

---

## 8.8 阶段 B7：BenchmarkJob

### 直接参考计划

- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[复杂独立模块专项文档/PLAN.md](./复杂独立模块专项文档/PLAN.md)
- 主参考：[前端/REPORT.md](./前端/REPORT.md)
- 补充参考：[业务流程/PLAN.md](./业务流程/PLAN.md)
- 补充参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)

本阶段若与其他文档冲突，以 `后端/PLAN.md`、`复杂独立模块专项文档/PLAN.md` 和 `前端/REPORT.md` 为准。

### 要做什么

- 支撑虚拟前端：
  - `BenchmarkSubmitPage`
  - `BenchmarkResultPage`
- 支持压缩包上传、git repository、job 状态查询、推荐读取

### 如何执行

1. 实现：
   - `POST /benchmark-jobs/code-archive-uploads`
   - `POST /benchmark-jobs`
   - `GET /benchmark-jobs/{job_id}`
   - `GET /benchmark-jobs/{job_id}/recommendations`
2. 落输入互斥校验。
3. 落 benchmark worker 调度。
4. 落 job 状态机和失败原因表达。
5. 推荐结果返回快照，并允许前端再查 listing 最新状态。

### 代码位置

- `platform-backend/app/api/benchmarks/`
- `platform-backend/app/modules/benchmark/`
- `platform-worker/app/tasks/benchmark/`
- `platform-benchmark/`

### 测试方法

- API 测试：
  - 上传 zip
  - 创建 job
  - 查询 job
  - recommendations
- 校验测试：
  - 输入源互斥
  - git url 合法性
  - 并发限制
- 异步测试：
  - benchmark 成功
  - benchmark 失败
  - timeout
  - 结果解析失败

### 测试位置

- `platform-backend/tests/api/test_benchmark_job_api.py`
- `platform-backend/tests/unit/test_benchmark_input_validation.py`
- `platform-worker/tests/integration/test_benchmark_task.py`
- `platform-worker/tests/integration/test_benchmark_task_failure_cases.py`
- `platform-benchmark/tests/test_workspace_prepare.py`
- `platform-benchmark/tests/test_result_export.py`

### 完成标准

- 虚拟前端 benchmark 提交和结果页依赖接口可用
- 推荐结果能与市场 listing 联动

### 检查点

阶段完成后建立：

- `checkpoints/B7_pass_yyyyMMdd_HHmmss/`

---

## 8.9 阶段 B8：Runtime Reconcile

### 直接参考计划

- 主参考：[复杂独立模块专项文档/PLAN.md](./复杂独立模块专项文档/PLAN.md)
- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[业务流程/PLAN.md](./业务流程/PLAN.md)
- 主参考：[前端/REPORT.md](./前端/REPORT.md)
- 补充参考：[底层框架+数据库/PLAN.md](./底层框架+数据库/PLAN.md)

本阶段若与其他文档冲突，以 `复杂独立模块专项文档/PLAN.md`、`后端/PLAN.md` 和 `业务流程/PLAN.md` 为准。

### 要做什么

- 落地运行态巡检与异常收敛
- 支撑虚拟前端订单详情页的异常摘要和轮询条件

### 如何执行

1. 建巡检任务，扫描：
   - `pending_deploy`
   - `running`
   - `releasing`
   - 以及相关 deployment 状态
2. 建 `RuntimeEvent`。
3. 建异常分类器。
4. 推进退款/补偿结果写回。
5. 对高风险异常设置人工介入标志。

### 代码位置

- `platform-worker/app/tasks/reconcile/`
- `platform-backend/app/application/reconcile/`
- `platform-backend/app/modules/runtime_events/`

### 测试方法

- 单元测试：
  - 异常分类器
  - 状态修正规则
- 集成测试：
  - 节点离线
  - service missing
  - 状态不一致
  - 重复巡检幂等
- 回归测试：
  - 异常事件不会无限新增

### 测试位置

- `platform-worker/tests/unit/test_reconcile_classifier.py`
- `platform-worker/tests/unit/test_reconcile_rules.py`
- `platform-worker/tests/integration/test_runtime_reconcile_job.py`
- `platform-backend/tests/integration/test_runtime_event_idempotency.py`

### 完成标准

- 订单详情页可稳定读取异常摘要
- reconcile 能把关键偏差写回后端事实

### 检查点

阶段完成后建立：

- `checkpoints/B8_pass_yyyyMMdd_HHmmss/`

---

## 8.10 阶段 B9：指标、快照、管理员大盘

### 直接参考计划

- 主参考：[后端/PLAN.md](./后端/PLAN.md)
- 主参考：[复杂独立模块专项文档/PLAN.md](./复杂独立模块专项文档/PLAN.md)
- 主参考：[业务流程/PLAN.md](./业务流程/PLAN.md)
- 主参考：[前端/REPORT.md](./前端/REPORT.md)
- 补充参考：[通用规范/PLAN.md](./通用规范/PLAN.md)

本阶段若与其他文档冲突，以 `后端/PLAN.md`、`复杂独立模块专项文档/PLAN.md`、`业务流程/PLAN.md` 和 `前端/REPORT.md` 为准。

### 要做什么

- 建指标快照与缓存支撑层
- 建管理员 dashboard 多区块只读接口
- 支撑虚拟前端 `AdminDashboardPage`

### 如何执行

1. 建：
   - summary builders
   - distribution builders
   - trend builders
   - ranking builders
   - timeline builders
2. 建 MySQL snapshot + Redis cache。
3. 按区块拆 admin API。
4. 节点详情接口走字段白名单。
5. 高频区块支持快照和缓存，不现场拼大 SQL。

### 代码位置

- `platform-backend/app/modules/metrics/`
- `platform-worker/app/tasks/metrics/`
- `platform-backend/app/modules/admin_dashboard/`
- `platform-backend/app/api/admin/`

### 测试方法

- 单元测试：
  - builder
  - 聚合器
- 集成测试：
  - 从事实表构建 snapshot
  - snapshot 一致性
- API 测试：
  - 各区块 overview/distribution/trend/ranking/timeline
  - admin 权限
  - `time_window <= 90d`

### 测试位置

- `platform-worker/tests/unit/test_metric_builders.py`
- `platform-worker/tests/integration/test_metric_snapshot_build.py`
- `platform-backend/tests/api/test_admin_dashboard_api.py`
- `platform-backend/tests/api/test_admin_guard.py`

### 完成标准

- `AdminDashboardPage` 所需区块接口可独立读取
- 快照时间点一致
- 管理员权限和字段白名单稳定

### 检查点

阶段完成后建立：

- `checkpoints/B9_pass_yyyyMMdd_HHmmss/`

---

## 9. 阶段检查点机制

本文件的阶段检查点机制，与总 [PLAN.md](./PLAN.md) 中的里程碑检查点机制一致，只是把“里程碑”替换为“阶段”。

## 9.1 检查点目录

统一放在：

- `../checkpoints/`

阶段命名建议：

- `B0_pass_20260321_160000`
- `B4_fail_20260322_101500`

## 9.2 每个阶段检查点必须包含

```text
checkpoints/
  B4_pass_20260322_101500/
    CHANGE.md
    code_snapshot/
    test_logs/
```

要求：

- `CHANGE.md`
  - 记录本阶段改了什么代码
  - 对应什么功能
  - 修改前是什么样
  - 修改后是什么样
- `code_snapshot/`
  - 保存该阶段修改后的代码副本
- `test_logs/`
  - 保存本阶段测试日志

## 9.3 建议命令

```powershell
$CheckpointRoot = "..\\checkpoints"
$Stage = "B4"
$Result = "pass"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$CheckpointDir = Join-Path $CheckpointRoot "${Stage}_${Result}_${Timestamp}"

New-Item -ItemType Directory -Force -Path $CheckpointDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $CheckpointDir "code_snapshot") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $CheckpointDir "test_logs") | Out-Null
New-Item -ItemType File -Force -Path (Join-Path $CheckpointDir "CHANGE.md") | Out-Null
```

推荐同时执行：

```powershell
git diff --name-only > (Join-Path $CheckpointDir "changed_files.txt")
```

## 9.4 额外要求

除检查点外，每个阶段完成后还应补：

- `../log/` 下的开发日志
- `../test_log/` 下的测试日志

---

## 10. 推荐测试矩阵

| 测试类型 | 必须覆盖内容 |
|---|---|
| 单元测试 | 状态机、builder、pricing、guard、错误码、时间工具 |
| API 测试 | 请求响应结构、错误码、权限、字段集合 |
| 集成测试 | MySQL、Redis、worker、adapter、事务、幂等、并发 |
| 契约测试 | Swarm adapter、错误响应、虚拟前端字段契约 |
| smoke | health、worker、迁移、最小流程 |

必须纳入长期回归的已知高风险点：

- token 自动刷新与轮换
- 重复节点注册与跨卖家抢注
- 价格 stale 标记
- cursor 分页一致性
- listing 并发超售
- 部署失败即时退款
- `idempotency_key` 重放
- `web-connect` 前实时容器校验
- benchmark 安全解压与超时
- reconcile 事件幂等
- admin 快照一致性与权限保护

---

## 11. 当前阶段的最小交付顺序

如果只追求后端尽快达到“可被虚拟前端消费”的状态，推荐最小交付顺序如下：

1. `B0`
2. `B1`
3. `B2`
4. `B3`
5. `B4`
6. `B5`
7. `B6`
8. `B8`

以上 8 个阶段完成后，虚拟前端主链路中的：

- 登录
- 卖家接入
- 市场浏览
- 详情查看
- 下单
- 详情轮询
- 网页连接
- 主动释放
- 运行态异常收敛

就都有了后端支撑。

然后再补：

9. `B7`
10. `B9`

---

## 12. 结论

当前项目的后端搭建，不应再被“先写真实前端页面”所阻塞。  
现在已经有了 [REPORT.md](./前端/REPORT.md) 这一份足够清晰的虚拟前端契约，因此后端完全可以先按契约落数据库、框架、模块、接口和测试。

这份 `backend_PLAN.md` 的核心要求只有三条：

1. 以后端和数据库先行为主，不等真实前端。
2. 以虚拟前端契约作为接口和字段验收标准。
3. 每个阶段结束后立即建立检查点，不允许只在最终阶段留档。
