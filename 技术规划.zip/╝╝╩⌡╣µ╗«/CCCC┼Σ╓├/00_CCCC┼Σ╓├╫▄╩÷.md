# CCCC 多智能体协作配置总述

版本：V1.0
日期：2026-03-18

## 1. 为什么在本项目中使用 CCCC

### 1.1 项目特点

本项目是一个**多技术栈、多模块、高复杂度**的算力交易平台，包含：

- **前端**：3 个独立前端项目（Vue2、React + Umi、Vue3）
- **后端**：FastAPI + 12 个业务模块
- **区块链**：FISCO BCOS 智能合约（Solidity）
- **基础设施**：Docker Swarm 集群管理
- **数据层**：MySQL + Redis + Celery

### 1.2 传统单 Agent 开发的痛点

1. **上下文切换频繁**：在前端、后端、合约、Docker 配置间跳转，单个 agent 容易混乱
2. **token 消耗巨大**：每次对话都要加载全部技术栈上下文
3. **专业性不足**：单个 agent 难以同时精通 Vue、FastAPI、Solidity、Docker Swarm
4. **并行开发困难**：前后端联调时，必须串行等待

### 1.3 CCCC 的价值

CCCC 让多个 agent 按**角色职能**协作，模拟真实软件团队：

- **Architect（架构师）**：分析任务、制定计划、分解子任务
- **Builder（构建者）**：实现代码（前端、后端、基础设施等所有技术栈）
- **Tester（测试者）**：运行测试、分析失败、验证功能
- **Reviewer（审查者）**：审查代码质量、决定是否合并
- **Scribe（文档记录者）**：更新 POR.md、记录决策、生成报告

这种划分方式符合 CCCC 的最佳实践，避免了按技术栈划分导致的职责模糊和重复工作。

## 2. CCCC 在本项目中的工作模式

### 2.1 核心工作流

```mermaid
sequenceDiagram
    participant User
    participant Architect
    participant Builder
    participant Tester
    participant Reviewer
    participant Scribe

    User->>Architect: 提交任务目标
    Architect->>Architect: 分析并制定计划
    Architect->>Scribe: 记录计划到 POR.md
    Architect->>Builder: 分配实现任务

    Builder->>Builder: 编写代码
    Builder->>Scribe: 报告进度
    Builder->>Tester: 提交代码

    Tester->>Tester: 运行测试
    alt 测试失败
        Tester->>Builder: 报告问题
    else 测试通过
        Tester->>Reviewer: 请求审查
    end

    Reviewer->>Reviewer: 审查代码
    alt 需要修改
        Reviewer->>Builder: 提出修改意见
    else 审查通过
        Reviewer->>Scribe: 批准合并
        Scribe->>User: 任务完成通知
    end
```

### 2.2 典型场景示例

**场景：实现"买家直租 NodeRentalListing 并创建 Deployment"功能**

1. **Architect** 接收目标并制定计划：
   - 阅读技术规划文档，理解业务流程
   - 分解为 3 个子任务：前端租用表单、后端订单 API、Swarm Adapter 部署接口
   - 识别依赖关系：前后端需要 API 契约，后端需要调用 Swarm Adapter
   - 在 POR.md 中记录计划

2. **Builder** 并行实现代码：
   - Builder-A：实现 Vue3 租用表单和支付流程
   - Builder-B：实现 FastAPI 订单 API 和状态机
   - Builder-C：实现 Swarm Adapter 的 `create_deployment()` 方法
   - 三个 Builder 独立工作，互不阻塞

3. **Tester** 验证功能：
   - 运行前端单元测试（Vitest）
   - 运行后端 API 测试（pytest）
   - 运行端到端测试（Playwright）
   - 发现问题反馈给 Builder 修复

4. **Reviewer** 审查代码：
   - 检查是否符合技术规划文档
   - 验证代码质量和安全性
   - 确认测试覆盖率达标
   - 批准合并

5. **Scribe** 记录完成：
   - 更新 POR.md 标记任务完成
   - 记录 API 契约到文档
   - 生成完成报告

## 3. 本项目的 CCCC 配置策略

### 3.1 Agent 角色划分

| Agent 角色 | 主要职责 | 技能要求 |
|-----------|---------|---------|
| **Architect** | 任务分析、计划制定、架构设计 | 理解技术规划文档、系统思维 |
| **Builder** | 代码实现（全技术栈） | Vue3/React、FastAPI、Docker、Solidity |
| **Tester** | 测试执行、问题分析 | pytest、Vitest、Playwright |
| **Reviewer** | 代码审查、质量把关 | 代码规范、安全审计、性能分析 |
| **Scribe** | 文档记录、进度跟踪 | POR.md 维护、报告生成 |

**关键原则**：
- Builder 可以启动多个实例并行工作（Builder-A、Builder-B、Builder-C）
- 每个 Builder 处理全技术栈，而非按前端/后端划分
- 角色间通过 ledger 通信，形成流水线式协作

### 3.2 工作窗口分配（tmux）

CCCC 使用 tmux 管理多个 agent 窗口：

```bash
# 会话名称：pivot-computing-power
tmux new-session -s pivot-computing-power

# 窗口 0: architect（架构师）
tmux rename-window -t 0 'architect'

# 窗口 1-3: builder（构建者，可并行）
tmux new-window -t pivot-computing-power -n 'builder-a'
tmux new-window -t pivot-computing-power -n 'builder-b'
tmux new-window -t pivot-computing-power -n 'builder-c'

# 窗口 4: tester（测试者）
tmux new-window -t pivot-computing-power -n 'tester'

# 窗口 5: reviewer（审查者）
tmux new-window -t pivot-computing-power -n 'reviewer'

# 窗口 6: scribe（文档记录者）
tmux new-window -t pivot-computing-power -n 'scribe'
```

### 3.3 持久化机制

CCCC 会在项目根目录创建：

```
Pivot_Computing_Power_Network/
├── .cccc/
│   ├── ledger.jsonl          # 所有 agent 消息与事件日志
│   ├── POR.md                 # Proof of Reality - 当前项目状态
│   ├── SUBPOR.md              # 子任务状态
│   └── config.yaml            # CCCC 配置文件
```

## 4. 与现有技术规划的集成

### 4.1 CCCC 如何使用现有文档

CCCC 的 Architect 会加载技术规划文档作为上下文：

- **Architect** 加载：
  - `技术规划/综述/00_全局总述文档.md`
  - `技术规划/业务流程/*.md`
  - `技术规划/后端/00_后端总述文档.md`
  - `技术规划/前端/00_前端详细页面总述.md`

- **Builder** 按需加载：
  - 实现前端时加载 `技术规划/前端/*.md`
  - 实现后端时加载 `技术规划/后端/*.md`
  - 实现基础设施时加载 `技术规划/复杂独立模块专项文档/Docker*.md`

- **Reviewer** 加载：
  - 相关模块的设计文档
  - 代码规范文档

### 4.2 POR.md 与技术规划的关系

- **技术规划文档**：设计阶段的蓝图（What & Why）
- **POR.md**：实现阶段的实时状态（What's Done & What's Next）

POR.md 会引用技术规划文档，但不替代它们。

## 5. 快速开始

### 5.1 初始化 CCCC

```bash
cd D:\AI\Pivot_Computing_Power_Network

# 初始化 CCCC
cccc init

# 定义项目目标
cccc goal "构建算力交易平台 MVP，实现 7 个核心业务场景"

# 定义约束
cccc constraint "遵循技术规划文档中的架构设计"
cccc constraint "Builder 处理全技术栈，不按前后端划分"
cccc constraint "所有 Docker 操作必须通过 Swarm Adapter"
```

### 5.2 启动 Agent 团队

```bash
# 启动 CCCC daemon
cccc start

# 查看 agent 状态
cccc status

# 打开 Web UI（默认 http://localhost:8080）
cccc ui
```

### 5.3 分配第一个任务

```bash
# 通过 CLI 分配任务
cccc task "实现卖家接入 ComputeNode 功能"

# Architect 会自动：
# 1. 阅读相关技术规划文档
# 2. 制定实现计划
# 3. 分解子任务并分配给 Builder
# 4. 在 POR.md 中记录计划
```

## 6. 为什么按角色而非技术栈划分？

### 6.1 错误方式：按技术栈划分

❌ **Frontend Agent + Backend Agent + DevOps Agent**

问题：
1. **职责模糊**：谁负责 API 契约？谁负责测试？谁负责审查？
2. **重复工作**：每个 agent 都要做规划、实现、测试、审查
3. **协调困难**：前后端需要频繁协商接口，容易冲突
4. **无法并行**：前端等后端，后端等基础设施
5. **不符合 CCCC 最佳实践**

### 6.2 正确方式：按角色划分

✅ **Architect + Builder + Tester + Reviewer + Scribe**

优势：
1. **职责清晰**：每个角色专注一件事
2. **流水线协作**：Architect → Builder → Tester → Reviewer，顺畅流转
3. **可并行扩展**：启动多个 Builder 并行实现不同子任务
4. **模拟真实团队**：符合软件工程实践
5. **符合 CCCC 设计理念**

### 6.3 参考资料

- [CCCC GitHub - Multi-agent Collaboration Kernel](https://github.com/ChesterRa/cccc)
- [CCCC Best Practices](https://cccc.ike.ba)
- [Multi-agent Orchestration Patterns](https://vertexaisearch.cloud.google.com/grounding-api-redirect/AUZIYQFICbT5EAnMYChk5S27Xwv1arKsJSaVLsmRyPGdTwB5QXhW77j4gXV-hSP7CJQK7S8xK4qlxc9qQ6uZ0WckIdyerxGHQOgELAUdzo3bd0390eXQpj_1FGfTE5xxcA==)

---

## 7. 下一步

阅读以下配置文档了解详细设置：

1. [01_Agent角色定义.md](./01_Agent角色定义.md) - 每个 agent 的详细职责与提示词
2. [02_工作流配置.md](./02_工作流配置.md) - 任务分解与协作规则
3. [03_技术栈映射.md](./03_技术栈映射.md) - Builder 如何处理多技术栈
4. [04_监控与调试.md](./04_监控与调试.md) - 如何监控 agent 工作状态
5. [05_最佳实践.md](./05_最佳实践.md) - 使用 CCCC 的经验总结
6. **[06_上下文管理与文档策略.md](./06_上下文管理与文档策略.md)** - 如何处理大量技术规划文档（重要）

## 8. 已创建的文件

```
.cccc/
├── POR.md                      # 项目状态记录
├── SUBPOR.md                   # 子任务跟踪
└── context/
    ├── index.md                # 文档索引
    ├── architecture.md         # 架构摘要
    └── decisions.md            # 关键决策记录
```
