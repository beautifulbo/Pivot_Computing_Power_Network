# Docker Swarm 与 Swarm Adapter 专项设计文档

版本：V1.4
日期：2026-03-18

## 1. 文档目的

本文件是算力交易平台的 Docker Swarm 与 `Swarm Adapter` 专项设计文档。

这份文档会比其他文档写得更“解释型”，原因很简单：当前团队成员大多没有接触过 Docker Swarm，如果直接从接口或代码开始设计，很容易在最基础的概念上理解错。

本文件重点回答以下问题：

1. Docker Swarm 到底是什么
2. `manager`、`worker`、`service`、`task`、`container` 分别是什么
3. 在本项目里，卖家节点、买家运行环境、AI 测算模块分别对应 Swarm 里的什么对象
4. 为什么必须做 `Swarm Adapter`
5. `Swarm Adapter` 应该封装哪些能力
6. 在当前 MVP 中，最合理、最简单的 Swarm 使用方式是什么

## 2. 先用人话理解 Docker Swarm

### 2.1 Docker Swarm 是什么

Docker Swarm 可以理解为 Docker 自带的一套“小型容器集群调度系统”。  
它把多台装了 Docker Engine 的机器组织成一个集群，由集群统一决定：

- 哪台机器能加入集群
- 哪个容器应该跑在哪台机器上
- 容器挂了之后要不要重建
- 某台节点下线后，系统怎么感知

对你们项目来说，Swarm 的作用不是“卖东西”，而是“让平台有能力把买家的运行任务调度到卖家的机器上”。

### 2.2 为什么选择 Docker Swarm

对于学生团队和比赛原型，Swarm 有几个现实优势：

- 比 Kubernetes 更轻量
- 学习成本相对更低
- 原生支持多节点、service、replica、placement constraint
- 适合快速做出“有调度能力”的原型

所以你们项目里，Swarm 更像是“底层容器编排引擎”，不是业务系统本身。

## 3. Swarm 核心概念说明

本节是最重要的入门部分。

### 3.1 Swarm

`Swarm` 是一组 Docker Engine 组成的集群。  
官方文档里明确说，Swarm 是由一个或多个运行 Docker Engine 的物理机或虚拟机构成的集群，其中节点分为 `manager` 和 `worker` 两类。[Docker Docs - How nodes work](https://docs.docker.com/engine/swarm/how-swarm-mode-works/nodes/)

### 3.2 Manager Node

`Manager Node` 是控制节点。  
它负责：

- 维护整个集群状态
- 接收和处理调度请求
- 决定 service 应该运行在哪里
- 对外暴露 Swarm 管理 API

官方文档说明，manager 负责维护集群状态、调度 services、提供 swarm mode API；并且多 manager 需要奇数个，主要是为了容错和 Raft 一致性。[Docker Docs - How nodes work](https://docs.docker.com/engine/swarm/how-swarm-mode-works/nodes/)

对你们项目的结论：

- `Swarm Manager` 必须由平台自己控制
- 卖家不能成为 manager
- 比赛 MVP 可以先用 1 个 manager，后续再扩展

### 3.3 Worker Node

`Worker Node` 是执行节点。  
它的职责只有一个：运行容器任务。

官方文档明确写到，worker node 的唯一目的就是执行容器；它不参与 Raft 状态维护、不做调度决策、也不提供 swarm mode HTTP API。[Docker Docs - How nodes work](https://docs.docker.com/engine/swarm/how-swarm-mode-works/nodes/)

对你们项目的结论：

- 卖家接入平台的机器，本质上是 `Swarm Worker`
- 买家的运行环境会被调度到某个卖家的 `Swarm Worker` 上

### 3.4 Service

`Service` 是“你希望系统长期维持的运行目标”。  
你不是直接让某台机器跑一个容器，而是向 Swarm 提交一个 service 定义，告诉它：

- 用哪个镜像
- 怎么启动
- 要几个副本
- 限制跑在哪些节点
- 需要多少资源

官方文档说明，部署应用时你创建的是 service；manager 接收 service 的“期望状态”，然后调度 task 去实现它。[Docker Docs - How services work](https://docs.docker.com/engine/swarm/how-swarm-mode-works/services/)

对你们项目的结论：

- 买家租用一个实例时，后端应创建一个 `runtime service`
- AI 测算任务发起时，后端应创建一个 `benchmark service`

### 3.5 Task

`Task` 是 Swarm 调度的最小单位。

官方文档明确指出，task 是 swarm 中调度的原子单位；每个 task 最终会启动一个 container；如果 task 失败，调度器会创建新的 task 来满足 service 的期望状态。[Docker Docs - How services work](https://docs.docker.com/engine/swarm/how-swarm-mode-works/services/)

对你们项目的结论：

- 真正落到某台卖家机器上运行的，是 task 对应的 container
- 业务层不应该直接围绕 task 建模，而应围绕 `Deployment` 建模

### 3.6 Container

`Container` 是实际运行的进程实例。  
在 Swarm 模型里，一个 task 对应一个 container。

所以业务上更准确的关系是：

- 用户买的是租用时长
- 后端创建的是 `Deployment`
- Swarm 接收到的是 `Service`
- Swarm 调度的是 `Task`
- 机器上真正跑起来的是 `Container`

### 3.7 Node Labels

`Node Labels` 是打在 Swarm 节点上的标签，用于调度约束。

官方文档说明，node label 可以作为组织节点和 service 约束的依据，而且这些 label 是通过 manager 执行 `docker node update --label-add` 写到 Swarm 节点对象上的。[Docker Docs - Manage nodes](https://docs.docker.com/engine/swarm/manage-nodes/)

对你们项目的结论：

- 平台应通过 manager 给节点打标签
- 不应完全信任卖家机器自己上报的标签
- 后续调度买家任务时，通过 label + constraint 把 service 定向放到目标节点

### 3.8 Placement Constraints

`Placement Constraints` 是 service 的调度限制条件。

官方文档说明，你可以通过 `--constraint` 要求 service 只运行在符合某些 node label 条件的节点上；如果没有满足条件的节点，task 会保持 `Pending`。[Docker Docs - Deploy services](https://docs.docker.com/engine/swarm/services/)

对你们项目的结论：

- 买家租用某个 `NodeRentalListing` 后，应该通过 constraint 把运行任务放到对应的 `ComputeNode`
- AI 测算任务应该通过 constraint 只调度到专用 benchmark 节点

### 3.9 Node Availability

Swarm 节点有可用性概念，比如：

- `active`
- `pause`
- `drain`

官方文档说明，`drain` 可用于维护时停止节点接收任务，`pause` 可阻止节点接收新任务，而原有状态可以恢复。[Docker Docs - Manage nodes](https://docs.docker.com/engine/swarm/manage-nodes/)

对你们项目的结论：

- 卖家节点出现问题时，可以通过 `drain` 或等效业务状态阻止继续接单
- 这比直接删除节点更安全

### 3.10 Join Token

Worker 加入 Swarm 需要 `join token`。

官方文档说明，worker token 和 manager token 不同，token 是敏感信息，不能泄露到版本控制中，并且建议定期轮换。[Docker Docs - Swarm mode](https://docs.docker.com/engine/swarm/swarm-mode/)

对你们项目的结论：

- 平台只给卖家展示 worker token
- 不给卖家 manager token
- token 不应长时间暴露在前端页面中
- 后续平台应支持 token 轮换

## 4. 在本项目里，Swarm 概念如何映射

### 4.1 概念映射表

| 项目概念 | Swarm 概念 | 说明 |
|---|---|---|
| 平台控制集群 | `Swarm Manager` | 平台自己维护的控制节点 |
| 卖家接入机器 | `Swarm Worker` | 卖家的 Docker 主机加入集群 |
| 卖家节点基础记录 | `ComputeNode` | 业务层记录，映射到一个 worker |
| 平台市场上架单元 | `NodeRentalListing` | 绑定一个 `ComputeNode` 的市场记录 |
| 买家租用后的运行记录 | `Deployment` | 对应一个 runtime service 的业务记录 |
| 买家运行环境 | `runtime service` | 由 `Swarm Adapter` 创建的 service |
| 买家实际容器 | `task/container` | service 被调度后的实际运行实例 |
| AI 测算任务 | `benchmark service` | 调度到专用 benchmark 节点的 service |

### 4.2 最重要的澄清

你们项目里最容易误解的点有两个：

#### 误解一：卖家节点本身就是商品

更准确的说法是：

- 卖家机器加入 Swarm 后成为一个 `Swarm Worker`
- 后端记录成一个 `ComputeNode`
- 平台基于这个 `ComputeNode` 生成一个 `NodeRentalListing`
- 买家真正租用的是 `NodeRentalListing`

所以：

- `ComputeNode` 是基础设施对象
- `NodeRentalListing` 是市场对象

#### 误解二：AI 测算模块是一个“worker docker”

这个说法不准确。

更准确的设计应该是：

- 平台有一台或一组专用 `Swarm Worker` 节点，专门用于 benchmark
- 每次测算时，后端创建一个 `benchmark service`
- 该 service 被调度到 benchmark 节点上

也就是说，AI 测算模块不应该被理解为“一个 Docker 容器充当 worker node”，而应该被理解为：

**一个平台控制的 benchmark 运行环境，由专用 worker 节点承载 benchmark service。**

### 4.3 卖家接入不应采用“本地 join + 网页手工登记”双重录入

从产品体验上看，如果卖家已经在本地执行了 `docker swarm join`，再回到网页手工填写一遍 `ComputeNode` 表单，会有两个明显问题：

1. 卖家重复操作
2. 平台状态和真实 Swarm 状态容易出现错位

因此更合理的方式是：

- 网页生成一次性 `bootstrap session`
- 卖家在本地执行一条 bootstrap 命令
- 本地脚本自动完成 `docker swarm join`
- 本地脚本自动调用平台的自注册接口
- 平台通过 `Swarm Adapter` 校验节点已加入，再自动认领节点并生成 `ComputeNode`
- 平台自动生成并自动上架 `NodeRentalListing`
- listing 标题、配置摘要、默认描述由后端自动生成

换句话说：

- 终端负责执行本地接入动作
- `Swarm Adapter` 负责校验和认领底层 worker
- `ComputeNode Access` 负责 bootstrap session、注册令牌和业务对象创建
- 前端只负责生成命令、显示状态、等待节点出现

## 5. 项目中 Swarm 的推荐使用方式

### 5.1 MVP 集群拓扑

对当前比赛版原型，推荐采用最简单且足够稳定的拓扑：

- 1 台平台控制的 `Swarm Manager`
- N 台卖家 `Swarm Worker`
- 1 台平台控制的 benchmark `Swarm Worker`

图示如下：

```mermaid
flowchart TB
    subgraph Platform[Platform Controlled]
        Manager[Swarm Manager]
        BenchNode[Benchmark Worker Node]
    end

    subgraph SellerSide[Seller Provided Workers]
        Worker1[Seller Worker A]
        Worker2[Seller Worker B]
        WorkerN[Seller Worker N]
    end

    Manager --> BenchNode
    Manager --> Worker1
    Manager --> Worker2
    Manager --> WorkerN
```

### 5.2 为什么 MVP 推荐 1 个 Manager

对于比赛原型，1 个 manager 的好处是：

- 结构简单
- 排错容易
- 团队理解成本低

缺点也要明确：

- manager 挂掉后，集群无法继续正常管理
- 虽然已有任务可能还在运行，但平台无法继续调度和恢复

因此：

- 比赛 MVP 可以接受 1 个 manager
- 但一定要把“单点风险”写进项目风险里

### 5.3 为什么 benchmark 节点要单独隔离

推荐单独准备 benchmark 节点，而不是跟卖家节点混跑，原因有 4 个：

- 避免 benchmark 容器影响卖家机器
- 避免买家任务和 benchmark 任务互相抢资源
- 便于通过 label 做调度隔离
- 便于后续统一清理 benchmark 运行环境

推荐给 benchmark 节点打标签：

- `node.labels.platform_role=benchmark`
- `node.labels.benchmark_enabled=true`

卖家节点则打：

- `node.labels.platform_role=seller`
- `node.labels.compute_node_id=<id>`
- `node.labels.seller_user_id=<id>`
- `node.labels.arch=x86_64`
- `node.labels.gpu_vendor=nvidia`

## 6. 业务流程里如何使用 Swarm

### 6.1 卖家接入流程

业务动作：

1. 卖家进入接入页
2. 后端创建 `bootstrap session`
3. 后端组合出本地执行命令
4. 卖家在本地执行 bootstrap 命令
5. 本地脚本自动执行 `docker swarm join`
6. 本地脚本自动调用平台注册接口
7. 平台通过 `Swarm Adapter` 校验该 worker 已加入
8. 平台把该 worker 认领为卖家名下 `ComputeNode`
9. 平台给该 node 写入业务标签
10. 平台自动生成 listing 元数据
11. 平台自动生成并自动上架 `NodeRentalListing`

流程图：

```mermaid
flowchart TD
    A[Seller opens access page] --> B[Backend creates bootstrap session]
    B --> C[Backend returns bootstrap command]
    C --> D[Seller runs bootstrap command locally]
    D --> E[Local script executes docker swarm join]
    E --> F[Local script calls register-self API]
    F --> G[Backend verifies worker exists in Swarm]
    G --> H[Backend claims ComputeNode ownership]
    H --> I[Backend writes trusted node labels]
    I --> J[Backend builds listing metadata]
    J --> K[Backend auto publishes NodeRentalListing]
```

### 6.2 买家租用流程

业务动作：

1. 买家选择 `NodeRentalListing`
2. 后端创建 `RentalOrder`
3. 后端创建 `Deployment`
4. `Swarm Adapter` 创建 runtime service
5. service 使用 placement constraint 指向目标节点
6. Swarm 调度出 task
7. task 启动一个 container

流程图：

```mermaid
flowchart TD
    A[Buyer creates RentalOrder] --> B[Backend creates Deployment]
    B --> C[Swarm Adapter creates runtime service]
    C --> D[Service uses placement constraints]
    D --> E[Manager schedules task]
    E --> F[Worker starts container]
    F --> G[Backend stores service and runtime status]
```

### 6.3 买家释放流程

业务动作：

1. 买家点击释放
2. 后端查到对应的 runtime service
3. `Swarm Adapter` 请求停止并删除 service
4. Swarm 停止对应 task/container
5. 后端更新 `Deployment` 和 `RentalOrder`

### 6.4 Benchmark 测算流程

业务动作：

1. 买家提交 `BenchmarkJob`
2. 后端创建 benchmark service
3. service 使用 benchmark 节点约束
4. benchmark 容器执行固定提示词逻辑
5. 容器输出结果
6. 后端读取结果并更新任务状态
7. 后端删除 benchmark service

## 7. 为什么必须有 Swarm Adapter

### 7.1 不做 Adapter 会出现什么问题

如果没有 `Swarm Adapter`，会马上出现这几个问题：

- 每个业务模块都要自己理解 Docker Swarm
- 每个业务模块都要自己拼 Docker 命令或 SDK 调用
- 错误处理不统一
- 返回结果格式不统一
- 后续从 CLI 换成 SDK 或从 SDK 换成 CLI 会大面积返工

更严重的是，业务层会直接和底层编排耦合，团队成员一旦没搞清楚 Swarm 概念，就会把业务状态和底层状态写乱。

### 7.2 Adapter 的定位

`Swarm Adapter` 的正确定位是：

**一个后端基础适配层，把业务请求翻译为 Docker Swarm 操作，并把 Swarm 返回结果翻译为业务可理解的统一结果。**

换句话说：

- 业务模块只说“我要部署一个运行实例”
- `Swarm Adapter` 负责真正调用 Swarm
- 业务模块不接触 Docker CLI / SDK 细节

### 7.3 Adapter 的边界

`Swarm Adapter` 负责：

- join token 获取
- worker join 命令组装
- 节点查询
- 节点接入后的存在性校验
- 节点标签维护
- runtime service 创建、查询、停止、删除
- benchmark service 创建、查询、删除
- 节点 availability 设置

`Swarm Adapter` 不负责：

- 生成 bootstrap session
- 生成 registration token
- 判断这个新 worker 属于哪个 seller 账号
- 判断某个 listing 是否可租
- 判断某个订单是否应该退款
- 生成价格
- 解析买家业务状态

这些仍然属于业务模块职责。

## 8. Swarm Adapter 专项设计

### 8.1 推荐内部结构

建议 `Swarm Adapter` 内部拆成 4 层：

```mermaid
flowchart TB
    A[Business Modules] --> B[SwarmFacadeService]
    B --> C[SwarmCommandService]
    C --> D[Docker SDK / CLI Wrapper]
    D --> E[Docker Swarm]
```

含义如下：

- `SwarmFacadeService`
  - 面向业务模块
  - 提供稳定的业务化方法名

- `SwarmCommandService`
  - 负责把业务参数翻译成 Docker 操作参数

- `Docker SDK / CLI Wrapper`
  - 负责真正执行命令或 SDK 调用

- `Docker Swarm`
  - 实际底层运行时

### 8.2 推荐对外暴露的内部接口

建议 `Swarm Adapter` 对其他后端模块暴露以下内部接口：

#### 节点类

- `get_worker_join_command()`
- `inspect_swarm_node_by_id(swarm_node_id)`
  - **注意**：节点加入Swarm是异步过程，存在1-5秒延迟。调用方应实现重试机制
- `list_swarm_nodes()`
- `inspect_swarm_node(swarm_node_id)`
- `find_swarm_node_by_hostname(hostname)`
- `claim_swarm_node_labels(swarm_node_id, labels)`
- `update_swarm_node_labels(swarm_node_id, labels)`
- `set_node_availability(swarm_node_id, availability)`

#### runtime service 类

- `create_runtime_service(payload)`
- `inspect_runtime_service(service_id)`
- `inspect_runtime_service_web_entry(service_id)`
- `list_runtime_services(filters)`
- `stop_runtime_service(service_id)`
- `remove_runtime_service(service_id)`

#### benchmark service 类

- `create_benchmark_service(payload)`
- `inspect_benchmark_service(service_id)`
- `remove_benchmark_service(service_id)`

#### 通用辅助类

- `build_node_constraints(label_map)`
- `normalize_service_status(raw_status)`
- `normalize_node_status(raw_status)`

### 8.3 bootstrap 与自注册的职责边界

推荐把职责边界固定成下面这样：

- `ComputeNode Access`
  - 创建 `bootstrap session`
  - 下发短时 `registration token`
  - 提供 `POST /seller/compute-nodes/register-self`
  - 创建 `ComputeNode`
  - 创建初始 `NodeRentalListing`
- `Swarm Adapter`
  - 获取 join token
  - 组装 join command
  - 校验 `swarm_node_id` 是否真实存在
  - 给 node 写入可信标签

也就是说：

`Swarm Adapter` 负责“底层 worker 是不是真的加入了”，  
`ComputeNode Access` 负责“这个 worker 在业务上属于哪个 seller，以及何时自动生成并自动上架 listing”。

### 8.4 卖家本地自注册建议输入结构

推荐本地 bootstrap 脚本调用 `POST /seller/compute-nodes/register-self` 时，至少传以下结构：

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "registration_token": "reg_6f14ca0b",
  "swarm_node_id": "2k2x5j7l8abcde1234567890f",
  "swarm_hostname": "seller-gpu-01",
  "hardware_profile": {
    "cpu_model": "AMD Ryzen 9 7950X",
    "cpu_cores": 16,
    "memory_mb": 65536,
    "gpu_vendor": "NVIDIA",
    "gpu_model": "RTX 4090",
    "gpu_count": 1,
    "gpu_memory_mb": 24576,
    "bandwidth_mbps": 300
  }
}
```

返回结构建议至少包含：

```json
{
  "bootstrap_session_id": "bss_20260317_0001",
  "status": "verified",
  "compute_node_id": 101,
  "listing_id": 201
}
```

### 8.5 runtime service 推荐输入结构

建议业务层传给 `Swarm Adapter` 的 `runtime service payload` 至少包括：

- `service_name`
- `image`
- `command`
- `env`
- `mounts`
- `network_name`
- `target_compute_node_id`
- `resource_limits`
- `resource_reservations`
- `exposed_ports`
- `web_entry_enabled`
- `primary_web_port`

Adapter 再把 `target_compute_node_id` 翻译成真正的 node label constraint，例如：

- `node.labels.compute_node_id == 123`

### 8.5.1 网页访问入口约定

- 买家在网页里点击“连接容器”，不应理解为浏览器直连卖家 `Worker` 主机。
- 更合理的模式是：浏览器访问平台的 `Runtime Web Gateway`，再由网关反向代理到目标 `runtime service` 的主网页入口。
- `Swarm Adapter` 只负责确认 `runtime service` 当前是否在运行，以及返回它声明的网页入口端口信息。
- 订单归属校验、短时 `connect_url` 签发、连接过期控制，应由 `RentalOrder & Deployment` 模块配合 `Runtime Web Gateway` 完成，不应塞进 `Swarm Adapter`。
- 推荐顺序是：
  1. `RentalOrder & Deployment` 先校验当前买家确实拥有该订单；
  2. 再调用 `Swarm Adapter.inspect_runtime_service()` 或 `inspect_runtime_service_web_entry()` 确认 `runtime_status = running` 且存在主网页入口；
  3. 然后生成短时有效的 `connect_url`；
  4. 最后由前端使用这个 `connect_url` 打开新标签页或嵌入连接面板。

### 8.6 benchmark service 推荐输入结构

建议 `benchmark service payload` 至少包括：

- `service_name`
- `image`
- `command`
- `env`
- `mounts`
- `job_id`
- `timeout_seconds`
- `input_manifest_path`
- `result_output_path`

并强制加上 benchmark 节点约束，例如：

- `node.labels.platform_role == benchmark`

**资源限制配置**：

```python
benchmark_service_config = {
    'resources': {
        'limits': {
            'cpus': '2.0',
            'memory': '4G'
        },
        'reservations': {
            'cpus': '1.0',
            'memory': '2G'
        }
    }
}
```

**安全配置**：

```python
security_config = {
    'cap_drop': ['ALL'],
    'security_opt': ['no-new-privileges'],
    'networks': ['benchmark_isolated']
}
```

### 8.6.1 Benchmark 输入源边界

- 买家在前端可以用两种方式发起测算：
  - 上传完整代码压缩包
  - 提供 `git clone` 链接
- 但 `Swarm Adapter` 不应直接理解前端上传令牌或业务表单字段。
- 更合理的边界是：`BenchmarkJob` 模块先把输入来源整理成一个统一的 `benchmark input manifest`，再把这个 manifest 路径交给 `create_benchmark_service(payload)`。
- 也就是说：
  - `BenchmarkJob` 负责：上传文件、校验 git 地址、生成 manifest
  - `Swarm Adapter` 负责：把 manifest 挂进 benchmark 容器，并创建 benchmark service
- 推荐的 manifest 结构如下：

```json
{
  "source_type": "code_archive",
  "archive_path": "/shared/benchmark/uploads/upload_abc_001.zip",
  "git_clone_url": null,
  "git_ref": null,
  "entry_hint": "backend/app.py",
  "expected_project_type": "web_service",
  "notes": "prefer conservative estimate"
}
```

```json
{
  "source_type": "git_repository",
  "archive_path": null,
  "git_clone_url": "https://github.com/example/demo-app.git",
  "git_ref": "main",
  "entry_hint": "server/index.js",
  "expected_project_type": "web_service",
  "notes": "benchmark from public repository"
}
```

- benchmark 容器读取 manifest 后：
  - 如果 `source_type = code_archive`，就解压压缩包进入工作区；
  - 如果 `source_type = git_repository`，就执行 `git clone`，必要时 checkout 到指定 `git_ref`。

### 8.6.2 Runtime Reconcile 巡检边界

- `Runtime Reconcile` 是后端异常巡检模块，但它不应直接调用 Docker CLI 或 SDK。
- 它对 Swarm 的所有读取和控制都必须经过 `Swarm Adapter`。
- 巡检链路中最常用的 `Swarm Adapter` 方法应固定为：
  - `inspect_swarm_node_by_id(swarm_node_id)`
  - `inspect_runtime_service(service_id)`
  - `set_node_availability(swarm_node_id, availability)`
  - `remove_runtime_service(service_id)`，仅用于已确认异常后的最佳努力清理
- 推荐的职责划分是：
  - `Swarm Adapter` 负责返回标准化 node / service 状态
  - `Runtime Reconcile` 负责把这些状态解释为 `node_offline`、`deployment_lost`、`state_mismatch`
  - `RentalOrder & Deployment` 负责写入订单、部署、退款和补偿结果
- `Swarm Adapter` 不应直接决定：
  - 订单是否退款
  - 事件是否升级为 `RuntimeEvent`
  - 买家页面应该显示什么文案

推荐给 `Runtime Reconcile` 的标准化返回结构如下：

```json
{
  "success": true,
  "node": {
    "swarm_node_id": "node_seller_101",
    "availability": "active",
    "status": "down"
  },
  "runtime_service": {
    "service_id": "svc_runtime_9101",
    "desired_state": "running",
    "status": "missing",
    "task_status": "not_found"
  },
  "message": "node offline and runtime service missing",
  "raw": {}
}
```

推荐的巡检顺序是：

1. `Runtime Reconcile` 先加载本轮巡检目标
2. 对每个目标调用 `inspect_swarm_node_by_id()` 和 `inspect_runtime_service()`
3. 如果节点确认异常，可调用 `set_node_availability(..., drain)` 阻止新任务继续调度
4. 把标准化结果交给业务层做异常分类与补偿决策

这里的重点是：

**`Swarm Adapter` 负责“看见真实 Swarm 状态”，`Runtime Reconcile` 负责“把真实状态翻译成业务异常”。**

### 8.7 Adapter 返回值规范

建议 `Swarm Adapter` 不直接把 Docker 原始返回值暴露给业务层，而统一返回标准结果对象：

```json
{
  "success": true,
  "resource_type": "runtime_service",
  "resource_id": "service_xxx",
  "status": "running",
  "node_id": "swarm_node_xxx",
  "web_entry": {
    "enabled": true,
    "primary_web_port": 7860
  },
  "message": "ok",
  "raw": {}
}
```

这样做的好处是：

- 业务模块不需要理解 Docker 原始对象
- 后续切换 CLI / SDK 不影响上层
- 异常处理可以统一

### 8.8 Adapter 错误码建议

建议 `Swarm Adapter` 至少规范这几类错误：

- `SWARM_NODE_NOT_FOUND`
- `SWARM_NODE_NOT_READY`
- `SWARM_NODE_CLAIM_FAILED`
- `SWARM_NODE_OFFLINE`
- `SWARM_SERVICE_PENDING`
- `SWARM_SERVICE_CREATE_FAILED`
- `SWARM_SERVICE_MISSING`
- `SWARM_SERVICE_REMOVE_FAILED`
- `SWARM_BENCHMARK_TIMEOUT`
- `SWARM_LABEL_UPDATE_FAILED`

业务模块不要直接解析 Docker 原始错误字符串。

## 9. 推荐的调度策略

### 9.1 买家 runtime service 调度策略

当前 MVP 推荐：

- 每个 `RentalOrder` 创建一个 `replicated service`
- `replicas = 1`
- 使用 `placement constraints` 限定目标节点

为什么不用 global service：

- global service 是在所有满足条件的节点上都跑
- 你们的租用实例是“一单一实例”，显然不适合 global mode

官方文档说明，Swarm 支持 `replicated` 和 `global` 两种 service 模式；global 会在每个符合条件的节点上都跑一个 task。[Docker Docs - Deploy services](https://docs.docker.com/engine/swarm/services/)

因此本项目结论是：

- 买家运行实例：`replicated service + 1 replica`
- benchmark 任务：`replicated service + 1 replica`
- 监控或 agent 类：未来可考虑 `global service`

### 9.2 卖家节点选择策略

MVP 推荐先不做自动最优调度，而是：

- 买家在市场里选定一个 `NodeRentalListing`
- 后端直接把 runtime service 放到该 listing 绑定的 `ComputeNode`

这和你们“按时长租机器”的业务模型是一致的，也最容易理解。

### 9.3 节点维护策略

出现以下情况时，建议把节点设置为不可继续接单：

- 节点离线
- 节点心跳超时
- 节点正在维护
- 节点出现异常释放事件

技术上可以结合：

- 业务层把 listing 标记为不可租
- Swarm 层把 node 设为 `pause` 或 `drain`

## 10. 推荐的数据映射关系

建议业务表和 Swarm 数据建立如下映射：

| 业务对象 | Swarm 对象 | 说明 |
|---|---|---|
| `ComputeNode.swarm_node_id` | `docker node id` | 节点映射主键 |
| `Deployment.swarm_service_id` | `docker service id` | 运行实例映射 |
| `Deployment.swarm_task_id` | `docker task id` | 当前 task 快照 |
| `BenchmarkJob` | benchmark service | 测算任务映射 |

后端不要把整个 Docker 原始对象直接存库，而是只存：

- 业务真正需要的关键字段
- 原始对象必要的快照 JSON

## 11. 团队容易踩坑的点

### 11.1 不要让卖家成为 manager

这是最重要的一条。  
manager 控制整个集群；卖家如果能成为 manager，就等于能参与平台控制面。

### 11.2 不要把业务逻辑写进 Swarm Adapter

`Swarm Adapter` 只做适配，不做业务决策。  
它不是订单模块，也不是定价模块。

### 11.3 不要把 `Service` 和 `Container` 混为一谈

在 Swarm 里，业务应优先围绕 service 进行控制，因为 task/container 是更底层的运行实例。

### 11.4 不要信任卖家自己打的标签

重要调度标签应该由平台 manager 写入 node labels。  
官方文档也强调 node labels 属于 swarm 节点对象，不要和 daemon labels 混淆。[Docker Docs - Manage nodes](https://docs.docker.com/engine/swarm/manage-nodes/)

### 11.5 不要把 join token 放进仓库或长期前端暴露

官方文档明确提示 join token 是敏感信息，不应泄露到版本控制中，并建议定期轮换。[Docker Docs - Swarm mode](https://docs.docker.com/engine/swarm/swarm-mode/)

### 11.6 不要误以为 service 一定能马上运行

如果没有节点满足约束或资源要求，service 可能进入 `pending`。  
官方文档明确说明了这种情况。[Docker Docs - How services work](https://docs.docker.com/engine/swarm/how-swarm-mode-works/services/)

对业务的意义是：

- `Deployment` 不应只区分“成功/失败”
- 还要有“pending / starting / running / failed”这类状态

## 12. 设计建议总结

如果把这份文档压缩成最重要的 8 条建议，就是：

1. 平台自己控制 `Swarm Manager`，卖家只做 `Swarm Worker`
2. 卖家节点在业务上是 `ComputeNode`，市场上卖的是 `NodeRentalListing`
3. 买家租用实例时，后端创建 `replicated service`，副本数为 1
4. 调度时通过 `node labels + placement constraints` 指向目标节点
5. benchmark 使用专用 worker 节点，不与卖家节点混跑
6. 所有 Docker Swarm 操作都必须通过 `Swarm Adapter`
7. `Swarm Adapter` 只做底层适配，不做业务决策
8. MVP 先用 1 manager + N seller workers + 1 benchmark worker 的简单拓扑

## 13. 官方资料参考

以下为本文件依赖的官方 Docker 文档：

- How nodes work  
  https://docs.docker.com/engine/swarm/how-swarm-mode-works/nodes/

- How services work  
  https://docs.docker.com/engine/swarm/how-swarm-mode-works/services/

- Manage nodes in a swarm  
  https://docs.docker.com/engine/swarm/manage-nodes/

- Deploy services to a swarm  
  https://docs.docker.com/engine/swarm/services/

- Run Docker Engine in swarm mode  
  https://docs.docker.com/engine/swarm/swarm-mode/
