# 管理员模块与 Admin Dashboard 专项设计文档

版本：V1.3
日期：2026-03-18

## 1. 文档目的

本文件用于单独定义平台的管理员模块和 `Admin Dashboard`。

这份文档的目标不是只做一个“后台列表页”，而是明确设计出一个：

- 管理员可独立访问
- 数据量足够大
- 指标维度足够细
- 同时适合日常运维和炫酷大屏展示

的后台可视化模块。

## 2. 模块定位

`Admin Dashboard` 是平台的只读聚合模块。

它的职责不是直接改业务主状态，而是：

1. 汇总平台全局运行数据
2. 展示节点、租赁、测算、异常、价格、活跃度等多维指标
3. 给管理员提供钻取入口
4. 给前端提供足够丰富的图表数据源

并且默认遵守一条读取原则：

**总览页和大屏接口默认读取 `Metric Snapshot / Cache`，而不是在页面打开时现场拼大 SQL。**

它应当与买家端、卖家端完全隔离，使用独立入口、独立权限、独立布局。

## 3. 设计目标

管理员模块应同时满足 4 个目标：

### 3.1 运维可读

管理员可以快速看出：

- 当前平台是否健康
- 哪些节点在线或异常
- 哪些订单正在运行
- 哪些部署已丢失
- 哪些测算任务失败

### 3.2 数据丰富

页面中要能看到大量指标，而不是只有几张简单表格。

建议至少覆盖：

- 平台总量指标
- 资源供给指标
- 平台平均负载
- 单机负载
- 上架与租用指标
- Benchmark 指标
- 异常与风险指标
- 审计时间线

### 3.3 大屏友好

前端应能拿到：

- 总览指标
- 趋势数据
- 排名数据
- 热力矩阵数据
- 状态分布数据
- 时间线数据

这样才方便做大屏视觉表现，例如：

- KPI 数字翻牌
- 折线/面积图
- 柱状排行图
- 节点热力矩阵
- 状态环图
- 活动流时间轴

### 3.4 先 Mock 再 Real

管理员模块也必须兼容平台整体的 `mock|real` 推进策略。

也就是说：

- 前端大屏可以先吃到结构完整的数据
- 后端可先返回占位聚合结果
- 后续再逐项切换为真实采集和真实聚合

## 4. 管理员前端区域规划

建议管理员前端不是单一页面，而是一个后台区域。

```mermaid
flowchart LR
    Login[Admin Login]
    Overview[Admin Dashboard Overview]
    Nodes[ComputeNode Monitor]
    Market[Listing & Pricing Monitor]
    Orders[RentalOrder & Deployment Monitor]
    Benchmark[Benchmark Monitor]
    Risk[Risk & Runtime Event Center]
    Audit[Audit Timeline]

    Login --> Overview
    Overview --> Nodes
    Overview --> Market
    Overview --> Orders
    Overview --> Benchmark
    Overview --> Risk
    Overview --> Audit
```

推荐页面如下：

1. `AdminLoginPage`
2. `AdminDashboardOverviewPage`
3. `AdminNodeMonitorPage`
4. `AdminMarketMonitorPage`
5. `AdminOrderDeploymentPage`
6. `AdminBenchmarkMonitorPage`
7. `AdminRiskEventCenterPage`
8. `AdminAuditTimelinePage`

其中最核心的是 `AdminDashboardOverviewPage`，它负责承接大部分可视化组件。

## 5. Dashboard 总览页分区

建议首页拆成 8 个可视化分区。

```mermaid
flowchart TB
    A[KPI Summary Bar]
    B[Platform Load Overview]
    C[Node Health Matrix]
    D[Market & Pricing Zone]
    E[Order & Deployment Zone]
    F[Benchmark Zone]
    G[Risk Event Zone]
    H[Audit Timeline Zone]

    A --> B
    A --> C
    A --> D
    A --> E
    A --> F
    A --> G
    A --> H
```

### 5.1 KPI Summary Bar

用于顶部大数字展示，适合做翻牌和滚动统计。

建议指标：

- 平台注册总用户数
- 平台总买家数
- 平台总卖家数
- 已接入 `ComputeNode` 总数
- 在线节点数
- 离线节点数
- 已上架 `NodeRentalListing` 总数
- 当前可租节点数
- 当前运行中订单数
- 今日新建订单数
- 今日已完成订单数
- 今日异常订单数
- 当前运行中 `BenchmarkJob` 数
- 今日测算任务总数

### 5.2 Platform Load Overview

这是平台整体资源负载概览，适合折线图、堆叠面积图、仪表盘。

建议指标：

- 全平台 CPU 平均负载
- 全平台 CPU 峰值负载
- 全平台内存平均负载
- 全平台内存峰值负载
- 全平台 GPU 平均负载
- 全平台 GPU 峰值负载
- 全平台可用 CPU 总量
- 全平台可用内存总量
- 全平台 GPU 总卡数
- 当前被占用的 GPU 数
- 当前空闲 GPU 数
- 全平台资源利用率

### 5.3 Node Health Matrix

这是单机维度监控区，适合做热力矩阵、节点卡片墙、排行条图。

建议指标：

- 单机 CPU 当前负载
- 单机 CPU 5 分钟平均负载
- 单机内存当前占用
- 单机 GPU 当前占用
- 单机网络入流量
- 单机网络出流量
- 单机磁盘占用率
- 单机最后心跳时间
- 单机在线时长
- 单机当前运行订单数
- 单机异常事件数

推荐额外排名：

- CPU 最高负载 Top 10 节点
- 内存最高负载 Top 10 节点
- GPU 最高负载 Top 10 节点
- 异常最多 Top 10 节点
- 最空闲 Top 10 节点

### 5.4 Market & Pricing Zone

这一块用于展示市场供给和价格波动。

建议指标：

- 上架总数
- 当前可租上架数
- 当前已租出上架数
- 已下架上架数
- 按 CPU 档位的上架数量分布
- 按 GPU 型号的上架数量分布
- 平台平均时长租赁价格
- 不同 GPU 型号的平均价格
- 价格更新时间
- 价格变化趋势
- 当前最热门上架记录 Top 10
- 当前价格最高/最低的上架记录

### 5.5 Order & Deployment Zone

这一块用于展示交易和运行态。

建议指标：

- 订单总数
- 当前运行中订单数
- 已释放订单数
- 异常释放订单数
- 自动释放订单数
- 手动释放订单数
- 平均租用时长
- 即将到期订单数
- 当前 `Deployment` 总数
- `Deployment` 运行中数量
- `Deployment` 丢失数量
- `Deployment` 同步异常数量

推荐图表：

- 订单状态分布环图
- 运行态分布柱图
- 订单创建趋势图
- 释放类型占比图

### 5.6 Benchmark Zone

这一块用于展示 AI 测算模块运行情况。

建议指标：

- `BenchmarkJob` 总数
- 今日测算任务数
- 当前排队中任务数
- 当前运行中任务数
- 测算成功数
- 测算失败数
- 平均测算耗时
- 占位模式任务数
- 真实运行模式任务数
- 推荐结果生成成功率
- 高频失败原因 Top N

### 5.7 Risk Event Zone

这一块用于展示异常和风险。

建议指标：

- `runtime_events` 总数
- 当前未处理异常数
- 严重异常数
- 节点离线事件数
- 容器丢失事件数
- 状态不一致事件数
- 自动补偿次数
- 退款次数
- 连续异常节点数

推荐组件：

- 严重异常滚动列表
- 异常类型占比
- 节点风险热区图
- 最近 24 小时异常趋势

### 5.8 Audit Timeline Zone

这一块用于展示平台操作流。

建议数据：

- 用户注册
- 节点接入
- 节点上架
- 节点下架
- 订单创建
- 部署启动
- 部署释放
- Benchmark 任务提交
- Benchmark 任务完成
- 异常事件创建
- 异常补偿完成
- 管理员登录

这个区域适合做时间线、流式列表、活动瀑布流。

## 6. 数据来源分层

管理员模块不要直接把所有表拼在页面上，而应明确分成 3 层数据来源。

```mermaid
flowchart LR
    Source[Business Source Data]
    Collector[Metric Collector]
    Snapshot[Metric Snapshot / Cache]
    Dashboard[Admin Dashboard]

    Source --> Collector
    Collector --> Snapshot
    Snapshot --> Dashboard
```

### 6.1 Business Source Data

来自业务事实表和运行态采集：

- `users`
- `compute_nodes`
- `node_rental_listings`
- `listing_price_snapshots`
- `rental_orders`
- `deployments`
- `benchmark_jobs`
- `runtime_events`
- `activity_logs`

### 6.2 Metric Collector

建议新增一个内部聚合层，专门负责：

- 聚合全平台统计
- 计算平台平均负载
- 计算单机负载
- 计算趋势序列
- 生成排行数据
- 生成热力矩阵数据

### 6.3 Metric Snapshot / Cache

为了让大屏刷新流畅，建议引入缓存或快照层。

可选方式：

- Redis 缓存
- MySQL 快照表
- 后端内存缓存

建议至少区分：

- 实时指标缓存
- 趋势指标缓存
- 排行指标缓存

### 6.4 Dashboard Read Path Rule

管理员前端请求应当遵守以下读取规则：

1. `AdminDashboardOverviewPage` 默认只读快照或缓存
2. 大屏模式默认只读快照或缓存
3. 趋势图、排行图、热力矩阵默认只读聚合结果
4. 只有“节点详情”“订单详情”“事件详情”这类强过滤、强分页页面，才允许有限度回查事实表

也就是说：

- 重聚合在后台做
- 页面请求只拿现成结果
- 详情查询才做小范围 SQL

这样可以避免：

- 页面一打开就跑多表聚合
- 多个管理员同时打开页面时拖垮数据库
- 前端大屏高频刷新导致数据库压力飙升

## 7. 建议补充的聚合数据表

如果后续要让 Dashboard 真正稳定输出大量统计数据，建议额外补 4 张聚合表。

### 7.1 `platform_metric_snapshots`

用于保存平台总体指标快照。

建议字段：

- `id`
- `snapshot_time`
- `total_users`
- `total_buyers`
- `total_sellers`
- `total_compute_nodes`
- `online_compute_nodes`
- `offline_compute_nodes`
- `total_listings`
- `rentable_listings`
- `running_orders`
- `running_deployments`
- `running_benchmark_jobs`
- `avg_cpu_load_pct`
- `avg_memory_load_pct`
- `avg_gpu_load_pct`

### 7.2 `compute_node_metric_snapshots`

用于保存单机负载快照。

建议字段：

- `id`
- `compute_node_id`
- `snapshot_time`
- `cpu_load_pct`
- `memory_load_pct`
- `gpu_load_pct`
- `network_in_kbps`
- `network_out_kbps`
- `disk_usage_pct`
- `running_order_count`
- `runtime_event_count`

### 7.3 `market_metric_snapshots`

用于保存市场和价格聚合结果。

建议字段：

- `id`
- `snapshot_time`
- `avg_listing_price_hourly`
- `listed_count`
- `rentable_count`
- `rented_count`
- `off_shelf_count`
- `gpu_listing_count_json`
- `cpu_tier_count_json`
- `top_hot_listing_ids_json`

### 7.4 `benchmark_metric_snapshots`

用于保存测算模块聚合结果。

建议字段：

- `id`
- `snapshot_time`
- `queued_jobs`
- `running_jobs`
- `succeeded_jobs`
- `failed_jobs`
- `placeholder_mode_jobs`
- `runtime_mode_jobs`
- `avg_duration_seconds`
- `top_failure_reasons_json`

### 7.5 建议的 Collector 刷新任务

建议给 `Metric Collector` 配置固定刷新任务：

- `refresh_platform_overview_metrics_job()`
- `refresh_compute_node_load_matrix_job()`
- `refresh_market_pricing_metrics_job()`
- `refresh_order_deployment_metrics_job()`
- `refresh_benchmark_metrics_job()`
- `refresh_risk_event_metrics_job()`
- `refresh_activity_timeline_cache_job()`

建议职责分工如下：

- 高频任务：刷新在线节点、运行订单、平台平均负载、未处理异常
- 中频任务：刷新单机矩阵、市场价格聚合、订单状态分布、Benchmark 状态分布
- 低频任务：刷新趋势图、历史排行、审计时间线归档

## 8. 数据更新频率建议

为了前端既炫酷又不卡，建议按数据类型设置不同刷新频率。

### 8.1 高频刷新，5-10 秒

适用于：

- 在线节点数
- 当前运行订单数
- 当前运行部署数
- 当前运行 Benchmark 数
- 异常未处理数量
- 平台平均负载

### 8.2 中频刷新，30-60 秒

适用于：

- 单机负载矩阵
- 热门节点排行
- 市场可租数量
- 价格聚合
- 部署状态分布

### 8.3 低频刷新，5-15 分钟

适用于：

- 趋势图
- 历史统计
- 日累计指标
- 周期价格趋势
- 审计时间线归档

## 9. 管理员模块交互关系

```mermaid
flowchart LR
    Frontend[Admin Frontend]
    AdminAPI[Admin Dashboard Module]
    Auth[Auth Module]
    Collector[Metric Collector]
    Node[ComputeNode Module]
    Listing[NodeRentalListing Module]
    Pricing[PricingEngine]
    Order[RentalOrder & Deployment Module]
    Benchmark[BenchmarkJob Module]
    Reconcile[Runtime Reconcile]
    Store[Metric Snapshot / Cache]

    Frontend --> AdminAPI
    AdminAPI --> Auth
    AdminAPI --> Store
    Node --> Collector
    Listing --> Collector
    Pricing --> Collector
    Order --> Collector
    Benchmark --> Collector
    Reconcile --> Collector
    Collector --> Store
```

交互边界如下：

- 对前端：输出聚合指标、趋势序列、排行数据、异常列表、时间线数据
- 对其他后端模块：管理员请求路径默认不直接读取事实模块；事实数据由 `Metric Collector` 周期采集
- 对缓存层：优先读取快照、缓存和聚合结果
- 对权限模块：校验管理员身份

## 10. 推荐的对前端数据接口分组

当前建议正式按“widget 可独立取数”来设计接口。

除 `/{id}/detail` 这类详情接口外，下面这些接口都建议优先读取 `Metric Snapshot / Cache`。

### 10.1 总览接口组

建议包括：

- `GET /admin/dashboard/overview`
- `GET /admin/dashboard/kpi-summary`
- `GET /admin/dashboard/platform-health`
- `GET /admin/dashboard/platform-load`
- `GET /admin/dashboard/resource-capacity`
- `GET /admin/dashboard/resource-utilization-trend`
- `GET /admin/dashboard/activity-timeline`

### 10.2 节点监控接口组

建议包括：

- `GET /admin/nodes/overview`
- `GET /admin/nodes/status-distribution`
- `GET /admin/nodes/load-matrix`
- `GET /admin/nodes/top-cpu`
- `GET /admin/nodes/top-memory`
- `GET /admin/nodes/top-gpu`
- `GET /admin/nodes/top-network-in`
- `GET /admin/nodes/top-network-out`
- `GET /admin/nodes/top-idle`
- `GET /admin/nodes/risk-ranking`
- `GET /admin/nodes/heartbeat-latency`
- `GET /admin/nodes/{node_id}/detail`

### 10.3 市场与价格接口组

建议包括：

- `GET /admin/market/overview`
- `GET /admin/market/listing-status-distribution`
- `GET /admin/market/price-trend`
- `GET /admin/market/gpu-distribution`
- `GET /admin/market/cpu-tier-distribution`
- `GET /admin/market/region-distribution`
- `GET /admin/market/top-hot-listings`
- `GET /admin/market/top-expensive-listings`
- `GET /admin/market/top-cheap-listings`

### 10.4 订单与部署接口组

建议包括：

- `GET /admin/orders/overview`
- `GET /admin/orders/status-distribution`
- `GET /admin/orders/create-trend`
- `GET /admin/orders/release-type-distribution`
- `GET /admin/deployments/runtime-distribution`
- `GET /admin/orders/expiring-soon`
- `GET /admin/orders/high-value`
- `GET /admin/deployments/overview`
- `GET /admin/deployments/web-entry-distribution`
- `GET /admin/deployments/runtime-failure-top`

### 10.5 Benchmark 接口组

建议包括：

- `GET /admin/benchmarks/overview`
- `GET /admin/benchmarks/status-distribution`
- `GET /admin/benchmarks/failure-top`
- `GET /admin/benchmarks/mode-distribution`
- `GET /admin/benchmarks/source-type-distribution`
- `GET /admin/benchmarks/duration-trend`

### 10.6 风险与审计接口组

建议包括：

- `GET /admin/risk/overview`
- `GET /admin/risk/runtime-events`
- `GET /admin/risk/severity-distribution`
- `GET /admin/risk/event-type-distribution`
- `GET /admin/risk/refund-compensation-stats`
- `GET /admin/risk/risk-nodes`
- `GET /admin/audit/timeline`
- `GET /admin/audit/action-type-distribution`
- `GET /admin/audit/recent-admin-logins`

### 10.7 这一层接口为什么要多

管理员大屏不应只依赖一个 `GET /admin/dashboard/overview`。

更合理的方式是：

1. 保留 `overview` 作为首屏快速回显入口。
2. 每个可视化 widget 都有自己的细分接口。
3. 前端按区块并行请求、独立重试、独立刷新。
4. 某个区块失败时，只让该区块报错，不拖垮整页。

这样前端才能自由做：

- 数字翻牌
- 折线趋势
- 节点热力矩阵
- Top 榜单
- 风险滚动流
- 审计时间线

## 11. 推荐的总览接口输出格式

为方便大屏前端直接消费，建议 `GET /admin/dashboard/overview` 返回一个组合型载荷。

该接口建议默认只读取缓存或快照，不在请求路径上动态做大聚合。

```json
{
  "generated_at": "2026-03-17T20:30:00Z",
  "kpi_summary": {
    "total_users": 1280,
    "total_buyers": 920,
    "total_sellers": 360,
    "total_compute_nodes": 148,
    "online_compute_nodes": 136,
    "offline_compute_nodes": 12,
    "total_listings": 146,
    "rentable_listings": 89,
    "running_orders": 42,
    "today_orders": 117,
    "today_abnormal_orders": 5,
    "running_benchmark_jobs": 8
  },
  "platform_load": {
    "avg_cpu_load_pct": 61.3,
    "peak_cpu_load_pct": 89.7,
    "avg_memory_load_pct": 58.1,
    "peak_memory_load_pct": 83.6,
    "avg_gpu_load_pct": 54.2,
    "peak_gpu_load_pct": 91.4,
    "gpu_in_use": 39,
    "gpu_idle": 18
  },
  "top_nodes": {
    "highest_cpu_load": [
      {
        "compute_node_id": "cn_1001",
        "title": "RTX4090-01",
        "cpu_load_pct": 93.1
      }
    ],
    "highest_gpu_load": [
      {
        "compute_node_id": "cn_1008",
        "title": "A100-02",
        "gpu_load_pct": 97.5
      }
    ]
  },
  "market": {
    "avg_listing_price_hourly": 18.6,
    "listed_count": 146,
    "rentable_count": 89,
    "rented_count": 41
  },
  "orders": {
    "running_count": 42,
    "released_count": 933,
    "abnormal_count": 17,
    "auto_release_count": 110,
    "manual_release_count": 823
  },
  "benchmarks": {
    "queued_count": 3,
    "running_count": 8,
    "succeeded_count": 295,
    "failed_count": 21,
    "placeholder_mode_count": 240,
    "runtime_mode_count": 76
  },
  "risk": {
    "open_events": 11,
    "critical_events": 2,
    "offline_node_events": 4,
    "deployment_lost_events": 3
  }
}
```

## 12. 页面表现建议

为了配合前端做“炫酷视觉效果”，建议数据区块的表现方式从文档层就预留出来。

### 12.1 顶部 KPI 区

适合：

- 数字翻牌
- 动态增量动画
- 红绿状态提示

### 12.2 平台负载区

适合：

- 仪表盘
- 多折线图
- 面积趋势图

### 12.3 节点区

适合：

- 热力矩阵
- 节点卡片墙
- 排名条形图

### 12.4 异常区

适合：

- 滚动告警流
- 风险等级色块
- 最近事件闪烁提醒

### 12.5 时间线区

适合：

- 流式事件列表
- 活动瀑布流
- 最近操作轨迹

## 13. 权限与安全要求

管理员模块必须独立校验。

最低要求：

- 只有 `admin` 身份可访问
- 管理员接口与普通用户接口逻辑隔离
- 所有后台访问要写入 `activity_logs`
- 大屏只读，不提供直接危险操作按钮
- 如需后续加入“人工干预”，应单独走管理操作接口，不混入总览接口

## 14. MVP 与后续阶段

### 14.1 MVP 阶段

MVP 阶段优先保证：

- 有独立管理员入口
- 有总览页
- 有核心 KPI
- 有节点状态分布
- 有订单和异常统计
- 有活动时间线
- 有 Mock 聚合数据支持

### 14.2 第二阶段

第二阶段增强：

- 单机实时负载
- 更细的价格趋势
- Benchmark 失败原因分析
- 风险热区图
- 热门节点/热门上架排行

### 14.3 第三阶段

第三阶段增强：

- 大屏专用模式
- 多时间窗口切换
- 聚合缓存与快照表
- 更精细的 GPU 型号分布
- 更细的订单生命周期分析

## 15. 本文档最终结论

1. 管理员模块不应只是几个后台表格，而应设计成独立的 `Admin Dashboard` 区域。
2. 为了支持前端做炫酷可视化，必须预留大量可直接作图的聚合指标。
3. 指标应分成平台总览、单机负载、市场价格、订单运行、Benchmark、异常风险、审计时间线 7 大类。
4. 后端应增加 `Metric Collector + Snapshot / Cache` 层，而不是每次页面打开都现场拼大 SQL。
5. 管理员模块必须保持只读聚合定位，不直接承担业务状态修改职责。

## 16. 数据时效性说明

### 16.1 一致性模型

管理员 Dashboard 采用**最终一致性**模型：
- 数据允许 1-5 分钟延迟
- 不追求实时强一致性
- 适合监控和分析场景

### 16.2 数据来源

- **快照数据**：从 `metric_snapshots` 表读取预聚合结果
- **缓存数据**：从 Redis 读取热点指标
- **事实数据**：仅在小范围、强过滤的详情查询时回查

### 16.3 用户提示

在 Dashboard 页面顶部显示：
```
📊 数据更新时间：2026-03-18 10:15:30（每 5 分钟刷新）
```

