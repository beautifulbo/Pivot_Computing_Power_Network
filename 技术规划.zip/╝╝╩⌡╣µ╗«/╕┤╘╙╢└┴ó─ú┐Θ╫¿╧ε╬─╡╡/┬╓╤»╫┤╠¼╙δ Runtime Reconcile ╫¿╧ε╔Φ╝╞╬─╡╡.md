# 轮询状态与 Runtime Reconcile 专项设计文档

版本：V1.0  
日期：2026-03-18

## 1. 文档目的

本文件单独描述平台里两类容易混淆、但必须拆开的机制：

1. 后端主动轮询：`Runtime Reconcile` 定时巡检 `ComputeNode`、`Deployment`、`RentalOrder` 的真实运行状态。
2. 前端只读轮询：买家页和管理员页周期刷新自己看到的状态，但它们不负责发现异常。

这份文档的目标是把下面几件事写死：

- 后端多久巡检一次
- 每一轮巡检扫哪些对象
- `Swarm Adapter` 应该返回什么标准化结果
- 什么时候创建 `RuntimeEvent`
- 什么时候推进订单异常、退款、补偿
- 买家页和管理员页随后会看到什么

## 2. 专项范围

本文件只讨论这些内容：

- `runtime_reconcile_job`
- `Runtime Reconcile` 内部巡检逻辑
- `Swarm Adapter` 为巡检提供的节点和 service 检查能力
- `RentalOrder & Deployment.apply_runtime_abnormal_result()`
- 买家端、管理员端对异常结果的读取展示

本文件不讨论这些内容：

- 正常下单与部署创建
- 正常主动释放
- Benchmark 测算流程
- 前端视觉稿

## 3. 相关对象与状态

### 3.1 核心对象

- `ComputeNode`
- `NodeRentalListing`
- `RentalOrder`
- `Deployment`
- `RuntimeEvent`
- `Runtime Reconcile`

### 3.2 本专项最常用状态

| 对象 | 关键状态 |
|---|---|
| `compute_nodes.runtime_status` | `online`、`offline`、`busy`、`error` |
| `rental_orders.order_status` | `pending_deploy`、`running`、`releasing`、`abnormal`、`refunded`、`released` |
| `rental_orders.payment_status` | `frozen`、`settled`、`refunded` |
| `deployments.runtime_status` | `pending`、`starting`、`running`、`stopping`、`lost`、`released`、`failed` |
| `runtime_events.event_type` | `node_offline`、`deployment_lost`、`state_mismatch`、`release_failed`、`manual_off_shelf` |
| `runtime_events.event_status` | `open`、`processing`、`resolved`、`compensated`、`closed` |

## 4. 分层原则

轮询与巡检必须遵守下面 4 条边界：

1. 前端页面只能读取状态，不能承担异常发现职责。
2. `Runtime Reconcile` 负责判定是否异常，但不直接操作 Docker Swarm。
3. 所有 Swarm 读取和控制动作都必须经过 `Swarm Adapter`。
4. 所有订单、部署、退款、补偿写入都必须回到 `RentalOrder & Deployment` 模块。

一句话固定为：

**前端只看，`Runtime Reconcile` 只判，`Swarm Adapter` 只适配，`RentalOrder & Deployment` 只写业务主状态。**

## 5. 总体结构图

```mermaid
flowchart LR
    Scheduler[Celery Beat / Scheduler]
    Reconcile[Runtime Reconcile]
    Swarm[Swarm Adapter]
    Node[ComputeNode Access]
    Order[RentalOrder & Deployment]
    Metric[Metric Collector / Snapshot]
    BuyerUI[Buyer Pages]
    AdminUI[Admin Dashboard]

    Scheduler --> Reconcile
    Reconcile --> Swarm
    Reconcile --> Node
    Reconcile --> Order
    Reconcile --> Metric
    BuyerUI --> Order
    AdminUI --> Metric
```

## 6. 轮询体系拆分

### 6.1 后端主动轮询

这是异常发现的唯一可靠来源。

- 入口：`runtime_reconcile_job`
- 执行频率：推荐每 30 秒一轮
- 扫描范围：
  - `rental_orders.order_status in (pending_deploy, running, releasing)`
  - `deployments.runtime_status in (pending, starting, running, stopping)`
- 目标：发现节点离线、service 丢失、状态不一致、释放失败

### 6.2 前端只读轮询

前端允许轮询，但只能轮询“已经被后端写出来的结果”。

推荐规则：

- `RentalOrderListPage`
  - 当列表中存在 `pending_deploy`、`running`、`releasing` 时，每 30 秒刷新一次 `GET /rental-orders`
- `RentalOrderDetailPage`
  - 当 `runtime_status in (starting, stopping)` 时，每 10 秒刷新一次 `GET /rental-orders/{order_id}/deployment`
  - 当 `runtime_event_summary.has_open_event = true` 时，每 10 秒刷新一次详情与部署
- `AdminDashboardPage`
  - 每 30 秒刷新一次 `GET /admin/dashboard/overview`
  - 每 30 秒刷新一次 `GET /admin/dashboard/runtime-events`

重点约束：

**前端轮询只读后端结果，不参与异常判定。**

## 7. 巡检总时序图

```mermaid
sequenceDiagram
    participant Scheduler as Scheduler
    participant Reconcile as Runtime Reconcile
    participant Swarm as Swarm Adapter
    participant Node as ComputeNode Access
    participant Order as RentalOrder & Deployment
    participant Metric as Metric Collector
    actor Buyer as Buyer
    participant BuyerAPI as Buyer APIs
    actor Admin as Admin
    participant AdminAPI as Admin Dashboard APIs

    Scheduler->>Reconcile: runtime_reconcile_job
    Reconcile->>Reconcile: load_reconcile_targets()
    Reconcile->>Swarm: inspect_swarm_node_by_id() / inspect_runtime_service()
    Swarm-->>Reconcile: 返回标准化巡检结果
    Reconcile->>Reconcile: classify_runtime_anomaly()

    alt 发现异常
        Reconcile->>Node: sync_compute_node_status()
        Reconcile->>Swarm: set_node_availability(..., drain)
        Reconcile->>Order: apply_runtime_abnormal_result()
        Order-->>Reconcile: 返回订单、部署、退款结果
        Reconcile->>Reconcile: create_runtime_event()
        Reconcile->>Metric: 写入异常事实供聚合读取
    else 未发现异常
        Reconcile-->>Scheduler: 本轮结束
    end

    Buyer->>BuyerAPI: GET /rental-orders/{order_id}/deployment
    BuyerAPI-->>Buyer: 返回 abnormal / refunded / lost 等状态

    Admin->>AdminAPI: GET /admin/dashboard/runtime-events
    AdminAPI-->>Admin: 返回异常事件列表与统计
```

## 8. 巡检详细流程

### 8.1 第 0 步：系统中已经存在运行中的订单和部署

**用户操作**

无。  
这一步是系统前置状态，不由用户触发。

**前端页面**

无。

**后端模块与接口**

- `RentalOrder & Deployment`
  - 提供当前 `RentalOrder`、`Deployment` 事实数据

**实现效果**

平台数据库中已经存在待巡检的运行对象，例如：

```json
{
  "rental_order_id": 9001,
  "order_status": "running",
  "deployment_id": 9101,
  "runtime_status": "running",
  "swarm_service_id": "svc_runtime_9101",
  "swarm_node_id": "node_seller_101"
}
```

### 8.2 第 1 步：调度器触发 `runtime_reconcile_job`

**用户操作**

无。  
这是后端定时任务，不依赖买家或管理员点击页面。

**前端页面**

无。

**后端模块与接口**

- `Runtime Reconcile`
  - `runtime_reconcile_job`
  - `load_reconcile_targets()`

**任务上下文 JSON 示例**

```json
{
  "job_name": "runtime_reconcile_job",
  "triggered_at": "2026-03-18T10:30:00Z",
  "scan_scope": {
    "order_statuses": ["pending_deploy", "running", "releasing"],
    "deployment_runtime_statuses": ["pending", "starting", "running", "stopping"],
    "batch_size": 200
  }
}
```

**实现效果**

- 后端确定本轮需要巡检哪些订单和部署
- 本轮任务开始，不影响前端当前页面

**下一步**

逐条目标进入 `Swarm Adapter` 检查。

### 8.3 第 2 步：`Runtime Reconcile` 调用 `Swarm Adapter` 获取真实状态

**用户操作**

无。

**前端页面**

无。

**后端模块与接口**

- `Runtime Reconcile`
  - `reconcile_compute_nodes()`
  - `reconcile_deployments()`
- `Swarm Adapter`
  - `inspect_swarm_node_by_id(swarm_node_id)`
  - `inspect_runtime_service(service_id)`

**内部请求 JSON 示例**

```json
{
  "reconcile_target": {
    "compute_node_id": 101,
    "swarm_node_id": "node_seller_101",
    "rental_order_id": 9001,
    "deployment_id": 9101,
    "swarm_service_id": "svc_runtime_9101"
  }
}
```

**`Swarm Adapter` 返回 JSON 示例**

```json
{
  "success": true,
  "node": {
    "swarm_node_id": "node_seller_101",
    "availability": "active",
    "status": "down"
  },
  "runtime_service": {
    "service_id": "svc_runtime_9101",
    "desired_state": "running",
    "status": "missing",
    "task_status": "not_found"
  },
  "message": "node offline and runtime service missing"
}
```

**实现效果**

- `Runtime Reconcile` 拿到一份统一格式的真实运行结果
- 业务层不需要自己解析 Docker 原始对象

**下一步**

`Runtime Reconcile` 开始分类异常。

### 8.4 第 3 步：分类异常类型

**用户操作**

无。

**前端页面**

无。

**后端模块与接口**

- `Runtime Reconcile`
  - `classify_runtime_anomaly()`
  - `detect_abnormal_release()`

**分类结果 JSON 示例**

```json
{
  "anomaly_detected": true,
  "event_type": "node_offline",
  "severity": "critical",
  "business_decision": {
    "mark_order_status": "abnormal",
    "mark_deployment_status": "lost",
    "refund_required": true,
    "set_node_drain": true
  }
}
```

**实现效果**

- 平台把“真实 Swarm 状态”翻译为“业务异常类型”
- 这一步仍然没有直接暴露给前端

**下一步**

创建 `RuntimeEvent` 并推进业务写入。

### 8.5 第 4 步：创建 `RuntimeEvent`

**用户操作**

无。

**前端页面**

无。

**后端模块与接口**

- `Runtime Reconcile`
  - `create_runtime_event()`

**事件写入 JSON 示例**

```json
{
  "event_type": "node_offline",
  "severity": "critical",
  "event_status": "open",
  "compute_node_id": 101,
  "listing_id": 201,
  "rental_order_id": 9001,
  "deployment_id": 9101,
  "detected_source": "runtime_reconcile_job",
  "detail_json": {
    "swarm_node_status": "down",
    "swarm_service_status": "missing",
    "recommended_action": "refund_and_drain_node"
  }
}
```

**实现效果**

- 异常被持久化为平台事实事件
- 后续买家详情页和管理员大盘都可以显示同一条异常事实

**下一步**

推进节点、订单、部署、退款状态。

### 8.6 第 5 步：推进 `ComputeNode`、`RentalOrder`、`Deployment` 和补偿状态

**用户操作**

无。

**前端页面**

无。

**后端模块与接口**

- `ComputeNode Access`
  - `sync_compute_node_status()`
- `Swarm Adapter`
  - `set_node_availability(swarm_node_id, availability)`
- `RentalOrder & Deployment`
  - `apply_runtime_abnormal_result()`
- `Runtime Reconcile`
  - `trigger_refund_or_compensation()`

**内部请求 JSON 示例**

```json
{
  "runtime_event_id": 5001,
  "compute_node_id": 101,
  "rental_order_id": 9001,
  "deployment_id": 9101,
  "target_node_availability": "drain",
  "business_result": {
    "compute_node_runtime_status": "offline",
    "rental_order_status": "abnormal",
    "deployment_runtime_status": "lost",
    "payment_action": "refund"
  }
}
```

**业务写入结果 JSON 示例**

```json
{
  "compute_node": {
    "id": 101,
    "runtime_status": "offline"
  },
  "rental_order": {
    "id": 9001,
    "order_status": "refunded",
    "payment_status": "refunded",
    "refunded_amount": 31.0
  },
  "deployment": {
    "id": 9101,
    "runtime_status": "lost"
  },
  "runtime_event": {
    "id": 5001,
    "event_status": "compensated"
  }
}
```

**实现效果**

- 节点被标记为异常，不再继续接单
- 当前订单被推进到 `abnormal` 或 `refunded`
- 当前部署被推进到 `lost`
- 退款或补偿金额写回订单和交易流水

**下一步**

买家页和管理员页会在下一次读取时看到这些新状态。

### 8.7 第 6 步：买家在控制台看到异常状态

**用户操作**

买家打开“我的实例”或刷新某个实例详情页。

**前端页面**

- `RentalOrderListPage`
- `RentalOrderDetailPage`

**后端模块与接口**

- `RentalOrder & Deployment`
  - `GET /rental-orders`
  - `GET /rental-orders/{order_id}`
  - `GET /rental-orders/{order_id}/deployment`

**买家详情响应 JSON 示例**

```json
{
  "order": {
    "id": 9001,
    "order_status": "refunded",
    "payment_status": "refunded",
    "refunded_amount": 31.0
  },
  "deployment": {
    "id": 9101,
    "runtime_status": "lost",
    "web_entry_status": "unavailable",
    "runtime_event_summary": {
      "has_open_event": false,
      "latest_event_type": "node_offline",
      "latest_event_status": "compensated"
    }
  }
}
```

**实现效果**

- 列表页对应实例卡片高亮为异常或已退款
- 详情页顶部出现异常告警条
- “网页连接”按钮禁用
- 页面展示退款或补偿结果

### 8.8 第 7 步：管理员在 Dashboard 看到异常事件

**用户操作**

管理员打开或刷新 `AdminDashboardPage`。

**前端页面**

- `AdminDashboardPage`

**后端模块与接口**

- `Admin Dashboard`
  - `GET /admin/dashboard/overview`
  - `GET /admin/dashboard/runtime-events`

**管理员响应 JSON 示例**

```json
{
  "overview": {
    "open_runtime_event_count": 3,
    "compensated_runtime_event_count": 12,
    "offline_compute_node_count": 1
  },
  "runtime_events": [
    {
      "id": 5001,
      "event_type": "node_offline",
      "severity": "critical",
      "event_status": "compensated",
      "compute_node_id": 101,
      "rental_order_id": 9001,
      "detected_at": "2026-03-18T10:30:08Z"
    }
  ]
}
```

**实现效果**

- 管理员大盘上的异常计数增长
- 异常事件列表新增一条记录
- 后续可继续钻取节点、订单和补偿详情

## 9. 异常类型与处理规则

| 异常类型 | 典型判定信号 | 节点处理 | 订单处理 | 部署处理 | 前端表现 |
|---|---|---|---|---|---|
| `node_offline` | node 状态为 `down` 或长时间不可达 | `runtime_status -> offline`，必要时 `drain` | `abnormal -> refunded` | `lost` | 详情页告警，显示已退款 |
| `deployment_lost` | node 正常，但 service / task 丢失 | 节点可继续观察 | `abnormal`，可退款 | `lost` | 网页连接失效，显示实例丢失 |
| `state_mismatch` | 数据库显示 running，但 Swarm 显示 failed / released / missing | 视真实 node 状态而定 | `abnormal` 或 `released` | `failed` / `released` / `lost` | 页面显示状态不同步修正结果 |
| `release_failed` | 用户主动释放后，service 未删除成功 | 视情况保留或 `drain` | `releasing` 或 `abnormal` | `stopping` / `failed` | 详情页显示释放失败 |

## 10. `Swarm Adapter` 在本专项中的边界

`Swarm Adapter` 在巡检链路里只负责 4 件事：

1. 检查某个 `Swarm Worker` 的真实状态
2. 检查某个 `runtime service` 的真实状态
3. 在必要时把节点设置为 `pause` 或 `drain`
4. 提供标准化返回结果，不让业务层直接碰 Docker 原始结构

它不负责：

- 判定是否应该退款
- 判定订单是否进入 `abnormal`
- 写 `RuntimeEvent`
- 修改 `RentalOrder` 和 `Deployment`

## 11. 前端状态层约束

前端只需要消费后端已经产出的事实状态，不自己发明新状态。

### 11.1 买家页

- 列表页依赖：
  - `order_status`
  - `runtime_status`
  - `runtime_event_summary`
- 详情页依赖：
  - `runtime_status`
  - `web_entry_status`
  - `latest_event_type`
  - `latest_event_status`
  - `refunded_amount`

### 11.2 管理员页

- 总览卡片依赖聚合快照
- 异常事件表依赖 `GET /admin/dashboard/runtime-events`
- 不在页面打开时临时拼接事实表大 SQL

## 12. 当前结论

本专项固定下面 6 条规则：

1. 异常发现只由 `Runtime Reconcile` 负责。
2. 前端轮询只是读取结果，不承担判定职责。
3. `Swarm Adapter` 只负责读 Swarm 和做必要控制，不负责业务判定。
4. `RentalOrder & Deployment.apply_runtime_abnormal_result()` 是异常链路的唯一订单写入口。
5. `runtime_reconcile_job` 推荐每 30 秒执行一轮。
6. 买家页和管理员页看到的所有异常结果，都应来自同一条 `RuntimeEvent` 事实链路。
