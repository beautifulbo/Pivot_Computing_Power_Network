# 后端定价模块与 PricingEngine 专项设计文档

版本：V1.0  
日期：2026-03-17

## 1. 文档目的

本文件用于单独定义后端 `PricingEngine` 定价模块。

这份文档的重点不是去设计复杂交易系统，而是把这个模块收敛成一个边界清晰、与其他后端逻辑弱耦合的独立能力：

1. 提供一个“实时算力单位价格”计算接口
2. 提供一个“某个容器实际总价”计算接口

除此之外，定价模块只保留少量内部支撑能力，例如：

- 周期采集外部市场参考价格
- 生成价格解释
- 缓存近实时价格快照

## 2. 先给出设计结论

### 2.1 模块边界

`PricingEngine` 不负责：

- 创建订单
- 冻结余额
- 部署容器
- 处理释放
- 修改上架状态

`PricingEngine` 只负责：

- 根据节点规格和外部市场参考，返回单位价格
- 根据价格快照和运行时长，返回实际总价

### 2.2 对业务层暴露的最小接口

对其他后端模块，只暴露两个主接口：

1. `quote_unit_price(pricing_input)`
2. `calculate_runtime_total(runtime_pricing_input)`

内部支撑接口可以有，但不作为主要业务接口公开给其他模块。

### 2.3 “实时” 的正确实现方式

这里的“实时”不建议理解成“每次前端打开页面都立刻联网抓取全网价格”。

更合理的方式是：

- 外部价格源由定时任务周期抓取
- 结果归一化后写入 `Market Reference Cache`
- 业务请求读取最近一份可用快照
- 对外表现为“近实时价格”

因此本模块应采用：

**外部异步采集 + 内部实时计算 + 快照缓存读取**

而不是：

**页面请求直接联网拼价格**

## 3. 网上是否有相关实现思路

有，而且比较成熟。当前主流有两类思路。

### 3.1 云厂商公开价格 API 思路

大型云厂商普遍提供公开的价格 API 或价格目录：

- AWS 提供 `Price List Query API` 和 `Bulk API`，可按服务、属性、过滤条件查询价格与 SKU 信息。  
  官方文档说明可以使用 `DescribeServices`、`GetAttributeValues`、`GetProducts` 组合查询产品和价格。[AWS Price List Query API](https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/using-price-list-query-api.html) [AWS GetProducts](https://docs.aws.amazon.com/aws-cost-management/latest/APIReference/API_pricing_GetProducts.html) [AWS Bulk API](https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/finding-prices-in-service-price-list-files.html)
- Google Cloud 提供 `Cloud Billing Catalog API` 与 `Pricing API`，可获取服务、SKU、地区、价格单位和当前价格。[Google Cloud Catalog API](https://docs.cloud.google.com/billing/v1/how-tos/catalog-api) [Google Cloud Pricing API](https://docs.cloud.google.com/billing/docs/reference/pricing-api/rest)
- Azure 提供 `Azure Retail Prices API`，可按 `serviceName`、`serviceFamily`、`armSkuName`、区域等条件检索价格。[Azure Retail Prices API](https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices)

这类思路的特点是：

- 价格结构标准化
- 区域和 SKU 信息比较完整
- 适合做“基准价”
- 不一定贴近民间 GPU 算力市场

### 3.2 算力市场报价聚合思路

GPU 算力平台和 marketplace 更接近你们项目的形态。

- Runpod 的官方文档说明，Pods 会显示小时价格，但计算和存储是按秒计费。[Runpod Pods Pricing](https://docs.runpod.io/pods/pricing)
- Vast.ai 的官方文档说明，其平台是 marketplace 模式，价格由供需和主机条件实时变化；并提供 `search offers` 这类程序化查询接口。[Vast.ai Pricing](https://docs.vast.ai/documentation/instances/pricing) [Vast.ai Search Offers](https://docs.vast.ai/api-reference/search/search-offers)

这类思路的特点是：

- 更接近 GPU 算力租赁市场
- 更适合拿来做“市场修正系数”
- 数据波动更大
- 字段和价格模型更不统一

### 3.3 对你们项目的最合适方案

综合来看，最合理的是：

1. 用云厂商公开价格 API 提供“稳定基准价”
2. 用 GPU marketplace 公开价格提供“市场修正”
3. 在平台内部统一换算成一个标准单位，例如 `CNY/hour`
4. 由平台自己的 `PricingEngine` 生成最终平台价

这是一个推断：  
从官方 API 和 marketplace 文档看，做“价格采集 -> 归一化 -> 统一定价”是完全合理的；但你们当前阶段不需要做到复杂竞价或高频撮合。

## 4. 模块定位与交互边界

```mermaid
flowchart LR
    Node[ComputeNode / NodeRentalListing]
    Order[RentalOrder & Deployment]
    Pricing[PricingEngine]
    Cache[Market Reference Cache]
    Ext[External Pricing Sources]

    Node --> Pricing
    Order --> Pricing
    Pricing --> Cache
    Pricing --> Ext
```

交互含义如下：

- `ComputeNode Access` 或 `NodeRentalListing Market` 调 `quote_unit_price()`
- `RentalOrder & Deployment` 调 `calculate_runtime_total()`
- 定时任务调 `refresh_market_reference_quotes()`
- 其他模块不直接接触外部价格源

## 5. 模块职责

`PricingEngine` 的职责固定为 5 件事：

1. 采集外部市场参考价格
2. 把不同来源价格归一化
3. 计算节点的单位价格
4. 计算容器的实际总价
5. 输出价格解释和价格新鲜度信息

## 6. 推荐的内部结构

```mermaid
flowchart TB
    subgraph M[PricingEngine Module]
        API1[quote_unit_price]
        API2[calculate_runtime_total]
        REF[Market Reference Resolver]
        NORM[Price Normalizer]
        RULE[Pricing Rule Engine]
        EXPLAIN[Price Explanation Builder]
        CACHE[Reference Cache / Snapshot]
        JOB[Scheduled Fetch Jobs]
    end

    JOB --> REF
    REF --> NORM
    NORM --> CACHE
    API1 --> CACHE
    API1 --> RULE
    RULE --> EXPLAIN
    API2 --> RULE
```

### 6.1 `Market Reference Resolver`

负责：

- 抓取 AWS / GCP / Azure 等公开价格
- 抓取或录入 marketplace 参考价
- 识别不同来源字段

### 6.2 `Price Normalizer`

负责：

- 统一币种
- 统一时间单位
- 统一规格维度
- 过滤异常值

### 6.3 `Pricing Rule Engine`

负责：

- 根据节点规格算单位价格
- 根据价格快照和运行时长算总价
- 应用保底价、上限价、舍入规则

### 6.4 `Price Explanation Builder`

负责：

- 解释价格从哪来
- 给前端和管理员提供说明

## 7. 推荐的数据流

```mermaid
sequenceDiagram
    participant Job as Scheduled Fetch Job
    participant Ext as External Pricing Sources
    participant Norm as Price Normalizer
    participant Cache as Market Reference Cache
    participant Biz as Business Module
    participant Engine as PricingEngine

    Job->>Ext: 拉取公开价格与市场参考价
    Ext-->>Job: 返回原始价格数据
    Job->>Norm: 归一化
    Norm-->>Job: 返回标准化价格项
    Job->>Cache: 写入价格快照

    Biz->>Engine: 请求单位价格 / 总价
    Engine->>Cache: 读取最近可用快照
    Cache-->>Engine: 返回参考价格
    Engine-->>Biz: 返回计算结果
```

## 8. 推荐的价格参考源设计

## 8.1 统一参考价格模型

建议内部统一成 `MarketReferenceQuote`：

```json
{
  "source_name": "azure_retail_prices",
  "source_type": "cloud_public_api",
  "sku_name": "Standard_NP20s",
  "region": "southcentralus",
  "currency": "USD",
  "unit": "hour",
  "gpu_model": "NVIDIA Tesla V100",
  "gpu_count": 1,
  "cpu_cores": 20,
  "memory_gb": 112,
  "price_per_unit": 0.828503,
  "price_type": "on_demand",
  "reliability_hint": null,
  "fetched_at": "2026-03-17T12:00:00Z"
}
```

## 8.2 归一化字段

建议至少归一化这些字段：

- `source_name`
- `source_type`
- `sku_name`
- `region`
- `currency`
- `unit`
- `gpu_model`
- `gpu_count`
- `cpu_cores`
- `memory_gb`
- `price_per_unit`
- `price_type`
- `fetched_at`

## 8.3 推荐的统一单位

建议内部统一用两层单位：

1. 存储和计算基准：`USD/hour`
2. 对外展示与平台结算：`CNY/hour`

理由：

- 大量云价格源默认就是 USD
- 统一到 USD/hour 更容易做源间比较
- 平台对前端展示时再统一换算到 CNY/hour

## 9. 单位价格接口设计

这是模块最重要的第一个主接口。

### 9.1 接口定义

`quote_unit_price(pricing_input)`

### 9.2 输入建议

```json
{
  "compute_node_id": "cn_1001",
  "hardware_profile": {
    "cpu_cores": 16,
    "memory_gb": 64,
    "gpu_model": "RTX_4090",
    "gpu_count": 1,
    "gpu_vram_gb": 24,
    "network_tier": "standard"
  },
  "pricing_context": {
    "currency": "CNY",
    "region_hint": "CN",
    "price_type": "on_demand"
  }
}
```

### 9.3 输出建议

```json
{
  "ok": true,
  "price_currency": "CNY",
  "unit_price_hourly": 18.60,
  "unit_price_second": 0.00516667,
  "price_source_mode": "market_reference_plus_rule",
  "freshness_seconds": 180,
  "breakdown": {
    "cpu_component": 2.40,
    "memory_component": 1.20,
    "gpu_component": 14.30,
    "network_component": 0.70
  },
  "explanation": [
    "based on recent normalized public cloud and marketplace references",
    "gpu component dominates the final price",
    "price displayed as CNY/hour and settled by actual runtime"
  ],
  "priced_at": "2026-03-17T20:30:00Z",
  "expires_at": "2026-03-17T20:35:00Z"
}
```

### 9.4 推荐计算流程

```mermaid
flowchart LR
    A[Receive hardware profile]
    B[Find comparable market quotes]
    C[Normalize to USD/hour]
    D[Filter stale / outlier quotes]
    E[Compute baseline reference]
    F[Apply platform pricing rules]
    G[Convert to target currency]
    H[Return unit price result]

    A --> B --> C --> D --> E --> F --> G --> H
```

### 9.5 推荐的最小算法

当前阶段不建议一上来做复杂模型，建议采用“参考价 + 规则修正”。

可以先按下面方式：

1. 先找相近规格的参考价
2. 如果没有完全匹配，则按组件估算
3. 去掉明显过高和过低的离群值
4. 用加权中位数或截尾均值作为基准价
5. 再叠加平台规则修正

建议公式：

```text
baseline_price_hourly
  = weighted_median(comparable_market_quotes)

fallback_component_price_hourly
  = cpu_cores * cpu_ref_price_per_core_hour
  + memory_gb * mem_ref_price_per_gb_hour
  + gpu_count * gpu_ref_price_per_card_hour
  + network_tier_factor

final_unit_price_hourly
  = choose(baseline_price_hourly, fallback_component_price_hourly)
  * market_adjustment_factor
  * reliability_adjustment_factor
```

### 9.6 MVP 建议

MVP 阶段建议先这样做：

- `gpu_model` 有明确基准时，以 GPU 价格为主
- CPU 和内存只做轻量修正
- 不做动态竞价
- 不做用户级个性化定价
- 不做复杂折扣系统

## 10. 容器实际总价接口设计

这是模块第二个主接口。

### 10.1 接口定义

`calculate_runtime_total(runtime_pricing_input)`

### 10.2 输入建议

```json
{
  "deployment_id": "dep_9001",
  "pricing_snapshot": {
    "price_currency": "CNY",
    "unit_price_hourly": 18.60,
    "billing_granularity_seconds": 60,
    "minimum_billing_seconds": 60
  },
  "runtime_window": {
    "started_at": "2026-03-17T20:00:00Z",
    "ended_at": "2026-03-17T21:18:37Z"
  },
  "addon_usage": {
    "storage_gb_hours": 0,
    "network_egress_gb": 0
  }
}
```

### 10.3 输出建议

```json
{
  "ok": true,
  "price_currency": "CNY",
  "actual_runtime_seconds": 4717,
  "billable_seconds": 4740,
  "compute_total": 24.49,
  "storage_total": 0,
  "network_total": 0,
  "final_total": 24.49,
  "breakdown": {
    "unit_price_hourly": 18.60,
    "unit_price_second": 0.00516667,
    "billing_granularity_seconds": 60
  }
}
```

### 10.4 推荐结算公式

建议采用“展示按小时，结算按秒或按分钟粒度”的方式。

如果为了实现简单，当前 MVP 推荐：

```text
actual_runtime_seconds = ended_at - started_at

billable_seconds
  = max(
      minimum_billing_seconds,
      ceil(actual_runtime_seconds / billing_granularity_seconds)
      * billing_granularity_seconds
    )

compute_total
  = unit_price_hourly / 3600 * billable_seconds

final_total
  = compute_total + storage_total + network_total
```

### 10.5 为什么建议这样

因为这套方式兼顾 3 点：

1. 前端展示简单：`CNY/hour`
2. 结算公平：按真实运行时长
3. 实现容易：分钟粒度已经足够稳定

### 10.6 MVP 限制

MVP 阶段建议：

- 存储和网络附加费用先固定为 0
- 只算容器运行时长费用
- 不做分时折扣
- 不做峰谷电价

也就是说，第一阶段 `calculate_runtime_total()` 本质上只结算：

**单位时价 x 计费时长**

## 11. 新鲜度、过期与回退

## 11.1 推荐新鲜度策略

- `reference quote fetch interval`: 5-15 分钟
- `unit price ttl`: 5 分钟
- `hard stale threshold`: 30 分钟

## 11.2 当外部价格源失败时

建议回退顺序：

1. 使用最近一份未过硬过期阈值的快照
2. 使用内部组件价格表做回退计算
3. 返回 `stale=true` 和解释信息

### 11.3 为什么不能每次请求都联网

因为这样会立刻遇到：

- 请求延迟不稳定
- 外部接口分页和限流
- 第三方短时失败放大为用户页面失败
- 页面刷新直接压到外部服务

所以“实时价格”更应该理解成：

**最近一次成功采集基础上的近实时计算结果**

## 12. 推荐的数据存储

定价模块建议至少有 3 类数据：

### 12.1 `external_market_quotes`

保存外部价格源的原始或半归一化结果。

### 12.2 `pricing_reference_snapshots`

保存按 GPU 型号、规格档位归一化后的参考快照。

### 12.3 `listing_price_snapshots`

这个表你们现有设计里已经有，用来保存最终平台价快照。  
它应继续作为业务层可审计的最终价格记录。

## 13. 模块交互图

```mermaid
flowchart LR
    FE[Frontend]
    Node[ComputeNode / Listing Module]
    Order[RentalOrder & Deployment]
    Ext[External Pricing Sources]
    DB[(Snapshots / Cache)]

    subgraph M[PricingEngine Module]
        IS[Internal Service Unit]
        SJ[Scheduled Job Unit]
        PC[Price Calculation Core]
        PR[Price Reference Cache]
    end

    Node --> IS
    Order --> IS
    SJ --> IS
    IS --> PC
    PC --> PR
    IS --> Ext
    PR --> DB
```

交互分类如下：

| 交互方向 | 内容 |
|---|---|
| 对前端 | 无直接接口 |
| 对其他后端模块 | 提供单位价格与总价计算 |
| 对外 | 读取外部价格 API 或公开价格文档数据 |
| 内部 | 抓价、归一化、计算、缓存、解释 |

## 14. 推荐的内部接口

### 14.1 主接口

- `quote_unit_price(pricing_input)`
- `calculate_runtime_total(runtime_pricing_input)`

### 14.2 内部支撑接口

- `refresh_market_reference_quotes()`
- `normalize_market_quotes(raw_quotes)`
- `resolve_comparable_quotes(hardware_profile)`
- `build_price_explanation(price_result)`

## 15. 推荐的实现顺序

1. 先冻结 `quote_unit_price()` 输入输出
2. 先冻结 `calculate_runtime_total()` 输入输出
3. 先做内部占位参考价
4. 再接入 1 个公开价格源
5. 再接入第 2 类 marketplace 参考价
6. 最后再补价格解释和异常回退

## 16. 本文档最终结论

1. `PricingEngine` 应保持独立和弱耦合，只向业务层暴露两个主接口。
2. “实时价格”应通过异步抓价和快照缓存实现，而不是页面请求直接联网。
3. 网上现成思路是存在的，官方云价格 API 和 GPU marketplace 都可作为参考源。
4. 当前阶段最合适的方案是“公开云价格做基准，marketplace 价格做修正”。
5. MVP 只需要先把单位价格和总价两个接口做正确，不需要一开始就做复杂竞价系统。

## 17. 参考资料

- AWS Price List Query API: https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/using-price-list-query-api.html
- AWS GetProducts API: https://docs.aws.amazon.com/aws-cost-management/latest/APIReference/API_pricing_GetProducts.html
- AWS Price List Bulk API: https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/finding-prices-in-service-price-list-files.html
- Google Cloud Billing Catalog API: https://docs.cloud.google.com/billing/v1/how-tos/catalog-api
- Google Cloud Pricing API: https://docs.cloud.google.com/billing/docs/reference/pricing-api/rest
- Azure Retail Prices API: https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices
- Runpod Pods Pricing: https://docs.runpod.io/pods/pricing
- Vast.ai Pricing: https://docs.vast.ai/documentation/instances/pricing
- Vast.ai Search Offers API: https://docs.vast.ai/api-reference/search/search-offers
