# AI测算与 BenchmarkJob 专项设计文档

版本：V1.1
日期：2026-03-18

## 1. 文档目的

本文件是算力交易平台的 AI 测算与 `BenchmarkJob` 专项设计文档。

这份文档重点解决 5 个问题：

1. AI 测算模块在 Docker Swarm 里到底是什么
2. 为什么它应当被设计成一个专用的 `Benchmark Worker` 体系
3. `Claude Code` 在这个模块里扮演什么角色
4. 测算结果应该输出成什么格式
5. `BenchmarkJob` 模块应如何和 `Swarm Adapter` 对接

本文件会尽量解释清楚概念，因为当前团队成员普遍还不熟悉 Docker Swarm 和“代理式代码执行”的组合方式。

## 2. 设计结论先说清

先给出最重要的结论，避免后面理解偏掉：

1. 从 Swarm 技术角度看，“worker” 指的是节点，不是容器。
2. 因此你想要的“AI 测算 worker”，正确落地方式不是“一个特殊容器就是 worker”，而是：
   - 平台准备一台或多台专用 `Benchmark Worker Node`
   - 在这个节点上运行 `Benchmark Service Container`
3. `Claude Code` 应该被内置在 `Benchmark Service Container` 中，作为容器内部的代码分析与压测编排执行器。
4. 当前项目应保留双模式：
   - `placeholder mode`：直接返回结构正确的占位结果
   - `claude runtime mode`：真正调用容器里的 `Claude Code` 尝试运行、压测、分析并输出推荐
5. 对外业务上仍统一叫 `BenchmarkJob`，前端不需要知道底层当前跑的是占位模式还是真实模式。

## 3. 名词解释

### 3.1 Benchmark Worker Node

`Benchmark Worker Node` 是平台专门控制的一台 `Swarm Worker`。  
它只用于执行测算任务，不承载卖家的租赁运行环境。

### 3.2 Benchmark Service Container

`Benchmark Service Container` 是由 `Swarm Adapter` 创建并调度到 `Benchmark Worker Node` 上的测算容器。  
它是一次 `BenchmarkJob` 的实际执行载体。

### 3.3 Claude Code Runner

`Claude Code Runner` 指内置在测算容器中的代理式代码执行组件。  
它接收固定提示词、读取用户代码目录、尝试判断项目类型、尝试启动项目、执行压测命令，并输出结构化结果。

### 3.4 BenchmarkJob

`BenchmarkJob` 是平台业务层中的测算任务记录。  
它不是 Docker 概念，而是平台业务概念。

### 3.5 Placeholder Mode

`Placeholder Mode` 是当前 MVP 必须保留的一种执行模式。  
即便真实测算尚未完成，只要接口和结果结构正确，系统也能返回一份“可信的占位结果”。

### 3.6 Claude Runtime Mode

`Claude Runtime Mode` 是后续增强模式。  
它要求测算容器真正分析用户代码并尝试执行简单压测。

## 4. 模块定位

### 4.1 这个模块在整个平台中的位置

`BenchmarkJob` 是一个独立入口，不参与直接下单。

- 买家可以完全不使用它，直接去市场租机器
- 买家也可以先提交代码做测算，再拿推荐结果去市场挑选 `NodeRentalListing`
- 测算结果不应自动创建 `RentalOrder`
- 测算结果不应锁定任何节点资源

因此它的定位是：

**一个辅助决策模块，不是交易模块。**

### 4.2 在 Swarm 中的准确映射

```mermaid
flowchart LR
    Buyer[Buyer]
    Frontend[Frontend]
    BenchmarkJobModule[BenchmarkJob Module]
    SwarmAdapter[Swarm Adapter]
    BenchWorker[Benchmark Worker Node]
    BenchService[Benchmark Service Container]
    OutputStore[Result Store]
    Market[NodeRentalListing Market]

    Buyer --> Frontend
    Frontend --> BenchmarkJobModule
    BenchmarkJobModule --> SwarmAdapter
    SwarmAdapter --> BenchWorker
    BenchWorker --> BenchService
    BenchService --> OutputStore
    BenchmarkJobModule --> OutputStore
    BenchmarkJobModule --> Market
    BenchmarkJobModule --> Frontend
```

解释如下：

- `Benchmark Worker Node` 是 Swarm 层面的节点
- `Benchmark Service Container` 是一次测算的容器
- `Claude Code Runner` 在这个容器里面
- `BenchmarkJob Module` 负责业务记录和结果解析
- `Swarm Adapter` 负责真正调用 Docker Swarm

## 5. 为什么要专门隔离 Benchmark Worker

AI 测算任务应当从卖家节点隔离出来，原因如下：

1. 测算过程本身可能消耗 CPU、内存、网络，不能影响卖家租赁节点。
2. 测算需要更高权限的观察能力，例如读取日志、收集性能数据，这类能力不应落在卖家机器上。
3. 用户上传代码可能不可控，必须集中在平台可控节点内运行。
4. 后续清理、审计、限流、安全隔离都更容易做。

因此，推荐拓扑固定为：

- `1 x Swarm Manager`
- `N x Seller Worker Node`
- `1 x Benchmark Worker Node`

并且给 benchmark 节点打固定标签：

- `node.labels.platform_role=benchmark`
- `node.labels.benchmark_enabled=true`

## 6. Benchmark Service Container 的建议组成

推荐把测算容器做成一套固定镜像，例如：

- 基础镜像：`ubuntu:22.04` 或 `python:3.11-slim`
- 内置运行时：`python`、`node`、`bash`
- 内置压测工具：`hey`、`wrk`、`ab`、`curl`
- 内置采集工具：`ps`、`time`、`pidstat` 或轻量监控脚本
- 内置代理执行器：`Claude Code Runner`
- 内置平台脚本：
  - `prepare_workspace.sh`
  - `detect_project.py`
  - `benchmark_runner.py`
  - `emit_result.py`

建议目录结构：

```text
/opt/benchmark/
  runner/
    detect_project.py
    benchmark_runner.py
    result_schema.py
    emit_result.py
  prompts/
    system_prompt.md
    benchmark_prompt.md
  workspace/
    input/
    repo/
    output/
```

## 7. 双模式设计

### 7.1 Placeholder Mode

这是当前最重要的落地模式。

执行逻辑：

1. 创建 `BenchmarkJob`
2. 直接返回一份结构合法的结果
3. 结果字段固定，内容可由规则或假数据生成
4. 前端流程、推荐页面、状态流转全部可以先打通

适用阶段：

- 前端联调
- 页面演示
- 接口契约冻结
- 团队尚未完成真实压测能力前

### 7.2 Claude Runtime Mode

这是后续增强模式。

执行逻辑：

1. 用户提交代码
2. 平台创建 benchmark service
3. 容器解压代码并分析项目结构
4. `Claude Code Runner` 根据提示词推断启动方式
5. 容器尝试启动应用
6. 容器执行轻量压测
7. 容器汇总性能指标
8. 容器输出推荐资源和推荐节点
9. 平台删除 benchmark service

### 7.3 模式切换原则

建议在 `BenchmarkJob Module` 内保留配置项：

- `BENCHMARK_EXECUTION_MODE=placeholder`
- `BENCHMARK_EXECUTION_MODE=claude_runtime`

这样前端永远只调用正式接口，不感知底层模式切换。

## 8. Claude Code 工作流设计

### 8.1 总体思路

`Claude Code Runner` 不应被理解成“自由发挥的聊天机器人”，而应被约束成一个固定流程执行器：

1. 阅读项目目录结构
2. 判断项目类型
3. 推测依赖安装方式
4. 推测启动命令
5. 尝试启动服务
6. 尝试压测
7. 收集指标
8. 输出固定 JSON

也就是说，它必须被限制在“产出结构化 benchmark 结果”的目标里，而不是开放式问答。

### 8.2 建议提示词结构

建议采用三层提示词：

1. `system prompt`
2. `benchmark workflow prompt`
3. `job input prompt`

### 8.3 建议 System Prompt

下面是建议版本，可以直接写入文档并作为后续模板：

```text
You are a benchmark execution agent running inside a controlled Docker container.

Your goal is to inspect the submitted project, infer how to run it, attempt a safe lightweight benchmark,
and produce a structured JSON result for an infrastructure recommendation system.

You must follow these rules:
1. Prefer deterministic actions over speculation.
2. If project type is unclear, report uncertainty instead of inventing details.
3. Never output free-form final text as the main result. The main result must be valid JSON.
4. If execution fails, still produce a JSON result with status=failed and a clear failure_reason.
5. Do not modify files outside the workspace.
6. Keep commands lightweight and time-bounded.
7. Do not expose secrets, tokens, or environment internals in output.
8. Recommend infrastructure conservatively rather than aggressively.
```

### 8.4 建议 Benchmark Workflow Prompt

```text
Perform the benchmark workflow in this order:

1. Inspect the repository root and identify likely framework, language, and entry points.
2. Detect whether the project is likely:
   - web backend
   - web frontend
   - script / CLI
   - model inference service
   - training task
   - unknown
3. Determine a minimal install and start strategy.
4. Attempt to install dependencies only if required and feasible within time limit.
5. Attempt to start the project with a bounded timeout.
6. If a service starts successfully, execute a lightweight load test.
7. Collect metrics: startup time, CPU estimate, memory peak, response latency, throughput, error rate.
8. Infer a recommended resource profile.
9. Produce output JSON strictly matching the platform schema.

If any step fails:
- stop the current execution path safely
- record the failure reason
- still return a valid JSON object
```

### 8.5 建议 Job Input Prompt

这部分由平台在每次执行时动态拼接：

```text
Job context:
- benchmark_job_id: {{benchmark_job_id}}
- repository_path: /opt/benchmark/workspace/repo
- output_path: /opt/benchmark/workspace/output/benchmark_result.json
- max_total_runtime_seconds: 600
- start_timeout_seconds: 120
- benchmark_duration_seconds: 60
- allowed_ports: 3000, 5000, 8000, 8080
- preferred_output_language: zh-CN

Business goal:
- analyze the codebase
- estimate runtime requirements
- recommend suitable rental listings conservatively

Output requirements:
- write the final JSON result to the output path
- do not include markdown fences
- ensure the JSON is parseable
```

## 9. 建议的执行流程

```mermaid
sequenceDiagram
    participant Buyer as Buyer
    participant Frontend as Frontend
    participant Benchmark as BenchmarkJob Module
    participant Adapter as Swarm Adapter
    participant Worker as Benchmark Worker Node
    participant Container as Benchmark Service Container
    participant Store as Result Store

    Buyer->>Frontend: upload code / submit benchmark
    Frontend->>Benchmark: create BenchmarkJob
    Benchmark->>Adapter: create_benchmark_service(payload)
    Adapter->>Worker: schedule benchmark service
    Worker->>Container: start container
    Container->>Container: Claude Code Runner analyzes code
    Container->>Container: try start + try benchmark
    Container->>Store: write benchmark_result.json
    Benchmark->>Adapter: inspect_benchmark_service(service_id)
    Benchmark->>Store: read result
    Benchmark->>Adapter: remove_benchmark_service(service_id)
    Benchmark-->>Frontend: return status/result
```

## 10. 输入与输出

### 10.1 用户输入建议

本版补充一个关键前提：

- 买家发起 `BenchmarkJob` 时，输入源只允许二选一：
  - 上传完整代码压缩包
  - 提供 `git clone` 链接
- 当前阶段不要求买家提供 SSH 凭证；`git clone` 默认按公开仓库处理。

建议 `BenchmarkJob` 的输入字段保持简洁：

- `benchmark_job_id`
- `user_id`
- `source_type`
- `code_archive_token` 或共享卷路径
- `git_clone_url`
- `git_ref`
- `entry_hint`
- `expected_project_type`
- `notes`

解释：

- `entry_hint`：用户对启动方式的补充说明，例如“主程序在 backend/app.py”
- `expected_project_type`：可选值，例如 `web_service`、`script`、`unknown`
- `notes`：用户补充信息

### 10.1.1 推荐输入来源规则

- 当 `source_type = code_archive` 时，平台先保存压缩包，再把压缩包路径写入输入清单。
- 当 `source_type = git_repository` 时，平台把 `git_clone_url` 和 `git_ref` 写入输入清单，由 benchmark 容器内部执行 `git clone`。
- 对 `Claude Code Runner` 来说，二者最终都会变成同一个本地工作区目录。

### 10.2 容器内部标准输入文件

推荐平台把输入写成 `/opt/benchmark/workspace/input/job_context.json`：

```json
{
  "benchmark_job_id": "bj_20260317_0001",
  "user_id": "u_10001",
  "source_type": "code_archive",
  "code_archive_path": "/shared/benchmark/uploads/upload_abc_001.zip",
  "git_clone_url": null,
  "git_ref": null,
  "entry_hint": "main entry may be app.py",
  "expected_project_type": "web_service",
  "notes": "prefer conservative estimate",
  "limits": {
    "max_total_runtime_seconds": 600,
    "start_timeout_seconds": 120,
    "benchmark_duration_seconds": 60
  },
  "paths": {
    "repo_path": "/opt/benchmark/workspace/repo",
    "output_path": "/opt/benchmark/workspace/output/benchmark_result.json"
  }
}
```

对于 git 源，输入文件建议是：

```json
{
  "benchmark_job_id": "bj_20260317_0002",
  "user_id": "u_10001",
  "source_type": "git_repository",
  "code_archive_path": null,
  "git_clone_url": "https://github.com/example/demo-app.git",
  "git_ref": "main",
  "entry_hint": "server/index.js",
  "expected_project_type": "web_service",
  "notes": "benchmark from public repository",
  "limits": {
    "max_total_runtime_seconds": 600,
    "start_timeout_seconds": 120,
    "benchmark_duration_seconds": 60,
    "output_path": "/opt/benchmark/workspace/output/benchmark_result.json"
  }
}
```

benchmark 容器读取该文件后的第一步应固定为：

1. 如果 `source_type = code_archive`，先解压压缩包到工作区。
2. 如果 `source_type = git_repository`，先执行 `git clone`，必要时 checkout 到指定 `git_ref`。
3. 之后 `Claude Code Runner` 再继续做项目识别、尝试启动和轻量压测。

### 10.3 标准输出文件

推荐强制输出 3 个文件：

1. `benchmark_result.json`
2. `benchmark_summary.md`
3. `benchmark_execution.log`

其中平台真正依赖的是 `benchmark_result.json`。

### 10.4 benchmark_result.json 建议格式

建议冻结成如下结构：

```json
{
  "schema_version": "1.0",
  "benchmark_job_id": "bj_20260317_0001",
  "mode": "placeholder",
  "status": "succeeded",
  "project_profile": {
    "project_type": "web_service",
    "language": "python",
    "framework": "fastapi",
    "entry_guess": "uvicorn app:app --host 0.0.0.0 --port 8000",
    "confidence": 0.82
  },
  "execution_summary": {
    "install_attempted": true,
    "start_attempted": true,
    "load_test_attempted": true,
    "failure_reason": null,
    "warnings": []
  },
  "performance_metrics": {
    "startup_time_ms": 4200,
    "cpu_avg_pct": 48.5,
    "cpu_peak_pct": 92.0,
    "memory_avg_mb": 512,
    "memory_peak_mb": 890,
    "gpu_avg_pct": null,
    "gpu_peak_pct": null,
    "gpu_memory_peak_mb": null,
    "latency_p50_ms": 42,
    "latency_p95_ms": 110,
    "latency_p99_ms": 180,
    "throughput_rps": 126.4,
    "error_rate_pct": 0.4
  },
  "resource_recommendation": {
    "cpu_cores": 4,
    "memory_mb": 4096,
    "gpu_count": 0,
    "gpu_vram_mb": 0,
    "disk_mb": 2048,
    "network_level": "medium"
  },
  "listing_recommendation": {
    "recommended_listing_ids": [
      "nrl_1001",
      "nrl_1048",
      "nrl_1099"
    ],
    "selection_rationale": [
      "CPU recommendation matches 4 cores",
      "memory recommendation fits within 4GB-8GB range",
      "current platform price is competitive"
    ],
    "confidence": 0.76
  },
  "artifacts": {
    "summary_path": "/opt/benchmark/workspace/output/benchmark_summary.md",
    "log_path": "/opt/benchmark/workspace/output/benchmark_execution.log"
  }
}
```

### 10.5 失败时的输出格式

即便失败，也必须返回合法 JSON：

```json
{
  "schema_version": "1.0",
  "benchmark_job_id": "bj_20260317_0002",
  "mode": "claude_runtime",
  "status": "failed",
  "project_profile": {
    "project_type": "unknown",
    "language": "unknown",
    "framework": "unknown",
    "entry_guess": null,
    "confidence": 0.18
  },
  "execution_summary": {
    "install_attempted": true,
    "start_attempted": false,
    "load_test_attempted": false,
    "failure_reason": "Dependency installation failed: package lock missing and install command could not be inferred safely.",
    "warnings": [
      "requirements.txt not found",
      "package.json not found"
    ]
  },
  "performance_metrics": {
    "startup_time_ms": null,
    "cpu_avg_pct": null,
    "cpu_peak_pct": null,
    "memory_avg_mb": null,
    "memory_peak_mb": null,
    "gpu_avg_pct": null,
    "gpu_peak_pct": null,
    "gpu_memory_peak_mb": null,
    "latency_p50_ms": null,
    "latency_p95_ms": null,
    "latency_p99_ms": null,
    "throughput_rps": null,
    "error_rate_pct": null
  },
  "resource_recommendation": {
    "cpu_cores": 2,
    "memory_mb": 2048,
    "gpu_count": 0,
    "gpu_vram_mb": 0,
    "disk_mb": 1024,
    "network_level": "low"
  },
  "listing_recommendation": {
    "recommended_listing_ids": [],
    "selection_rationale": [
      "Benchmark failed before runtime profiling, recommendation is fallback-only."
    ],
    "confidence": 0.21
  },
  "artifacts": {
    "summary_path": "/opt/benchmark/workspace/output/benchmark_summary.md",
    "log_path": "/opt/benchmark/workspace/output/benchmark_execution.log"
  }
}
```

## 11. 与 Swarm Adapter 的结合方式

### 11.1 原则

`BenchmarkJob Module` 不能直接操作 Docker Swarm。  
所有 Swarm 操作必须经过 `Swarm Adapter`。

因此职责边界如下：

- `BenchmarkJob Module` 负责：
  - 创建业务任务
  - 准备输入文件
  - 调用 `Swarm Adapter`
  - 轮询状态
  - 读取结果文件
  - 生成前端返回
- `Swarm Adapter` 负责：
  - 创建 benchmark service
  - 查询 service 状态
  - 删除 service
  - 屏蔽 Docker SDK/CLI 细节

### 11.2 模块交互图

```mermaid
flowchart LR
    Frontend[Frontend]
    Benchmark[BenchmarkJob Module]
    Adapter[Swarm Adapter]
    Docker[Docker Swarm]
    Store[Shared Result Store]

    Frontend -->|HTTP| Benchmark
    Benchmark -->|internal call| Adapter
    Adapter -->|docker sdk / cli| Docker
    Docker -->|schedule container| Store
    Benchmark -->|read result| Store
    Benchmark -->|HTTP response| Frontend
```

### 11.3 建议的内部接口

建议 `Swarm Adapter` 至少对 `BenchmarkJob Module` 暴露以下内部接口：

```text
create_benchmark_service(payload)
inspect_benchmark_service(service_id)
remove_benchmark_service(service_id)
get_service_logs(service_id)
```

### 11.4 create_benchmark_service(payload) 建议结构

```json
{
  "benchmark_job_id": "bj_20260317_0001",
  "service_name": "benchmark-bj-20260317-0001",
  "image": "platform/benchmark-runner:latest",
  "env": {
    "BENCHMARK_JOB_ID": "bj_20260317_0001",
    "BENCHMARK_MODE": "claude_runtime",
    "JOB_CONTEXT_PATH": "/opt/benchmark/workspace/input/job_context.json",
    "RESULT_OUTPUT_PATH": "/opt/benchmark/workspace/output/benchmark_result.json"
  },
  "mounts": [
    {
      "type": "bind",
      "source": "/data/benchmark/jobs/bj_20260317_0001",
      "target": "/opt/benchmark/workspace"
    }
  ],
  "constraints": [
    "node.labels.platform_role == benchmark",
    "node.labels.benchmark_enabled == true"
  ],
  "resources": {
    "cpu_limit": 2,
    "memory_limit_mb": 4096
  },
  "restart_policy": {
    "condition": "none"
  }
}
```

### 11.5 inspect_benchmark_service(service_id) 返回建议

```json
{
  "ok": true,
  "service_id": "svc_benchmark_001",
  "service_status": "running",
  "task_status": "running",
  "node_id": "node_benchmark_01",
  "container_id": "ctr_001",
  "started_at": "2026-03-17T20:00:00Z",
  "finished_at": null,
  "error_code": null,
  "error_message": null
}
```

### 11.6 remove_benchmark_service(service_id) 返回建议

```json
{
  "ok": true,
  "service_id": "svc_benchmark_001",
  "removed": true,
  "error_code": null,
  "error_message": null
}
```

## 12. 对前端的接口建议

虽然你前面要求接口清单先不冻结，但 AI 测算专项文档里仍然建议先固定最小对前端接口。

### 12.0 上传代码压缩包

`POST /benchmark-jobs/code-archive-uploads`

请求方式建议使用 `multipart/form-data`，上传完整 zip 文件。

响应体建议：

```json
{
  "code_archive_token": "upload_abc_001",
  "filename": "demo-app.zip",
  "expires_at": "2026-03-18T10:30:00Z"
}
```

### 12.1 创建测算任务

`POST /benchmark-jobs`

请求体建议：

```json
{
  "source_type": "code_archive",
  "entry_hint": "main entry may be app.py",
  "expected_project_type": "web_service",
  "notes": "prefer conservative estimate",
  "code_archive_token": "upload_abc_001",
  "git_clone_url": null,
  "git_ref": null
}
```

对于 git 仓库输入，建议请求体是：

```json
{
  "source_type": "git_repository",
  "entry_hint": "server/index.js",
  "expected_project_type": "web_service",
  "notes": "benchmark from public repository",
  "code_archive_token": null,
  "git_clone_url": "https://github.com/example/demo-app.git",
  "git_ref": "main"
}
```

响应体建议：

```json
{
  "benchmark_job_id": "bj_20260317_0001",
  "status": "queued"
}
```

### 12.2 查询任务状态

`GET /benchmark-jobs/{benchmark_job_id}`

响应体建议：

```json
{
  "benchmark_job_id": "bj_20260317_0001",
  "status": "running",
  "mode": "claude_runtime",
  "progress_stage": "load_testing"
}
```

### 12.3 查询推荐结果

`GET /benchmark-jobs/{benchmark_job_id}/recommendations`

响应体建议直接返回 `benchmark_result.json` 的裁剪版：

```json
{
  "benchmark_job_id": "bj_20260317_0001",
  "status": "succeeded",
  "project_profile": {
    "project_type": "web_service",
    "language": "python",
    "framework": "fastapi"
  },
  "performance_metrics": {
    "startup_time_ms": 4200,
    "memory_peak_mb": 890,
    "throughput_rps": 126.4,
    "latency_p95_ms": 110
  },
  "resource_recommendation": {
    "cpu_cores": 4,
    "memory_mb": 4096,
    "gpu_count": 0
  },
  "listing_recommendation": {
    "recommended_listing_ids": [
      "nrl_1001",
      "nrl_1048",
      "nrl_1099"
    ]
  }
}
```

## 13. 内部状态建议

建议 `BenchmarkJob.status` 使用如下枚举：

- `queued`
- `preparing`
- `deploying`
- `running`
- `analyzing`
- `succeeded`
- `failed`
- `timeout`
- `cancelled`

建议 `progress_stage` 使用如下枚举：

- `workspace_preparing`
- `project_detecting`
- `dependency_installing`
- `service_starting`
- `load_testing`
- `result_emitting`

## 14. 推荐的异常处理原则

### 14.1 可接受失败

测算模块不是交易主链路，因此允许失败，但失败必须：

1. 状态清晰
2. 返回合法结果
3. 给出失败原因
4. 不影响市场租用流程

### 14.2 必须处理的异常

- 代码包解压失败
- benchmark service 创建失败
- benchmark service 长时间未启动
- 容器启动成功但结果文件未生成
- 压测工具执行失败
- JSON 输出格式错误
- service 删除失败

### 14.3 建议的兜底策略

如果 `claude runtime mode` 失败，可按以下顺序兜底：

1. 尝试读取部分日志并生成 `failed result`
2. 若结果文件不存在，由后端生成一份统一失败结构
3. 若系统配置允许，则退回到 `placeholder mode`

## 15. 安全与边界

因为测算要执行用户代码，这一模块必须比普通页面接口更谨慎。

最低要求：

- 限制代码包大小
- 限制执行总时长
- 限制可开放端口
- 限制网络访问策略
- 禁止宿主机敏感目录挂载
- benchmark 节点与卖家节点隔离
- 所有输出文件路径固定
- 所有结果必须可审计

当前阶段建议：

- 先不追求“真正高可信压测”
- 先保证结构、流程、状态、接口都成立
- 真实压测能力放在后续迭代增强

## 16. MVP 建议

对当前项目，最务实的推进顺序是：

1. 先实现 `placeholder mode`
2. 冻结 `benchmark_result.json` 结构
3. 打通前端提交与结果展示
4. 再实现 `Swarm Adapter` 的 benchmark service 创建/删除
5. 最后把 `Claude Code Runner` 接入容器

这样可以保证：

- 前端和业务流程先跑通
- 数据结构先冻结
- Swarm 集成边界先固定
- 复杂的代理执行能力后置

## 17. 本文档最终结论

1. AI 测算模块在 Swarm 里应设计为：`Benchmark Worker Node + Benchmark Service Container`
2. `Claude Code` 应内置在测算容器中，充当受限的代码分析与压测编排执行器
3. 当前项目必须保留 `placeholder mode` 与 `claude runtime mode` 双模式
4. `BenchmarkJob Module` 不直接操作 Swarm，必须通过 `Swarm Adapter`
5. 平台应优先冻结输出 JSON 结构，再逐步把真实能力填进去
6. `BenchmarkJob` 只负责推荐，不自动下单，不锁定资源

## 18. 推荐结果与实际状态不一致性

### 18.1 问题描述

`BenchmarkJob` 完成后推荐若干 `NodeRentalListing`，但从测算完成到买家查看推荐，这些 listing 的状态可能已变化。

### 18.2 解决方案

采用**乐观展示 + 下单时二次校验**：

1. 推荐结果是快照，不锁定节点
2. 前端展示时实时查询每个 listing 的当前状态
3. UI 标注：✅ 可租用 / ⚠️ 已被占用 / ❌ 已下架
4. 买家下单时后端再次校验

### 18.3 不采用预留方案的原因

- 预留会降低节点利用率
- 预留时长难以确定
- 可能被恶意利用

## 19. 资源隔离与安全防护

### 19.1 并发控制

- 全局最多 3 个并发任务
- 单用户最多 1 个运行中任务
- 超出限制进入队列

### 19.2 容器资源限制

```yaml
resources:
  limits:
    cpus: '2.0'
    memory: '4G'
  reservations:
    cpus: '1.0'
    memory: '2G'
```

### 19.3 安全配置

- `cap_drop: ['ALL']` - 移除所有 Linux capabilities
- `security_opt: ['no-new-privileges']` - 禁止提权
- 网络隔离：使用独立的 benchmark 网络
- 超时控制：默认 30 分钟

### 19.4 恶意代码防范

- 容器内禁用 privileged 模式
- 不挂载宿主机敏感目录
- 文件系统只读（除工作目录）
- 资源限制防止 DoS

