# Swarmpit 接入与运维控制台专项方案

## 1. 结论先行

`Swarmpit` 可以融入当前项目，但定位必须严格限制为：

- Docker Swarm 集群的管理员内部运维控制台
- `Runtime Reconcile` 超过自动处理阈值后的人工干预工具
- `Admin Dashboard` 的外部运维入口或扩展运维面板

`Swarmpit` 不得承担以下职责：

- 不替代 `Swarm Adapter`
- 不进入买家/卖家主业务链路
- 不直接承接订单、部署、退款、节点接入的业务状态推进
- 不作为平台领域数据的权威来源

原因如下：

- 当前项目规划已经明确规定：所有 Swarm 调用必须统一经由 `Swarm Adapter`
- `Swarmpit` 是独立的 Swarm 管理 UI，不是为当前平台业务模型定制的控制面
- `Swarmpit` 使用自己的技术栈和独立存储，不适合作为平台主业务后端内核
- `Swarmpit` 上游处于 maintenance mode，不适合承担平台核心依赖

---

## 2. 它在 Swarm 集群管理中的作用

`Swarmpit` 适合解决的问题是：

- 直接查看 Swarm cluster、node、service、task 的真实运行状态
- 查看 stack、network、volume、secret 等基础设施资源
- 进行人工排障时的 service 重启、下线、删除、回滚、日志查看
- 给管理员提供一套现成的 Swarm 运维界面

它更像：

- 集群运维台
- 人工排障台
- 应急处置台

它不像：

- 平台业务后端
- 订单调度内核
- 节点接入状态机
- 面向普通买家/卖家的产品页面

---

## 3. 与当前项目规划的对应关系

## 3.1 最直接对应的部分

### A. `Admin Dashboard`

最适合的主挂载点是：

- 管理员端 `Admin Dashboard`
- 管理员看到平台聚合快照之后，需要进一步跳到真实 Swarm 运维台做人工排查

因此建议把 `Swarmpit` 作为：

- `Admin Dashboard` 中的一个外部运维入口
- 或 `Admin Dashboard -> Cluster Ops` 子区域

### B. `Runtime Reconcile`

当 `Runtime Reconcile` 遇到以下情况时：

- 多次重试仍失败
- service 状态异常但平台无法自动修复
- 节点 drain / service remove / cleanup 失败
- 需要管理员查看真实 task、service log、node 状态

这时 `Swarmpit` 可以作为：

- 人工接管入口
- 故障排查工具
- 应急运维工具

### C. `Swarm Infrastructure`

`Swarmpit` 也适合放在：

- `infra/swarm/` 下作为配套运维工具栈

它对应的是：

- 基础设施运维层
- 不是业务适配层

## 3.2 不对应的部分

`Swarmpit` 不应对应到以下模块：

- `platform-backend/app/integrations/swarm/` 的核心 `Swarm Adapter`
- `platform-backend/app/modules/orders/`
- `platform-backend/app/modules/compute_nodes/`
- `platform-backend/app/modules/benchmark/`
- `platform-worker/app/tasks/reconcile/` 的自动决策逻辑

这些模块必须保留在平台自有代码中，原因是：

- 它们需要遵守平台自己的状态机、错误码、审计、权限和幂等规则
- `Swarmpit` 不理解平台的 `RentalOrder`、`Deployment`、`RuntimeEvent`、`BenchmarkJob` 等领域模型

---

## 4. 推荐接入方式

## 4.1 推荐方式：独立部署 + 管理员入口跳转

推荐第一阶段采用：

- 独立部署 `Swarmpit`
- 仅管理员和运维网络可访问
- 在平台管理员后台提供入口链接
- 新标签页打开或反向代理到独立路径

推荐原因：

- 对当前主业务系统侵入最小
- 升级、替换、下线成本最低
- 可以明确隔离权限和风险边界

## 4.2 次优方式：反向代理集成

可以在 `platform` 管理后台中通过 Nginx 反向代理暴露：

- `/admin/ops/swarmpit/`

但必须满足：

- 仅 admin 角色可见入口
- 网关层和网络层双重限制访问
- 不对 buyer / seller 暴露
- 不把 `Swarmpit` 的 session 误当作平台自身登录态

## 4.3 不推荐方式：深度嵌入主前端 iframe

不建议默认走 iframe 深嵌方案，原因是：

- session、CSRF、cookie、header 转发更复杂
- 出问题时不容易区分是平台问题还是 `Swarmpit` 问题
- 后续替换成本更高

如果确实要嵌入，只能放在：

- 管理员独占页面
- 明确标记为外部运维控制台

---

## 5. 推荐落地位置

## 5.1 基础设施目录

建议新增：

```text
Pivot_Computing_Power_Network/
  infra/
    swarm/
      swarmpit/
        docker-compose.yml
        .env.example
        README.md
        nginx/
        scripts/
```

建议文件职责：

- `docker-compose.yml`
  - 部署 `app + agent + db + influxdb`
- `.env.example`
  - `Swarmpit` 基本环境变量与访问说明
- `README.md`
  - 部署方式、端口、管理员初始化方式、风险说明
- `nginx/`
  - 反向代理示例配置
- `scripts/`
  - 启停、备份、健康检查脚本

## 5.2 后端接入点

建议在平台后端增加一个很薄的 admin 运维配置接口：

- `platform-backend/app/api/admin/ops.py`
- `platform-backend/app/modules/admin_dashboard/ops_console_service.py`

职责仅限于：

- 返回 `Swarmpit` 是否启用
- 返回 `Swarmpit` 外部访问地址
- 返回运维入口文案和安全提示

不要做：

- 不要把 `Swarmpit` API 当成平台业务 API 转发
- 不要把 `Swarmpit` 的 service/node 操作封装成订单业务接口

## 5.3 前端接入点

建议在管理员前端新增：

- `platform-frontend/src/modules/admin-dashboard/ops-console/`
- `platform-frontend/src/pages/AdminDashboardPage/`

可包含：

- Cluster Ops 卡片
- “打开 Swarmpit 运维台”按钮
- 风险说明
- 最近人工接管事件列表

## 5.4 Runtime Reconcile 对接点

建议在：

- `platform-backend/app/modules/runtime_events/`
- `platform-backend/app/application/reconcile/`

补充人工接管字段和动作：

- `manual_intervention_required`
- `manual_intervention_reason`
- `manual_intervention_ref`
- `manual_intervention_status`

其中 `manual_intervention_ref` 可以指向：

- `Swarmpit` 中的 node id
- service id
- stack name

这样管理员从风险事件可以直接跳到对应的运维对象。

---

## 6. 环境要求

接入 `Swarmpit` 需要额外准备：

- 已初始化的 Docker Swarm 集群
- 至少 1 个 manager 节点
- `Swarmpit app`
- `Swarmpit agent`
- `CouchDB`
- `InfluxDB`
- 持久化卷

推荐附加约束：

- `app` 固定部署在 manager 节点
- `agent` 使用 global mode
- 访问仅限管理网段或 VPN
- 尽量通过 socket proxy 而不是直接暴露 docker.sock

---

## 7. 具体实施步骤

## 步骤 1：作为独立运维工具先落基础设施

需要做：

- 在 `infra/swarm/swarmpit/` 放置部署文件
- 固定端口、网络、卷和 manager placement
- 明确管理员初始化流程

要求：

- 能独立部署，不依赖平台主后端启动
- 部署失败不会影响平台主链路

## 步骤 2：在管理员后台增加入口

需要做：

- 后端增加启用状态和入口地址配置接口
- 前端 `Admin Dashboard` 增加运维入口卡片

要求：

- 只有管理员能看到入口
- 页面明确标识“外部运维控制台”

## 步骤 3：接入人工介入流程

需要做：

- `Runtime Reconcile` 超过阈值后把事件转为人工介入
- 事件详情展示 `Swarmpit` 跳转引用

要求：

- 人工介入只是排障入口，不直接替代平台状态写入
- 最终平台状态仍应回写到平台数据库和审计日志

## 步骤 4：增加安全边界

需要做：

- 管理网段访问限制
- 反向代理访问控制
- 非 admin 不展示入口
- 独立账号或独立认证策略

要求：

- 不允许 buyer / seller 接触到 Swarm 原生控制台
- 不允许平台普通接口透传 `Swarmpit` 高危操作

## 步骤 5：明确替换策略

需要做：

- 在文档中标明 `Swarmpit` 为可替换运维系统
- 不把平台主流程耦合到它的 API 或存储

要求：

- 后续即使替换成 Portainer 或自研运维台，也不影响业务后端

---

## 8. 需要达成的边界约束

必须满足：

1. 所有订单、部署、benchmark、节点接入仍只经平台业务后端和 `Swarm Adapter`
2. `Swarmpit` 只用于管理员查看、排障、人工操作
3. 平台数据库仍是业务真相源，`Swarmpit` 不是
4. 所有人工介入动作必须在平台侧留下审计记录或事件备注
5. `Swarmpit` 不得暴露给普通用户

---

## 9. 测试方法

## 9.1 基础设施测试

- 部署测试：`Swarmpit` 组件能正常启动
- 健康检查：app、agent、db、influxdb 全部健康
- 集群可见性测试：manager、worker、service、task 可正确展示

## 9.2 权限测试

- 平台前端：非 admin 不显示入口
- 平台后端：非 admin 无法读取 ops console 配置
- 网络访问：未授权来源不能直接打开 `Swarmpit`

## 9.3 集成测试

- 管理员登录平台 -> 打开 `Swarmpit` 入口成功
- `Runtime Reconcile` 事件转人工后，事件详情能关联到对应 node/service
- `Swarmpit` 下人工处理后，平台可通过下一轮巡检同步真实状态

## 9.4 回归测试

- `Swarmpit` 不在交易主链路中，关闭或故障时平台下单与部署流程不受影响
- 平台自动部署和回收逻辑不依赖 `Swarmpit`
- 管理员大盘在 `Swarmpit` 不可用时仍能显示自身快照数据

## 9.5 建议测试位置

- `tests/smoke/test_swarmpit_stack.py`
- `platform-backend/tests/api/test_admin_ops_console.py`
- `platform-frontend/tests/e2e/admin-ops-console.spec.ts`
- `platform-backend/tests/integration/test_runtime_event_manual_intervention.py`

---

## 10. 风险与限制

接入 `Swarmpit` 时必须接受以下事实：

- 上游维护强度有限，不适合承担核心控制面
- 技术栈与平台主栈不同，深度改造成本高
- 自带 `CouchDB + InfluxDB`，运维复杂度高于“只接一个 UI”
- 其权限模型无法直接映射到平台业务角色

因此本项目对它的正确用法只能是：

- 辅助运维系统
- 人工接管工具
- 可替换的外围能力

---

## 11. 最终建议

推荐决策如下：

1. 接入 `Swarmpit`
2. 但只接到 `infra/swarm/` 和 `Admin Dashboard / Runtime Reconcile` 的人工运维链路
3. 不让任何核心业务逻辑依赖它
4. 先用“独立部署 + 管理员入口跳转”的低耦合方案
5. 等平台主链路稳定后，再决定是否继续保留它或替换为别的运维台
