# 复杂独立模块专项文档 实施计划

## 1. 目录目标

本目录对应 5 个复杂度最高、最容易设计跑偏的核心专项模块，以及 1 个可选接入的运维配套系统：

- `Swarm Adapter`
- `BenchmarkJob`
- `PricingEngine`
- `Runtime Reconcile`
- `Admin Dashboard`
- `Swarmpit Ops Console（配套）`

这些模块的共同特点是：

- 都跨越多个业务模块
- 都涉及外部系统或聚合计算
- 都不能写成 Controller 里的临时逻辑
- 都必须优先冻结边界、输入输出和失败策略

当前项目中，这些模块在现有代码里基本没有真正落地，因此应在新平台目录中独立实现，而不是继续塞进现有 `system-template` 或门户壳系统。

其中凡是涉及前端展示面的部分，必须额外遵守：

- 前端实现优先落地到独立 `platform-frontend`，当前阶段不要求先适配旧 `system-template/system-vue`
- 页面落点、页面职责和跳转方式必须与 `../前端/前端页面规划文档.md` 保持一致，不能因专项模块需要而自行改写总体页面结构
- 前端代码必须遵守分层约束：页面 UI 不直接写网络请求和复杂业务规则，专项模块的页面流程应落在 page model / service / store 层中

同时，本目录中的 Mermaid 图和表格必须被视为专项模块边界定义：

- Mermaid 图用于固定复杂模块的输入输出、调用顺序、依赖方向和失败回退路径
- 表格用于固定能力清单、接口矩阵、限制条件、测试矩阵和可替换边界

专项模块一旦调整输入输出、依赖边界、回退策略、运行模式或运维职责，必须同步修改 Mermaid 图和表格，否则很容易再次把模块边界写散。

---

## 2. 当前项目中的建议落点

建议在 `../../Pivot_Computing_Power_Network` 下新增并使用如下目录：

```text
platform-backend/
  app/
    integrations/
      swarm/
      market_refs/
    modules/
      benchmark/
      pricing/
      admin_dashboard/
      runtime_events/
    application/
      deployments/
      reconcile/
  tests/

platform-worker/
  app/
    tasks/
      benchmark/
      pricing/
      reconcile/
      metrics/
  tests/

platform-benchmark/
  runner/
  prompts/
  scripts/
  schemas/

infra/
  docker/
  nginx/
  swarm/
    swarmpit/
```

---

## 3. 模块级实施方案

## 3.1 Docker Swarm 与 Swarm Adapter

依据 [Docker Swarm 与 Swarm Adapter 专项设计文档.md](./Docker Swarm 与 Swarm Adapter 专项设计文档.md)，本项目必须固定以下实现原则：

- 平台自己控制 `Swarm Manager`
- 卖家节点只作为 `Swarm Worker`
- 买家运行实例使用 `replicated service` 且 `replicas = 1`
- 所有 Swarm 调用必须走 `Swarm Adapter`
- `Swarm Adapter` 只做适配，不做业务决策

### 实现位置

- `platform-backend/app/integrations/swarm/facade.py`
- `platform-backend/app/integrations/swarm/commands.py`
- `platform-backend/app/integrations/swarm/sdk_wrapper.py`
- `platform-backend/app/integrations/swarm/schemas.py`
- `platform-worker/app/integrations/swarm/`
- `infra/swarm/`：本地 mock、示例脚本、节点标签约定

### 需要实现的能力

- worker join 命令生成
- 节点查询、存在性校验、标签写入、availability 更新
- 节点真实硬件信息查询，用于和卖家本地上报做交叉校验
- runtime service 创建、查询、删除、网页入口检查
- benchmark service 创建、查询、删除
- 标准化返回结构和标准化错误码

### 达成要求

- 业务层不直接接触 Docker CLI/SDK
- 业务层能拿到统一的标准化 node/service 状态
- Swarm provider 可替换，业务层不变
- 如果接入 `Swarmpit`，它只能作为管理员运维控制台，不得替代 `Swarm Adapter`

### 测试方法

- 契约测试：mock adapter 与真实 adapter 返回结构一致
- 集成测试：创建 runtime service 和 benchmark service 的参数翻译正确
- 故障测试：节点不存在、service pending、service missing、标签写入失败
- 超时/重试测试：节点接入和 service inspect 有稳定重试策略
- 安全边界测试：卖家伪造硬件信息时被检测到不一致

### 测试位置

- `platform-backend/tests/contracts/test_swarm_adapter_contract.py`
- `platform-backend/tests/integration/test_runtime_service_creation.py`
- `platform-backend/tests/integration/test_benchmark_service_creation.py`
- `platform-worker/tests/integration/test_swarm_retry_policy.py`

## 3.2 AI测算与 BenchmarkJob

依据 [AI测算与 BenchmarkJob 专项设计文档.md](./AI测算与 BenchmarkJob 专项设计文档.md)，本模块必须固定为：

- 专用 `Benchmark Worker Node`
- 调度出的 `Benchmark Service Container`
- 内置 `Claude Code Runner`
- 双模式：`placeholder` 和 `claude_runtime`

并且业务定位只能是“辅助推荐”，不能自动下单，不能锁定资源。

### 实现位置

- `platform-backend/app/modules/benchmark/`
- `platform-worker/app/tasks/benchmark/`
- `platform-benchmark/runner/`
- `platform-benchmark/prompts/`
- `platform-benchmark/schemas/benchmark_result.schema.json`

### 需要实现的能力

- 代码压缩包上传与 git 仓库输入
- 统一生成 input manifest / job_context
- benchmark job 状态机
- placeholder mode 结果生成
- claude runtime mode 容器执行
- 结果文件读取与 recommendation 回写
- 安全解压、依赖缓存、分阶段超时、卷挂载持久化
- 资源隔离、非特权运行、最小网络暴露

### 达成要求

- 无论成功失败，都产出合法 JSON 结果
- 前端不感知底层是 placeholder 还是真实运行
- benchmark 失败不影响交易主链路
- benchmark 容器不会因为恶意代码拖垮宿主机或吞掉结果文件

### 测试方法

- 单元测试：输入清单生成、结果 JSON 解析、推荐映射
- 契约测试：`benchmark_result.json` 必须符合 schema
- 集成测试：job 创建 -> service 调度 -> 结果回写
- 故障测试：代码包无效、git 地址无效、service 未启动、结果文件缺失、JSON 非法
- 模式切换测试：placeholder 与 runtime 使用同一对外 API
- 安全测试：zip bomb、过深目录、过多文件、结果文件在容器销毁前已落盘
- 资源测试：CPU/内存超限、网络限制、只读根文件系统

### 测试位置

- `platform-backend/tests/unit/test_benchmark_manifest.py`
- `platform-backend/tests/unit/test_benchmark_result_parser.py`
- `platform-worker/tests/integration/test_benchmark_job_flow.py`
- `platform-worker/tests/integration/test_benchmark_failure_fallback.py`
- `platform-benchmark/schemas/benchmark_result.schema.json`

## 3.3 PricingEngine

依据 [后端定价模块与 PricingEngine 专项设计文档.md](./后端定价模块与 PricingEngine 专项设计文档.md)，本模块对外只应暴露两个主接口：

- `quote_unit_price(pricing_input)`
- `calculate_runtime_total(runtime_pricing_input)`

并采用：

- 外部异步抓价
- 内部归一化
- 快照缓存读取
- 规则引擎计算

### 实现位置

- `platform-backend/app/modules/pricing/`
- `platform-backend/app/integrations/market_refs/`
- `platform-worker/app/tasks/pricing/`

建议进一步拆分：

- `resolver.py`
- `normalizer.py`
- `rule_engine.py`
- `explanation.py`
- `service.py`

### 需要实现的能力

- 外部参考价格抓取
- 市场报价归一化
- 价格快照写入
- listing 单位时价计算
- deployment 实际运行总价计算
- 新鲜度与过期回退

### 达成要求

- 页面请求不直接联网抓价格
- 价格输出包含来源、解释、新鲜度
- 订单结算只依赖冻结后的价格快照，不依赖实时重算

### 测试方法

- 单元测试：组件价、基准价、加权中位数、计费粒度、最小时长
- 集成测试：抓价任务 -> 归一化 -> 快照入库 -> 业务读取
- 回退测试：外部价格源失败时读取旧快照或本地组件价格表
- API 测试：listing 查询返回 price_status 与价格解释
- 结算测试：不同运行时长、不同计费粒度、边界取整

### 测试位置

- `platform-backend/tests/unit/test_pricing_rule_engine.py`
- `platform-backend/tests/unit/test_runtime_billing.py`
- `platform-worker/tests/integration/test_reference_quote_refresh.py`
- `platform-backend/tests/integration/test_listing_price_snapshot_usage.py`

## 3.4 Runtime Reconcile

依据 [轮询状态与 Runtime Reconcile 专项设计文档.md](./轮询状态与 Runtime Reconcile 专项设计文档.md)，本模块必须固定：

- 后端主动轮询是唯一异常发现来源
- 前端轮询只能读后端结果
- `Swarm Adapter` 只负责看真实 Swarm 状态
- 订单和部署状态写入必须回到业务模块

### 实现位置

- `platform-worker/app/tasks/reconcile/`
- `platform-backend/app/application/reconcile/`
- `platform-backend/app/modules/runtime_events/`
- `platform-backend/app/modules/orders/`

建议内部拆分：

- `target_loader.py`
- `inspector.py`
- `classifier.py`
- `event_writer.py`
- `abnormal_apply_service.py`

### 需要实现的能力

- 定时扫描运行中订单与部署
- 调用 `Swarm Adapter` 获取 node / service 真实状态
- 分类异常：`node_offline`、`deployment_lost`、`state_mismatch`、`release_failed`
- 创建 `RuntimeEvent`
- 推进节点、订单、部署、退款、补偿
- 防止异常处理循环依赖和事件风暴

### 达成要求

- 异常链路单点收口
- 同一个异常事实同时服务买家页和管理员页
- 节点异常时可自动 `drain`
- 清理动作采用最佳努力策略，重试次数可控，超阈值后转人工处理

### 测试方法

- 单元测试：异常分类规则
- 集成测试：数据库状态与 Swarm 状态不一致时的修正路径
- Worker 测试：巡检任务每轮只处理目标集合，异常正确落事件
- 故障测试：inspect 失败、节点离线、service missing、退款失败、重复处理
- 幂等测试：同一异常多轮巡检不会重复多次退款
- 循环保护测试：`remove_runtime_service()` 失败时不会无限生成新事件

### 测试位置

- `platform-worker/tests/unit/test_runtime_classifier.py`
- `platform-worker/tests/integration/test_reconcile_job_flow.py`
- `platform-backend/tests/integration/test_runtime_event_apply.py`
- `platform-backend/tests/integration/test_refund_idempotency.py`

## 3.5 Admin Dashboard

依据 [管理员模块与 Admin Dashboard 专项设计文档.md](./管理员模块与 Admin Dashboard 专项设计文档.md)，该模块必须是：

- 管理员独立入口
- 只读聚合模块
- 默认读取 `Metric Snapshot / Cache`
- 支持大量 widget 和大屏可视化

### 实现位置

- `platform-backend/app/modules/admin_dashboard/`
- `platform-worker/app/tasks/metrics/`
- `platform-frontend/src/views/platform/modules/admin-dashboard/`

建议后端细分：

- `overview_api.py`
- `nodes_api.py`
- `market_api.py`
- `orders_api.py`
- `benchmarks_api.py`
- `risk_api.py`
- `audit_api.py`

### 需要实现的能力

- 平台 KPI 聚合
- 节点负载矩阵
- 市场与价格聚合
- 订单与部署运行态聚合
- benchmark 统计
- 风险事件聚合
- 审计时间线
- 统一快照读取、批量加载和限流保护

### 达成要求

- 总览页默认不直连事实表拼重 SQL
- 各 widget 可独立刷新、独立失败、独立重试
- 管理员权限与普通用户权限彻底隔离
- 节点详情输出使用字段白名单
- 时间窗口参数有上限
- Dashboard 能通过统一快照接口保证同一时间点数据一致

### 测试方法

- 单元测试：聚合器和快照 builder
- 集成测试：collector 从事实表生成 snapshot/cache
- API 测试：overview 和各 widget 接口结构稳定
- 前端测试：区块独立加载、失败隔离、自动刷新
- E2E 测试：管理员登录 -> 查看 overview -> 查看节点/风险/订单区块
- 压测：批量加载和并发打开 dashboard 时不会触发请求雪崩

### 测试位置

- `platform-worker/tests/unit/test_metric_collectors.py`
- `platform-worker/tests/integration/test_snapshot_refresh_jobs.py`
- `platform-backend/tests/api/test_admin_dashboard_overview.py`
- `platform-frontend/src/__tests__/platform/admin-dashboard-overview.spec.js`
- `platform-frontend/tests/e2e/platform-admin-dashboard.spec.ts`

## 3.6 Swarmpit Ops Console（配套，不进入主链路）

依据 [Swarmpit 接入与运维控制台专项方案.md](./Swarmpit 接入与运维控制台专项方案.md)，本项目如接入 `Swarmpit`，必须固定以下边界：

- 它是 Docker Swarm 集群的管理员内部运维控制台
- 它只服务 `Admin Dashboard` 和 `Runtime Reconcile` 的人工介入链路
- 它不替代 `Swarm Adapter`
- 它不进入买家/卖家主业务路径
- 它不是平台业务真相源

### 实现位置

- `infra/swarm/swarmpit/`
- `platform-backend/app/api/admin/ops.py`
- `platform-backend/app/modules/admin_dashboard/ops_console_service.py`
- `platform-backend/app/modules/runtime_events/`
- `platform-frontend/src/views/platform/modules/admin-dashboard/ops-console/`

### 需要实现的能力

- 独立部署 `Swarmpit app + agent + db + influxdb`
- 管理员后台提供运维入口
- 风险事件与人工介入记录可关联到对应 node/service
- 非 admin 不可见、不可访问
- 平台可在 `Swarmpit` 不可用时继续运行核心业务链路

### 达成要求

- `Swarmpit` 关闭或故障时，不影响订单、部署、benchmark、节点接入主流程
- 管理员可从风险事件跳转到对应 Swarm 运维对象
- 所有最终业务状态仍由平台后端和 `Runtime Reconcile` 写回
- `Swarmpit` 为可替换外围工具，不与核心业务代码耦合

### 测试方法

- 基础设施 smoke：stack 可启动、manager/worker/service 可见
- 权限测试：非 admin 不显示入口、不返回配置
- 集成测试：人工介入事件可跳转到对应运维对象
- 回归测试：`Swarmpit` 不可用时平台主链路仍可运行

### 测试位置

- `tests/smoke/test_swarmpit_stack.py`
- `platform-backend/tests/api/test_admin_ops_console.py`
- `platform-backend/tests/integration/test_runtime_event_manual_intervention.py`
- `platform-frontend/tests/e2e/platform-admin-ops-console.spec.ts`

---

## 4. 这五个核心专项模块的依赖顺序

必须按下面顺序推进：

1. `Swarm Adapter`
2. `PricingEngine`
3. `BenchmarkJob`
4. `Runtime Reconcile`
5. `Admin Dashboard`

原因：

- `Swarm Adapter` 是 runtime、benchmark、reconcile 的共同底座
- `PricingEngine` 先冻结，listing 和订单价格才不会反复改
- `BenchmarkJob` 需要依赖 `Swarm Adapter`
- `Runtime Reconcile` 需要依赖 `Swarm Adapter` 和订单主链路
- `Admin Dashboard` 依赖前面所有模块的事实数据和快照

补充说明：

- `Swarmpit Ops Console` 不进入上述核心依赖链
- 它属于 P1 运维配套项，建议在 `Swarm Adapter`、`Runtime Reconcile`、`Admin Dashboard` 初版稳定后接入
- 如需提前部署，也必须保持与主业务代码解耦

---

## 5. 分阶段实施建议

## 阶段 A：先冻结输入输出与契约

需要做：

- 冻结 Swarm Adapter 标准返回结构
- 冻结 `benchmark_result.json` schema
- 冻结 `quote_unit_price()` 与 `calculate_runtime_total()` 输入输出
- 冻结 `RuntimeEvent` 分类结果结构
- 冻结 `GET /admin/dashboard/overview` 输出结构

## 阶段 B：先做 mock / placeholder 版本

需要做：

- mock Swarm adapter
- placeholder benchmark mode
- 内部参考价和占位快照
- mock metric snapshot

目的：

- 前后端和业务流程先跑通
- 专项模块先建立稳定边界

## 阶段 C：接真实外部能力

需要做：

- 接真实 Docker Swarm
- 接 benchmark runner 容器
- 接外部参考价格源
- 接真实 reconcile 任务和 metric collector
- 按需独立部署 `infra/swarm/swarmpit/`

## 阶段 D：补容错和补偿

需要做：

- 重试
- 超时
- stale fallback
- compensation / refund 幂等
- snapshot 缓存回退

---

## 6. 统一测试原则

本目录的模块都不是“只写 happy path 就能交付”的模块，必须同步验证以下场景：

- 正常成功
- 外部依赖失败
- 部分成功
- 超时
- 并发
- 幂等重试
- 结果结构合法但内容失败

并且根据 `问题` 目录新增以下专项回归：

- `Swarm Adapter`：节点硬件校验、接入重试、实时容器状态校验
- `BenchmarkJob`：zip bomb、防逃逸、结果文件持久化、阶段超时
- `Runtime Reconcile`：事件去重、重试上限、人工介入分流
- `Admin Dashboard`：统一快照、字段脱敏、限流与批量加载
- `Swarmpit Ops Console`：管理员入口隔离、平台主链路解耦、人工接管跳转可用

额外要求：

- 所有外部系统返回必须做契约测试
- 所有异步任务必须测成功、失败、重试三条路径
- 所有聚合接口必须测字段稳定性，防止前端大屏联调回归

---

## 7. 当前阶段结论

这组专项模块决定平台是否“像一个真正的平台”，但不应该最先追求全部真实能力。当前项目最稳的落地方式是：

1. 先把适配边界、标准结构、状态流转写死
2. 先用 mock / placeholder 打通全链路
3. 再逐步替换成真实 Swarm、真实 benchmark、真实聚合

如果直接跳过这一层，后续最容易出现的问题就是：

- Docker 细节污染业务层
- 测算结果结构反复变
- 价格无法追溯
- 异常和退款链路失控
- 管理员大屏接口反复返工

额外需要明确：

- `问题` 目录中被标记为“安全攻击类、MVP可暂缓”的事项，仍需在本目录计划中预留上线前整改槽位：
  - bootstrap token 不明文出现在命令行
  - git clone 白名单 / SSRF 防护
  - connect_url 访问次数或绑定控制
- `Swarmpit` 若接入，只能作为外围运维系统；后续可替换，但不得沉淀成平台核心依赖
