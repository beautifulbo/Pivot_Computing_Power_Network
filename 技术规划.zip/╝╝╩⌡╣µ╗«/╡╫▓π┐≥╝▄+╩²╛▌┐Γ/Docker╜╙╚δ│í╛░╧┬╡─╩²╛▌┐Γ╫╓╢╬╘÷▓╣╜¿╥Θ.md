# Docker 接入场景下的数据库字段增补建议

版本：V1.0  
日期：2026-03-20  
定位：作为 [数据库设计文档.md](D:\Pivot_Computing_Power_Network\技术规划\底层框架+数据库\数据库设计文档.md) 的补充说明，专门回答“真实 Docker / Docker Swarm 接入时，现有字段是否够用、还需要补什么”。

---

## 1. 文档目的

当前 `数据库设计文档.md` 中的 `compute_node_bootstrap_sessions`、`compute_nodes`、`node_rental_listings` 已经能够支撑：

- 卖家创建 bootstrap session
- 本地执行 join
- 本地调用 `register-self`
- 平台认领 `Swarm Worker`
- 自动创建 `ComputeNode`
- 自动创建 `NodeRentalListing`

也就是说，**对于 MVP 的“核心流程 1：接入”主链路，现有字段总体是够用的。**

但是，当接入目标从“同质化的 mock 节点”变成“真实的多种 Docker 环境”后，会出现新的问题：

- 仅凭 `cpu_cores / memory / gpu_count` 无法充分验证节点真实性
- 不同 Docker Engine / runtime / 驱动能力会影响后续部署与调度
- 卖家本地上报信息与 Swarm 侧探测信息可能冲突
- 节点能否运行 GPU 容器、能否跑特定镜像、能否暴露网页入口，不能只靠当前主表字段判断

因此，本文件的目标不是推翻当前设计，而是明确：

1. 现有字段哪些已经够用
2. 哪些缺口会在真实 Docker 接入时暴露
3. 推荐补哪些字段或新表
4. 哪些属于 `P0`，哪些可以延后到 `P1`

---

## 2. 基于三节点接入模拟得到的结论

针对当前项目代码，我已按现有 `Swarm Adapter + ComputeNode Access` 设计模拟了一个卖家接入三套不同配置 Docker 节点的场景：

- 节点 A：`16C / 64GB / RTX 4090 x1 / 300Mbps / cn-shanghai`
- 节点 B：`16C / 64GB / L40S x1 / 1000Mbps / cn-guangzhou`
- 节点 C：`32C / 128GB / A100 80GB x2 / 600Mbps / cn-beijing`

模拟结论如下：

### 2.1 当前字段足以完成接入闭环

现有表已经足以记录：

- 多个 bootstrap session
- 同一卖家名下多台 `ComputeNode`
- 不同硬件配置
- Swarm 节点 ID 与节点标签
- 自动生成的 listing 元数据与初始价格

所以从“接入能不能做成”这个角度看，答案是：**能。**

### 2.2 当前字段的主要问题不是“存不下”，而是“表达不够细”

当前 `compute_nodes` 能存：

- `cpu_model`
- `gpu_model`
- `gpu_memory_mb`
- `arch`
- `os_type`
- `hardware_profile_json`
- `swarm_labels_json`

因此“节点配置本身”并没有存储空间不足的问题。

真正的问题是：**当前 schema 缺少对 Docker 运行时能力的结构化表达。**

例如以下信息，后续调度和部署会真正依赖，但现在没有专门字段：

- Docker Engine 版本
- Docker API 版本
- containerd 版本
- 默认 runtime
- 是否存在 `nvidia` runtime
- GPU 驱动版本
- CUDA 版本
- storage driver
- cgroup driver
- rootless 模式
- 网络驱动 / volume driver 能力
- 是否支持特定端口暴露方式
- daemon 关键配置摘要

### 2.3 当前还缺少“卖家上报”和“平台探测”的对比结构

三节点模拟里暴露出一个很典型的问题：

- 节点 B 的业务 `region_code = cn-guangzhou`
- 但来自 mock Swarm label 的 `pivot.region = cn-shanghai`

这说明系统已经可以同时接收两份信息，但：

- 目前没有专门字段表示“哪份是真相源”
- 没有记录“冲突是否已人工确认”
- 没有记录“探测结果 vs 上报结果”的详细差异

如果后续接入真实 Docker，这类冲突会更多：

- 卖家说有 GPU，但 runtime 实际没有 `nvidia` runtime
- 卖家说是 `A100 80GB`，但本地驱动或设备名并不一致
- 卖家说能跑网页服务，但平台网关或端口策略不支持

---

## 3. 总体建议

建议保持以下原则：

### 3.1 `compute_nodes` 继续只存“业务主视图”

`compute_nodes` 主表应继续保持简洁，只保留：

- 归属关系
- 节点基础资源摘要
- 业务状态
- 最常用的筛选字段

不要把所有 Docker 原始探测结果都堆进 `compute_nodes` 主表。

### 3.2 真实 Docker 运行时能力应拆独立表

建议新增一张专门的运行时能力表，例如：

- `compute_node_runtime_capabilities`

它负责记录：

- Docker 运行时版本信息
- runtime / driver / network / storage 能力
- 平台实际探测到的事实快照
- 是否满足平台接入要求

### 3.3 “上报值”和“探测值”要分开存

建议新增一张接入验证结果表，或在 bootstrap session 侧补 JSON 字段，专门存：

- 卖家本地上报的原始事实
- Swarm / 平台探测到的原始事实
- 差异比对结果
- 最终是否通过

这部分不要仅靠 `activity_logs.detail_json` 临时兜底。

---

## 4. 推荐的最小增补方案

## 4.1 新增表：`compute_node_runtime_capabilities`

### 4.1.1 设计目标

这张表用于描述一个 `ComputeNode` 在“真实 Docker 运行时”层面的能力，而不是业务层的租赁状态。

### 4.1.2 推荐字段

| 字段名 | 类型 | 约束 | 说明 |
|---|---|---|---|
| id | BIGINT UNSIGNED | PK | 主键 |
| compute_node_id | BIGINT UNSIGNED | NOT NULL, FK, UK | 对应节点 |
| docker_engine_version | VARCHAR(64) | NULL | Docker Engine 版本 |
| docker_api_version | VARCHAR(32) | NULL | Docker API 版本 |
| containerd_version | VARCHAR(64) | NULL | containerd 版本 |
| kernel_version | VARCHAR(128) | NULL | 宿主机内核版本 |
| os_distribution | VARCHAR(128) | NULL | 发行版信息 |
| default_runtime | VARCHAR(64) | NULL | 默认 runtime |
| available_runtimes_json | JSON | NULL | 可用 runtimes |
| has_nvidia_runtime | TINYINT(1) | NOT NULL DEFAULT 0 | 是否具备 nvidia runtime |
| nvidia_driver_version | VARCHAR(64) | NULL | NVIDIA 驱动版本 |
| cuda_version | VARCHAR(64) | NULL | CUDA 版本 |
| storage_driver | VARCHAR(64) | NULL | 存储驱动 |
| cgroup_driver | VARCHAR(64) | NULL | cgroup 驱动 |
| logging_driver | VARCHAR(64) | NULL | 日志驱动 |
| rootless_enabled | TINYINT(1) | NOT NULL DEFAULT 0 | 是否 rootless |
| network_drivers_json | JSON | NULL | 网络驱动列表 |
| volume_drivers_json | JSON | NULL | 卷驱动列表 |
| daemon_features_json | JSON | NULL | daemon 关键能力摘要 |
| validation_status | VARCHAR(16) | NOT NULL | pending/passed/failed/warn |
| validation_message | VARCHAR(255) | NULL | 校验结论说明 |
| last_detected_at | DATETIME(3) | NULL | 最近探测时间 |
| created_at | DATETIME(3) | NOT NULL | 创建时间 |
| updated_at | DATETIME(3) | NOT NULL | 更新时间 |

### 4.1.3 用途

这张表主要解决下面几类问题：

- 某节点是否真的支持 GPU runtime
- 某节点能否运行平台要求的镜像
- 某节点是否因 Docker / 驱动版本过旧而只能标记为 `warn`
- Runtime Reconcile 与调度时，能否更稳定判断“节点不可部署”的原因

### 4.1.4 推荐索引

- `UK_compute_node_runtime_capabilities_node(compute_node_id)`
- `IDX_runtime_capabilities_validation(validation_status, updated_at DESC)`

---

## 4.2 新增表：`compute_node_registration_verifications`

### 4.2.1 设计目标

该表专门记录一次接入验证过程的“上报事实 / 探测事实 / 差异结果”，避免把所有比对逻辑只塞进 bootstrap session 或日志。

### 4.2.2 推荐字段

| 字段名 | 类型 | 约束 | 说明 |
|---|---|---|---|
| id | BIGINT UNSIGNED | PK | 主键 |
| bootstrap_session_id | BIGINT UNSIGNED | NOT NULL, FK | 对应接入会话 |
| compute_node_id | BIGINT UNSIGNED | NULL, FK | 成功后对应节点 |
| verification_stage | VARCHAR(32) | NOT NULL | local_report/swarm_probe/runtime_probe/finalize |
| reported_profile_json | JSON | NULL | 卖家本地上报 |
| swarm_profile_json | JSON | NULL | Swarm 侧探测 |
| runtime_profile_json | JSON | NULL | Docker 运行时探测 |
| diff_json | JSON | NULL | 差异结果 |
| verification_status | VARCHAR(16) | NOT NULL | pending/passed/failed/warn |
| error_code | VARCHAR(64) | NULL | 失败错误码 |
| error_message | VARCHAR(255) | NULL | 失败说明 |
| verified_at | DATETIME(3) | NULL | 完成时间 |
| created_at | DATETIME(3) | NOT NULL | 创建时间 |

### 4.2.3 用途

该表解决的是“为什么通过 / 为什么失败 / 差异在哪里”的追溯问题，尤其适合：

- 节点接入失败排查
- 卖家伪造硬件信息审计
- 后续人工介入
- 测试回归时比对真实输入输出

---

## 4.3 对现有表的最小字段补充建议

如果当前阶段不想一次新增两张表，至少建议对现有表补以下字段。

### 4.3.1 `compute_nodes` 建议补充

| 字段名 | 类型 | 约束 | 说明 |
|---|---|---|---|
| runtime_capability_status | VARCHAR(16) | NULL | 运行时能力校验状态 |
| scheduling_eligibility | VARCHAR(16) | NULL | schedulable/unschedulable/warn |
| trusted_region_code | VARCHAR(64) | NULL | 平台最终信任的区域 |
| region_source | VARCHAR(32) | NULL | seller_report/swarm_label/admin_override |
| last_capability_check_at | DATETIME(3) | NULL | 最近能力校验时间 |

说明：

- `region_code` 保留为卖家或业务侧可见值
- `trusted_region_code` 用于平台内部调度和风控
- `region_source` 用于解释最终采用来源

### 4.3.2 `compute_node_bootstrap_sessions` 建议补充

| 字段名 | 类型 | 约束 | 说明 |
|---|---|---|---|
| local_probe_payload_json | JSON | NULL | 本地 bootstrap 采集到的事实 |
| swarm_probe_payload_json | JSON | NULL | 平台从 Swarm 读到的事实 |
| verification_summary_json | JSON | NULL | 本次验证摘要 |
| agent_version | VARCHAR(32) | NULL | 本地 bootstrap 脚本版本 |

说明：

- 这些字段属于“接入过程态”
- 适合快速补齐，不一定非要立即拆独立表

---

## 5. 哪些是 P0，哪些可以后置

### 5.1 P0 必须补

以下内容如果不补，真实 Docker 接入后容易导致“接进来了，但后面不能稳定部署”：

1. `compute_node_runtime_capabilities` 或等效字段集  
2. `region` 冲突仲裁字段  
3. 运行时能力校验状态字段  
4. 接入验证过程中的原始探测结果存储

### 5.2 P1 可以后置

以下内容对真实生产更重要，但不一定阻塞下一阶段开发：

1. network / volume driver 详细清单  
2. daemon features 全量快照  
3. 更细的 driver / CUDA / runtime 兼容矩阵  
4. 多次接入验证历史归档与统计

---

## 6. 推荐实现方式

## 6.1 推荐方案

推荐采用下面这个组合：

1. 保持 `compute_nodes` 主表不大改
2. 新增 `compute_node_runtime_capabilities`
3. 新增 `compute_node_registration_verifications`
4. 在服务层把“卖家上报值”和“平台探测值”显式区分

这是最清晰、最不容易污染主表的方案。

## 6.2 次优方案

如果当前阶段想先控制工作量，可以先：

1. 在 `compute_nodes` 补少量状态字段
2. 在 `compute_node_bootstrap_sessions` 补 3 个 JSON 字段
3. 后续再把 JSON 字段拆表

这个方案适合当前 `M1/M2` 阶段快速往前走。

---

## 7. 对当前代码实现的直接影响

如果按本建议推进，后端最先会影响这些位置：

- `platform-backend/app/models/compute_nodes.py`
- `platform-backend/alembic/versions/`
- `platform-backend/app/modules/compute_nodes/service.py`
- `platform-backend/app/integrations/swarm/schemas.py`
- `platform-backend/app/integrations/swarm/sdk_wrapper.py`

改动重点：

1. `Swarm Adapter` 真实实现返回的 `SwarmNodeHardware` 不能只保留 `cpu_cores / memory_gib / gpu_count`
2. `register-self` 不能只校基础资源数量，还要校 runtime 能力与关键环境
3. `region_code`、GPU 型号、驱动能力冲突时，要有明确的入库与仲裁规则

---

## 8. 测试建议

新增字段或新表后，必须补以下测试：

### 8.1 接入验证测试

- 同一卖家接入三台不同配置 Docker 节点成功
- 节点上报 GPU 型号与平台探测不一致时进入 `warn` 或 `failed`
- `region_code` 与 `pivot.region` 冲突时写入仲裁字段
- 无 `nvidia` runtime 的节点被标记为不可部署 GPU workload

### 8.2 数据库测试

- `compute_node_runtime_capabilities.compute_node_id` 唯一约束生效
- `compute_node_registration_verifications` 可回溯完整验证链路
- `swarm_node_id` 仍保持唯一
- 重复注册同一节点仍幂等返回

### 8.3 后续联动测试

- Listing 筛选只使用经过信任的地区字段
- 调度模块只把任务下发到 `scheduling_eligibility = schedulable` 的节点
- Runtime Reconcile 能根据运行时能力信息输出更准确的异常分类

---

## 9. 最终结论

结论分两层：

### 9.1 对当前接入 MVP 的结论

现有数据库字段**足够完成**“核心流程 1 的 `<接入>` 环节”。

### 9.2 对真实 Docker / Swarm 接入的结论

现有数据库字段**不足以优雅支撑**“多种真实 Docker 环境”的长期接入、校验、调度和运维。

缺的不是“硬件字段能不能存”，而是以下三种结构化表达：

1. Docker 运行时能力
2. 上报值与探测值的差异验证
3. 平台最终信任值与调度资格

因此建议：

- `P0` 先补运行时能力与验证结果存储
- `P1` 再补更细的 daemon/network/driver 兼容性结构

这样既不会推翻当前设计，也能保证后续从 mock Swarm 平滑过渡到真实 Docker Swarm。
