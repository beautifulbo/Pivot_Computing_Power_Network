# 底层框架+数据库 实施计划

## 1. 目录目标

本目录文档定义了当前项目的三类底层基础约束：

- 数据库表结构与字段规范
- 全局错误码与错误响应格式
- 核心业务状态机

这些内容不属于单个业务模块，而是整个算力交易平台的基础骨架。当前仓库中的现有 Spring Boot 通用模板和其 SQL 结构无法直接承载这些约束，因此应在 `../../Pivot_Computing_Power_Network` 下新增平台专属实现。

建议统一落地到：

- `platform-backend/`：模型、迁移、状态机、错误体系
- `platform-worker/`：异步状态推进、巡检、补偿
- `tests/`：契约、集成、回归测试

同时，本目录中的 Mermaid 图和表格应被视为底层设计的正式组成部分：

- 类图、状态图、时序图用于固定实体关系、状态迁移和跨模块调用顺序
- 字段表、索引表、约束表、错误码表用于固定数据库与接口的结构性事实

后续如果调整表结构、状态机、幂等规则、并发控制或错误码映射，必须同步更新对应 Mermaid 图和表格，不能只改正文描述。

---

## 2. 需要实现的内容

### 2.1 数据库层

根据 [数据库设计文档.md](./数据库设计文档.md)，当前项目需要正式落地以下数据域：

- 用户与权限
- 节点接入与运行
- 市场上架与定价
- 钱包与订单
- 部署运行
- Benchmark 任务
- 异常与审计
- 指标快照

这意味着必须建立一套新的 MySQL 8 + Alembic 迁移体系，而不是继续沿用当前 `system-template` 中的通用用户/角色菜单表。

### 2.2 错误码体系

根据 [错误码规范文档.md](./错误码规范文档.md)，当前项目必须具备：

- 模块级错误码枚举
- 统一错误响应结构
- HTTP 状态码映射
- 请求追踪 ID
- 面向前端展示的中文错误信息
- 面向调试的详细错误信息

### 2.3 状态机体系

根据 [状态机设计文档.md](./状态机设计文档.md)，当前项目至少要正式实现：

- `RentalOrder` 状态机
- `Deployment` 状态机
- `ComputeNode` 状态机
- `BenchmarkJob` 状态机
- `BootstrapSession` 状态机

状态机必须是后端正式规则，不允许散落在前端页面、接口层或 worker 脚本中。

### 2.4 根据问题目录新增的底层硬约束

依据 `技术规划\问题` 下的文档，底层设计必须补齐以下约束：

- `compute_nodes.swarm_node_id` 必须唯一，重复注册要么幂等返回，要么拒绝
- `node_rental_listings`、`rental_orders`、`deployments`、`wallet_accounts` 必须带 `version` 字段用于乐观锁
- `rental_orders.idempotency_key` 必须唯一；若需要处理“处理中”状态，补充独立的 `idempotency_records` 或等效请求去重表
- 钱包必须有独立流水表，冻结、解冻、扣减、退款都必须审计
- `refresh_tokens` 表为强制项，支持 token 撤销与轮换
- `compute_node_bootstrap_sessions.session_code` 不能使用可枚举顺序号，建议改为 UUID / 高熵随机串
- 如果后续 Runtime Reconcile 需要最大重试与人工介入，应为 `runtime_events` 或独立补偿表预留：
  - `retry_count`
  - `last_attempt_at`
  - `manual_intervention_required`
  - 或至少在 `detail_json` 中固定这组字段
- 连接能力相关数据如果需要持久化连接 URL，应单独建表或缓存键，而不是把短时连接状态塞回 deployment 主表

---

## 3. 当前项目中的建议实现位置

## 3.1 后端目录

建议在 `../../Pivot_Computing_Power_Network/platform-backend` 中建立：

```text
platform-backend/
  app/
    api/
    schemas/
    core/
      errors/
      enums/
      state_machines/
      idempotency/
    models/
    repositories/
    application/
    modules/
  alembic/
  tests/
    unit/
    integration/
    api/
```

### 3.1.1 数据模型位置

- `app/models/users.py`
- `app/models/compute_nodes.py`
- `app/models/listings.py`
- `app/models/orders.py`
- `app/models/deployments.py`
- `app/models/benchmark.py`
- `app/models/runtime_events.py`
- `app/models/metrics.py`

### 3.1.2 迁移位置

- `alembic/versions/`

首批迁移建议拆成以下几批：

1. 用户与权限
2. 节点接入与运行
3. listing 与 pricing
4. 钱包与订单
5. deployment 与 benchmark
6. runtime event、activity log、metric snapshot

### 3.1.3 错误码位置

- `app/core/errors/codes.py`
- `app/core/errors/exceptions.py`
- `app/core/errors/handlers.py`
- `app/schemas/common.py`

### 3.1.4 状态机位置

- `app/core/state_machines/rental_order.py`
- `app/core/state_machines/deployment.py`
- `app/core/state_machines/compute_node.py`
- `app/core/state_machines/benchmark_job.py`
- `app/core/state_machines/bootstrap_session.py`

状态机调用方：

- `application/` 负责同步业务流转
- `platform-worker/` 负责异步推进和巡检修正

## 3.2 Worker 目录

建议在 `../../Pivot_Computing_Power_Network/platform-worker` 中建立：

- `app/tasks/orders/`
- `app/tasks/benchmark/`
- `app/tasks/reconcile/`
- `app/tasks/metrics/`

这些任务不能直接跳过状态机写数据库，必须调用后端共享的状态规则。

## 3.3 通用测试目录

建议在：

- `../../Pivot_Computing_Power_Network/platform-backend/tests`
- `../../Pivot_Computing_Power_Network/platform-worker/tests`
- `../../Pivot_Computing_Power_Network/tests/contracts`

统一放置测试与契约文件。

---

## 4. 实施优先级

### P0

- 建立 MySQL 模型与 Alembic 迁移
- 建立统一错误码和异常处理
- 建立状态机基础库
- 建立审计日志和 request_id 基础能力

### P1

- 建立快照归档、分区、冷热数据策略
- 建立错误码国际化映射
- 建立统一状态变更事件总线

### P2

- 建立自动错误码文档生成
- 建立状态机可视化导出
- 建立数据生命周期自动归档任务

---

## 5. 具体实施步骤

## 步骤 1：先建统一枚举和公共类型

需要做：

- 把所有状态枚举、错误码枚举、模块枚举集中定义
- 明确数据库字段允许值
- 明确 API 响应体结构

实现位置：

- `platform-backend/app/core/enums/`
- `platform-backend/app/schemas/common.py`

要求：

- 前后端使用同一套状态字符串
- 不允许在业务代码里手写裸字符串

## 步骤 2：落数据库模型

需要做：

- 按数据库设计文档创建 SQLAlchemy 模型
- 补约束、索引、默认值
- 统一 `created_at`、`updated_at`、`version`
- 把问题目录要求的唯一键、重试计数、幂等字段同步落实

实现位置：

- `platform-backend/app/models/`

要求：

- 字段名、类型、默认值与设计文档一致
- 所有关键表有唯一键和高频查询索引

## 步骤 3：建立迁移体系

需要做：

- 初始化 Alembic
- 生成首批迁移
- 准备初始化种子数据

实现位置：

- `platform-backend/alembic/`

要求：

- 从空库可升级到最新版本
- 测试环境可自动重建

## 步骤 4：建立统一错误处理

需要做：

- 定义基础异常类
- 定义模块错误码
- 在 FastAPI 中接入全局异常处理器
- 接入 `request_id` 和时间戳

实现位置：

- `platform-backend/app/core/errors/`
- `platform-backend/app/main.py`

要求：

- 所有业务错误都返回统一 JSON 结构
- 前端只按 `error_code` 分支，不依赖后端临时文案

## 步骤 5：建立状态机实现

需要做：

- 为五类对象分别建立状态机类
- 提供 `can_transition`、`transition`、`assert_transition` 接口
- 将状态变更同时写入审计日志

实现位置：

- `platform-backend/app/core/state_machines/`
- `platform-backend/app/application/`

要求：

- 禁止非法状态跳转
- 重复执行同一状态推进时保持幂等

## 步骤 6：接入 worker 和业务模块

需要做：

- 订单任务、benchmark 任务、reconcile 任务统一调用状态机
- 所有异步任务写入活动日志和运行事件

实现位置：

- `platform-worker/app/tasks/`

要求：

- 任何异步流程都不能绕开领域规则直接改状态

---

## 6. 测试方案

## 6.1 数据库测试

测试内容：

- Alembic 从空库升级成功
- 核心表回滚成功
- 唯一约束和外键约束生效
- 索引覆盖主要查询路径
- 乐观锁字段与幂等键可正常工作
- `swarm_node_id` 重复写入被拦截
- 钱包流水与钱包余额变更保持一致
- `refresh_tokens` 可轮换、可撤销
- `bootstrap_session` 标识不可预测

测试位置：

- `platform-backend/tests/integration/test_migrations.py`
- `platform-backend/tests/integration/test_schema_constraints.py`
- `platform-backend/tests/integration/test_repository_*.py`

## 6.2 错误码测试

测试内容：

- 所有异常响应结构一致
- 错误码与 HTTP 状态码映射正确
- `request_id`、`timestamp` 自动注入
- 未知异常被转换为 `SYSTEM_001`

测试位置：

- `platform-backend/tests/api/test_error_response_contract.py`
- `platform-backend/tests/unit/test_error_code_registry.py`
- `tests/contracts/error_response.schema.json`

## 6.3 状态机测试

测试内容：

- 合法迁移允许通过
- 非法迁移抛出预期错误
- 终态不可继续流转
- 幂等重放不会重复写副作用
- 状态推进会写审计日志

测试位置：

- `platform-backend/tests/unit/test_rental_order_state_machine.py`
- `platform-backend/tests/unit/test_deployment_state_machine.py`
- `platform-backend/tests/unit/test_compute_node_state_machine.py`
- `platform-backend/tests/unit/test_benchmark_job_state_machine.py`
- `platform-backend/tests/unit/test_bootstrap_session_state_machine.py`

## 6.4 事务与并发测试

测试内容：

- 并发下单时 `idempotency_key` 生效
- 乐观锁冲突时返回预期错误
- 同一状态更新并发时无脏写
- listing 行锁能阻止并发超售
- 钱包冻结与订单创建回滚后余额恢复
- Runtime Reconcile 异常重复写入不会无限新增事件

测试位置：

- `platform-backend/tests/integration/test_idempotency.py`
- `platform-backend/tests/integration/test_optimistic_locking.py`

---

## 7. 完成标准

当以下条件满足时，本目录涉及的底层模块可认为达到可开发状态：

- 数据库模型与迁移可稳定执行
- 错误码体系被全局 API 使用
- 五个状态机全部落地并通过测试
- worker 和业务服务都通过统一状态规则推进
- 审计日志与 request_id 已接入

---

## 8. 当前阶段结论

本目录对应的是“平台基础设施中的基础设施”。如果这里不先定死，后续后端、前端、专项模块都会反复返工。因此实现顺序上必须早于：

- 订单模块
- Benchmark 模块
- 管理员大盘
- 前端页面联调

建议把本目录作为整个新平台的第一阶段落地目标。
