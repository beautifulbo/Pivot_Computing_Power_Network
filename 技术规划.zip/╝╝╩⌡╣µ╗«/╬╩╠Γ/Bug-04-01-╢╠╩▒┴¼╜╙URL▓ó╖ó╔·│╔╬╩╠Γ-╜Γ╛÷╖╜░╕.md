# Bug-04-01：短时连接URL并发生成问题 - 解决方案

## 问题描述

**严重级别**：低
**所属流程**：流程04 - 买家控制台查看容器与网页连接

如果买家快速多次点击"网页连接"，可能生成多个`connect_url`，但只有最后一个有效，用户可能打开失效的连接。

## 解决方案

### 1. 前端防抖处理

```typescript
const handleConnectClick = useMemo(
  () => debounce(async () => {
    setConnecting(true);
    try {
      const url = await requestConnectUrl(deploymentId);
      window.open(url, '_blank');
    } finally {
      setConnecting(false);
    }
  }, 1000),
  [deploymentId]
);

<button onClick={handleConnectClick} disabled={connecting}>
  {connecting ? '连接中...' : '网页连接'}
</button>
```

### 2. 后端返回已存在的有效连接

```python
def get_or_create_connect_url(deployment_id: str, user_id: str) -> str:
    # 查找未过期的连接URL
    existing = db.query(ConnectUrl).filter(
        ConnectUrl.deployment_id == deployment_id,
        ConnectUrl.user_id == user_id,
        ConnectUrl.expire_at > datetime.utcnow()
    ).first()

    if existing:
        return existing.url

    # 生成新连接
    url = generate_connect_url(deployment_id)
    db.add(ConnectUrl(
        deployment_id=deployment_id,
        user_id=user_id,
        url=url,
        expire_at=datetime.utcnow() + timedelta(hours=1)
    ))
    db.commit()
    return url
```

### 3. 添加请求去重

```typescript
let pendingRequest: Promise<string> | null = null;

async function requestConnectUrl(deploymentId: string): Promise<string> {
  if (pendingRequest) return pendingRequest;

  pendingRequest = fetch(`/api/deployments/${deploymentId}/connect`)
    .then(r => r.json())
    .then(data => data.connect_url)
    .finally(() => { pendingRequest = null; });

  return pendingRequest;
}
```

## 涉及文档

- `API设计/deployment连接接口.md` - 更新接口逻辑
- `前端设计/买家控制台UI.md` - 添加防抖说明

## 验证方法

1. 快速多次点击"网页连接"按钮
2. 验证只生成一个URL
3. 验证按钮在请求期间禁用
4. 验证返回已存在的有效URL
