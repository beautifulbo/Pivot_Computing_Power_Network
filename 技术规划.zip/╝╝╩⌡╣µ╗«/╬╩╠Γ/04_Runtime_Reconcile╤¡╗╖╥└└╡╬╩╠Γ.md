# Runtime Reconcile 循环依赖问题

## 问题描述

`Runtime Reconcile` 发现异常后的处理流程可能形成循环：

1. Reconcile 发现异常 → 调用 `apply_runtime_abnormal_result()`
2. 订单状态变更 → 触发 Deployment 清理
3. Deployment 清理 → 调用 `Swarm Adapter.remove_runtime_service()`
4. Swarm 操作失败 → 产生新的异常事件
5. 新异常 → 再次触发 Reconcile → 回到步骤 1

## 潜在风险

- 无限循环重试
- 数据库写入压力
- 异常事件表膨胀
- 无法最终收敛到稳定状态

## 待讨论的解决方向

1. **最佳努力清理策略**：Swarm 清理失败不阻断订单状态流转
2. **最大重试次数**：异常事件增加重试计数器
3. **人工介入状态**：超过阈值后标记为需要人工处理
4. **幂等性保证**：同一异常不重复创建事件

## 优先级

中等（MVP 可暂时简化处理，后续优化）

## 记录时间

2026-03-18
