# Bug-00-01：认证Token过期处理 - 解决方案

## 问题描述

**严重级别**：P0 - 高优先级
**Bug ID**：Bug-00-01
**发现时间**：2026-03-18
**影响流程**：所有流程

### 问题现象
所有流程都依赖`Auth & Access`，但Token过期时的刷新机制未明确，导致用户操作中断。

### 业务影响
- 用户操作被中断
- 需要重新登录
- 用户体验差
- 可能丢失未保存数据

## 涉及文档与章节

1. **《系统架构设计文档.md》** - Auth & Access模块
2. **《API接口设计文档.md》** - 认证相关接口
3. **所有业务流程文档**

## 根本原因分析

### 技术原因
1. **缺少自动刷新机制**：Token过期后未自动刷新
2. **前端未处理401**：未统一处理Token过期响应
3. **Refresh Token未实现**：只有Access Token，无法静默刷新

## 详细解决方案

### 方案：实现Refresh Token机制

使用Access Token + Refresh Token双Token机制：
- Access Token：短期有效（15分钟），用于API调用
- Refresh Token：长期有效（7天），用于刷新Access Token

## 需要修改的具体位置

### 1. API接口设计文档

**文件位置**：`技术规划/API接口设计文档.md`

#### 修改登录接口响应

```json
// 修改前
{
  "access_token": "eyJhbGc...",
  "token_type": "Bearer",
  "expires_in": 3600
}

// 修改后
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "token_type": "Bearer",
  "expires_in": 900,
  "refresh_expires_in": 604800
}
```

#### 新增刷新Token接口

```
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJhbGc..."
}

Response 200:
{
  "access_token": "new_access_token",
  "refresh_token": "new_refresh_token",
  "expires_in": 900
}
```

### 2. 数据库设计文档

**文件位置**：`技术规划/数据库设计文档.md`

#### 新增表：RefreshTokens

```sql
CREATE TABLE refresh_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    token_hash VARCHAR(255) NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_token_hash (token_hash),
    INDEX idx_expires_at (expires_at)
);
```

## 伪代码实现

### 后端实现

```python
from datetime import datetime, timedelta
import jwt
import hashlib

class AuthService:

    def __init__(self):
        self.access_token_expire = timedelta(minutes=15)
        self.refresh_token_expire = timedelta(days=7)
        self.secret_key = "your-secret-key"

    async def login(self, username: str, password: str) -> dict:
        """用户登录"""
        # 验证用户
        user = await self._verify_credentials(username, password)

        # 生成tokens
        access_token = self._generate_access_token(user)
        refresh_token = self._generate_refresh_token(user)

        # 保存refresh token
        await self._save_refresh_token(user.id, refresh_token)

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "Bearer",
            "expires_in": int(self.access_token_expire.total_seconds()),
            "refresh_expires_in": int(self.refresh_token_expire.total_seconds())
        }

    def _generate_access_token(self, user: User) -> str:
        """生成Access Token"""
        payload = {
            "sub": str(user.id),
            "role": user.role,
            "exp": datetime.utcnow() + self.access_token_expire,
            "type": "access"
        }
        return jwt.encode(payload, self.secret_key, algorithm="HS256")

    def _generate_refresh_token(self, user: User) -> str:
        """生成Refresh Token"""
        payload = {
            "sub": str(user.id),
            "exp": datetime.utcnow() + self.refresh_token_expire,
            "type": "refresh",
            "jti": str(uuid.uuid4())  # 唯一标识
        }
        return jwt.encode(payload, self.secret_key, algorithm="HS256")

    async def _save_refresh_token(self, user_id: UUID, token: str):
        """保存Refresh Token"""
        token_hash = hashlib.sha256(token.encode()).hexdigest()

        await db.insert(RefreshToken(
            user_id=user_id,
            token_hash=token_hash,
            expires_at=datetime.utcnow() + self.refresh_token_expire
        ))

    async def refresh_access_token(self, refresh_token: str) -> dict:
        """刷新Access Token"""
        try:
            # 验证refresh token
            payload = jwt.decode(
                refresh_token,
                self.secret_key,
                algorithms=["HS256"]
            )

            if payload.get("type") != "refresh":
                raise InvalidTokenError("无效的token类型")

            # 检查是否被撤销
            token_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
            stored_token = await db.query(RefreshToken).filter(
                token_hash=token_hash,
                revoked_at=None
            ).first()

            if not stored_token:
                raise InvalidTokenError("Token已被撤销或不存在")

            # 获取用户
            user_id = UUID(payload["sub"])
            user = await db.query(User).filter(id=user_id).first()

            if not user:
                raise InvalidTokenError("用户不存在")

            # 生成新的tokens
            new_access_token = self._generate_access_token(user)
            new_refresh_token = self._generate_refresh_token(user)

            # 撤销旧的refresh token
            await db.update(RefreshToken).where(
                token_hash=token_hash
            ).values(revoked_at=datetime.utcnow())

            # 保存新的refresh token
            await self._save_refresh_token(user.id, new_refresh_token)

            return {
                "access_token": new_access_token,
                "refresh_token": new_refresh_token,
                "expires_in": int(self.access_token_expire.total_seconds())
            }

        except jwt.ExpiredSignatureError:
            raise InvalidTokenError("Refresh token已过期，请重新登录")
        except jwt.InvalidTokenError:
            raise InvalidTokenError("无效的refresh token")
```

### 前端实现

```typescript
class TokenManager {
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  private refreshPromise: Promise<void> | null = null;

  async init() {
    // 从localStorage恢复tokens
    this.accessToken = localStorage.getItem('access_token');
    this.refreshToken = localStorage.getItem('refresh_token');
  }

  async getAccessToken(): Promise<string> {
    // 如果正在刷新，等待刷新完成
    if (this.refreshPromise) {
      await this.refreshPromise;
    }

    // 检查token是否即将过期（提前1分钟刷新）
    if (this.isTokenExpiringSoon(this.accessToken)) {
      await this.refreshAccessToken();
    }

    return this.accessToken!;
  }

  private isTokenExpiringSoon(token: string | null): boolean {
    if (!token) return true;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const expiresAt = payload.exp * 1000;
      const now = Date.now();
      const timeUntilExpiry = expiresAt - now;

      // 提前1分钟刷新
      return timeUntilExpiry < 60 * 1000;
    } catch {
      return true;
    }
  }

  private async refreshAccessToken(): Promise<void> {
    // 防止并发刷新
    if (this.refreshPromise) {
      return this.refreshPromise;
    }

    this.refreshPromise = (async () => {
      try {
        const response = await fetch('/api/v1/auth/refresh', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            refresh_token: this.refreshToken
          })
        });

        if (!response.ok) {
          throw new Error('刷新失败');
        }

        const data = await response.json();
        this.accessToken = data.access_token;
        this.refreshToken = data.refresh_token;

        // 保存到localStorage
        localStorage.setItem('access_token', data.access_token);
        localStorage.setItem('refresh_token', data.refresh_token);

      } catch (error) {
        // 刷新失败，清除tokens并跳转登录
        this.clearTokens();
        window.location.href = '/login';
        throw error;
      } finally {
        this.refreshPromise = null;
      }
    })();

    return this.refreshPromise;
  }

  private clearTokens() {
    this.accessToken = null;
    this.refreshToken = null;
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
  }
}

// 全局实例
const tokenManager = new TokenManager();

// Axios拦截器
axios.interceptors.request.use(async (config) => {
  const token = await tokenManager.getAccessToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

axios.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // 如果是401且未重试过
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        // 刷新token
        await tokenManager.refreshAccessToken();

        // 重试原请求
        const token = await tokenManager.getAccessToken();
        originalRequest.headers.Authorization = `Bearer ${token}`;
        return axios(originalRequest);

      } catch (refreshError) {
        // 刷新失败，跳转登录
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);
```

## 验证方法

### 1. 单元测试

```python
async def test_refresh_token_flow():
    """测试刷新token流程"""
    # 登录
    login_response = await client.post("/api/v1/auth/login", json={
        "username": "test",
        "password": "password"
    })
    access_token = login_response.json()["access_token"]
    refresh_token = login_response.json()["refresh_token"]

    # 等待access token过期
    await asyncio.sleep(16 * 60)  # 16分钟

    # 使用过期的access token（应失败）
    response = await client.get("/api/v1/user/profile", headers={
        "Authorization": f"Bearer {access_token}"
    })
    assert response.status_code == 401

    # 刷新token
    refresh_response = await client.post("/api/v1/auth/refresh", json={
        "refresh_token": refresh_token
    })
    assert refresh_response.status_code == 200

    new_access_token = refresh_response.json()["access_token"]

    # 使用新token（应成功）
    response = await client.get("/api/v1/user/profile", headers={
        "Authorization": f"Bearer {new_access_token}"
    })
    assert response.status_code == 200
```

## 实施计划

### 阶段一：后端实现（2天）
- [ ] 实现Refresh Token生成和验证
- [ ] 创建refresh接口
- [ ] 数据库迁移

### 阶段二：前端实现（2天）
- [ ] 实现TokenManager
- [ ] 添加Axios拦截器
- [ ] 测试自动刷新

### 阶段三：部署上线（1天）
- [ ] 灰度发布
- [ ] 监控刷新成功率
- [ ] 全量发布

---

**文档版本**：V1.0
**创建日期**：2026-03-18
**负责人**：后端团队 + 前端团队
