# Bug-04-02：连接URL过期后用户体验问题 - 解决方案

## 问题描述

**严重级别**：低
**所属流程**：流程04 - 买家控制台查看容器与网页连接

`connect_url`有过期时间，但如果买家在新标签页打开后长时间未操作，再次刷新可能失败，用户需要重新申请连接。

## 解决方案

### 1. 网关层自动续期

```python
# 在网关验证连接URL时自动续期
def validate_and_renew_connect_url(token: str) -> bool:
    connect = db.query(ConnectUrl).filter(ConnectUrl.token == token).first()

    if not connect:
        return False

    # 如果即将过期（剩余时间<10分钟），自动续期
    if connect.expire_at - datetime.utcnow() < timedelta(minutes=10):
        connect.expire_at = datetime.utcnow() + timedelta(hours=1)
        db.commit()

    return connect.expire_at > datetime.utcnow()
```

### 2. 前端显示过期提示

```typescript
function ConnectUrlDisplay({ url, expireAt }: Props) {
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    const checkExpiry = setInterval(() => {
      if (new Date(expireAt) < new Date()) {
        setIsExpired(true);
      }
    }, 60000);

    return () => clearInterval(checkExpiry);
  }, [expireAt]);

  if (isExpired) {
    return (
      <div className="connect-expired">
        <p>连接已过期，请重新申请</p>
        <button onClick={handleReconnect}>重新连接</button>
      </div>
    );
  }

  return <a href={url} target="_blank">打开工作区</a>;
}
```

### 3. 工作区内自动重连

```typescript
// 在工作区页面检测连接状态
async function checkConnectionHealth() {
  try {
    await fetch('/api/health');
  } catch (error) {
    // 连接失效，提示用户
    showReconnectDialog();
  }
}

setInterval(checkConnectionHealth, 5 * 60 * 1000);
```

## 涉及文档

- `API设计/网关连接验证.md` - 添加自动续期逻辑
- `前端设计/工作区连接UI.md` - 添加过期提示

## 验证方法

1. 生成连接URL并等待接近过期
2. 验证网关自动续期
3. 验证前端显示过期提示
4. 验证重新连接功能正常
