# Bug-03-04 并发租用同一listing超售问题 解决方案

## 1. 问题描述

**Bug ID**: Bug-03-04
**严重级别**: 高
**问题**: 两个买家同时点击"立即租用"，可能都通过`rentable_status`校验，导致超售
**影响**: 一个节点被多个订单占用，资源冲突，用户投诉

## 2. 涉及的文档清单

### 2.1 业务流程文档
- `D:\AI\Pivot_Computing_Power_Network\技术规划\业务流程\03_买家直租NodeRentalListing并创建Deployment.md`
  - 第4.3节：第2步 - 前端提交创建订单请求
  - 第5.2节：异常分支B - 提交时实例已经不可租

### 2.2 后端模块文档
- `D:\AI\Pivot_Computing_Power_Network\技术规划\后端\08_RentalOrder与Deployment模块.md`
  - 第4.2节：Internal Service Unit - `create_rental_order()`
- `D:\AI\Pivot_Computing_Power_Network\技术规划\后端\06_NodeRentalListing市场模块.md`
  - 第4.2节：Internal Service Unit - `check_listing_rentable()`

## 3. 详细解决方案

### 3.1 根本原因分析

当前流程存在竞态条件：

**时间线**:
```
T1: 买家A读取listing，rentable_status = "rentable" ✅
T2: 买家B读取listing，rentable_status = "rentable" ✅
T3: 买家A创建订单，更新rentable_status = "unavailable"
T4: 买家B创建订单，但listing已被占用 ❌ 超售！
```

问题：检查和更新不是原子操作。

### 3.2 解决方案设计

**方案1（推荐）**: 数据库行锁（悲观锁）
**方案2**: 乐观锁（版本号）
**方案3**: Redis分布式锁

本方案采用**方案1**：数据库行锁 + **方案2**：乐观锁作为补充。

### 3.3 需要修改的具体章节

#### 修改1: 后端模块文档 - 增加并发控制说明

**文件**: `技术规划\后端\06_NodeRentalListing市场模块.md`
**章节**: 第4.2节 Internal Service Unit

**在`check_listing_rentable()`后增加**:

```markdown
| `lock_listing_for_rental()` | 锁定listing用于租用，防止并发超售 |
| `unlock_listing_on_failure()` | 租用失败时解锁listing |
```

#### 修改2: 后端模块文档 - 增加并发控制章节

**文件**: `技术规划\后端\08_RentalOrder与Deployment模块.md`
**章节**: 第6节 MVP 备注

**在最后增加**:

```markdown
- 并发控制机制：
  1. 使用数据库行锁（SELECT FOR UPDATE）锁定listing
  2. 在事务内检查并更新`rentable_status`
  3. 使用乐观锁（version字段）作为补充防护
  4. 第二个并发请求将等待锁释放或超时失败
```

#### 修改3: 业务流程文档 - 更新后端处理顺序

**文件**: `技术规划\业务流程\03_买家直租NodeRentalListing并创建Deployment.md`
**章节**: 第4.3节

**修改"后端内部处理顺序"第2步**:

```markdown
2. **【加锁】** 调用 `NodeRentalListing Market` 使用行锁锁定 `listing_id`，检查是否存在、是否 `listed`、是否 `rentable`。
```

## 4. 实现方案

### 4.1 使用数据库行锁（悲观锁）

```python
from django.db import transaction
from django.db.models import F

@transaction.atomic
def create_rental_order_with_lock(request_data: dict) -> dict:
    """
    创建租用订单，使用行锁防止并发超售
    """
    listing_id = request_data['listing_id']
    buyer_user_id = request_data['buyer_user_id']
    frozen_amount = request_data['frozen_amount']

    # 1. 使用SELECT FOR UPDATE锁定listing
    listing = NodeRentalListing.objects.select_for_update().get(id=listing_id)

    # 2. 检查可租状态
    if listing.publish_status != "listed":
        raise ListingNotAvailableError("listing is not published")

    if listing.rentable_status != "rentable":
        raise ListingNotRentableError("ORDER_011", "listing is not rentable")

    # 3. 立即更新为不可租（在同一事务内）
    listing.rentable_status = "unavailable"
    listing.save()

    try:
        # 4. 冻结余额
        wallet = WalletAccount.objects.select_for_update().get(user_id=buyer_user_id)
        if wallet.available_balance < frozen_amount:
            raise InsufficientBalanceError("ORDER_003")

        wallet.available_balance = F('available_balance') - frozen_amount
        wallet.frozen_balance = F('frozen_balance') + frozen_amount
        wallet.save()

        # 5. 创建订单
        order = RentalOrder.objects.create(
            buyer_user_id=buyer_user_id,
            listing_id=listing_id,
            order_status="pending_deploy",
            payment_status="frozen",
            frozen_amount=frozen_amount,
            **request_data
        )

        # 6. 创建部署记录
        deployment = Deployment.objects.create(
            rental_order_id=order.id,
            runtime_status="pending",
            **request_data
        )

        return {
            "rental_order": order,
            "deployment": deployment
        }

    except Exception as e:
        # 失败时恢复listing状态
        listing.rentable_status = "rentable"
        listing.save()
        raise
```

### 4.2 使用乐观锁（补充方案）

```python
# 数据库表增加version字段
class NodeRentalListing(models.Model):
    # ... 其他字段
    version = models.IntegerField(default=0)  # 乐观锁版本号

@transaction.atomic
def create_rental_order_with_optimistic_lock(request_data: dict) -> dict:
    """
    使用乐观锁创建订单
    """
    listing_id = request_data['listing_id']
    max_retries = 3

    for attempt in range(max_retries):
        try:
            # 1. 读取listing和当前版本号
            listing = NodeRentalListing.objects.get(id=listing_id)
            current_version = listing.version

            # 2. 检查可租状态
            if listing.rentable_status != "rentable":
                raise ListingNotRentableError("ORDER_011")

            # 3. 使用CAS（Compare-And-Swap）更新
            updated = NodeRentalListing.objects.filter(
                id=listing_id,
                version=current_version,  # 版本号必须匹配
                rentable_status="rentable"
            ).update(
                rentable_status="unavailable",
                version=F('version') + 1  # 版本号+1
            )

            if updated == 0:
                # CAS失败，说明被其他事务修改了
                if attempt < max_retries - 1:
                    continue  # 重试
                else:
                    raise ListingNotRentableError("ORDER_011", "listing was just rented by another user")

            # 4. CAS成功，继续创建订单
            # ... 后续逻辑同上

            break  # 成功，退出重试循环

        except ListingNotRentableError:
            raise
        except Exception as e:
            if attempt < max_retries - 1:
                continue
            raise
```

### 4.3 使用Redis分布式锁（可选）

```python
import redis
from contextlib import contextmanager

redis_client = redis.Redis(host='localhost', port=6379, db=0)

@contextmanager
def redis_lock(lock_key: str, timeout: int = 10):
    """
    Redis分布式锁上下文管理器
    """
    lock_id = str(uuid.uuid4())
    acquired = False

    try:
        # 尝试获取锁
        acquired = redis_client.set(
            lock_key,
            lock_id,
            nx=True,  # 只在key不存在时设置
            ex=timeout  # 过期时间
        )

        if not acquired:
            raise LockAcquisitionError("failed to acquire lock")

        yield

    finally:
        # 释放锁（只释放自己持有的锁）
        if acquired:
            lua_script = """
            if redis.call("get", KEYS[1]) == ARGV[1] then
                return redis.call("del", KEYS[1])
            else
                return 0
            end
            """
            redis_client.eval(lua_script, 1, lock_key, lock_id)

def create_rental_order_with_redis_lock(request_data: dict) -> dict:
    """
    使用Redis分布式锁创建订单
    """
    listing_id = request_data['listing_id']
    lock_key = f"listing:rental:lock:{listing_id}"

    with redis_lock(lock_key, timeout=10):
        # 在锁保护下执行订单创建
        return create_rental_order_with_lock(request_data)
```

## 5. 修改前后对比

### 修改前
```python
# ❌ 无并发控制
def create_order_old(listing_id):
    listing = NodeRentalListing.objects.get(id=listing_id)

    if listing.rentable_status == "rentable":  # 检查
        # 时间窗口：其他请求可能也通过检查
        order = create_order()  # 创建
        listing.rentable_status = "unavailable"  # 更新
        listing.save()
    # 结果：可能超售
```

### 修改后
```python
# ✅ 使用行锁
@transaction.atomic
def create_order_new(listing_id):
    # 锁定行，其他事务必须等待
    listing = NodeRentalListing.objects.select_for_update().get(id=listing_id)

    if listing.rentable_status == "rentable":
        listing.rentable_status = "unavailable"
        listing.save()
        order = create_order()
    # 结果：不会超售
```

## 6. 验证方法

### 6.1 并发测试

```python
import threading
import time

def test_concurrent_rental_no_oversell():
    """测试并发租用不会超售"""
    listing = create_test_listing(rentable_status="rentable")
    buyer1 = create_test_user(balance=100.0)
    buyer2 = create_test_user(balance=100.0)

    results = []
    errors = []

    def rent_listing(buyer_id):
        try:
            result = create_rental_order_with_lock({
                'buyer_user_id': buyer_id,
                'listing_id': listing.id,
                'frozen_amount': 50.0
            })
            results.append(result)
        except Exception as e:
            errors.append(e)

    # 创建两个并发线程
    thread1 = threading.Thread(target=rent_listing, args=(buyer1.id,))
    thread2 = threading.Thread(target=rent_listing, args=(buyer2.id,))

    # 同时启动
    thread1.start()
    thread2.start()

    # 等待完成
    thread1.join()
    thread2.join()

    # 验证：只有一个成功
    assert len(results) == 1, "Only one order should succeed"
    assert len(errors) == 1, "One order should fail"
    assert isinstance(errors[0], ListingNotRentableError)

    # 验证：listing状态正确
    listing.refresh_from_db()
    assert listing.rentable_status == "unavailable"
```

### 6.2 压力测试

```python
import concurrent.futures

def test_high_concurrency_rental():
    """测试高并发场景"""
    listing = create_test_listing(rentable_status="rentable")
    buyers = [create_test_user(balance=100.0) for _ in range(10)]

    success_count = 0
    failure_count = 0

    def attempt_rental(buyer_id):
        try:
            create_rental_order_with_lock({
                'buyer_user_id': buyer_id,
                'listing_id': listing.id,
                'frozen_amount': 50.0
            })
            return "success"
        except ListingNotRentableError:
            return "failed"

    # 使用线程池模拟10个并发请求
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(attempt_rental, buyer.id) for buyer in buyers]
        results = [f.result() for f in concurrent.futures.as_completed(futures)]

    success_count = results.count("success")
    failure_count = results.count("failed")

    # 验证：只有1个成功，9个失败
    assert success_count == 1
    assert failure_count == 9
```

## 7. 性能考虑

### 7.1 锁等待超时设置

```python
# 设置锁等待超时
from django.db import connection

with connection.cursor() as cursor:
    cursor.execute("SET innodb_lock_wait_timeout = 5")  # 5秒超时
```

### 7.2 死锁预防

- 按固定顺序获取锁：先listing，后wallet
- 设置合理的超时时间
- 监控死锁发生频率

### 7.3 性能优化

```python
# 使用索引加速锁定
class NodeRentalListing(models.Model):
    class Meta:
        indexes = [
            models.Index(fields=['rentable_status', 'publish_status']),
        ]
```

## 8. 监控与告警

```python
def monitor_concurrent_rental_conflicts():
    """监控并发租用冲突"""
    # 统计最近1小时内因listing不可租而失败的请求
    recent_failures = ErrorLog.objects.filter(
        error_code="ORDER_011",
        created_at__gte=timezone.now() - timedelta(hours=1)
    ).count()

    if recent_failures > 100:
        send_alert(f"High concurrent rental conflicts: {recent_failures}")
```

## 9. 优先级与时间估算

- **优先级**: P0（立即修复）
- **开发时间**: 3小时
- **测试时间**: 2小时（包含并发测试）
- **总计**: 5小时
