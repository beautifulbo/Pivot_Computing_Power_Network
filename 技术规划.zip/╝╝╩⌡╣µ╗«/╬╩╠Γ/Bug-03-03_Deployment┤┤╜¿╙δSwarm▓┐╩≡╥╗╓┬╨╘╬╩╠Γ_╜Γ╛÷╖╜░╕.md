# Bug-03-03 Deployment创建与Swarm部署一致性问题 解决方案

## 1. 问题描述

**Bug ID**: Bug-03-03
**严重级别**: 高
**问题**: `RentalOrder`已创建，`Deployment`记录已写入，但`Swarm Adapter.deploy_runtime_service()`失败，退款逻辑可能不会立即触发
**影响**: 资金被冻结但实例未运行，用户体验差

## 2. 涉及的文档清单

### 2.1 业务流程文档
- `D:\AI\Pivot_Computing_Power_Network\技术规划\业务流程\03_买家直租NodeRentalListing并创建Deployment.md`
  - 第4.3节：第2步 - 前端提交创建订单请求
  - 第5.6节：异常分支F - 订单已创建但部署失败

### 2.2 后端模块文档
- `D:\AI\Pivot_Computing_Power_Network\技术规划\后端\08_RentalOrder与Deployment模块.md`
  - 第4.2节：Internal Service Unit - `deploy_runtime_service()`
  - 第4.2节：Internal Service Unit - `apply_runtime_abnormal_result()`

## 3. 详细解决方案

### 3.1 根本原因分析

当前流程：
1. 创建`RentalOrder` ✅
2. 创建`Deployment` ✅
3. 调用`Swarm Adapter.deploy_runtime_service()` ❌ 失败
4. 退款逻辑未立即触发，需要等待后台任务或人工介入

问题：缺少同步的失败处理机制。

### 3.2 解决方案设计

**核心原则**: 在部署失败时立即触发退款流程

**实现方式**:
1. 在`POST /rental-orders`接口中捕获Swarm部署异常
2. 立即标记订单和部署为失败状态
3. 同步执行退款操作
4. 返回明确的失败响应给前端

### 3.3 需要修改的具体章节

#### 修改1: 后端模块文档 - 更新deploy_runtime_service说明

**文件**: `技术规划\后端\08_RentalOrder与Deployment模块.md`
**章节**: 第4.2节 Internal Service Unit

**在`deploy_runtime_service()`后增加**:

```markdown
| `handle_deployment_failure()` | 处理部署失败，立即触发退款 |
```

#### 修改2: 后端模块文档 - 增加失败处理流程

**文件**: `技术规划\后端\08_RentalOrder与Deployment模块.md`
**章节**: 第6节 MVP 备注

**在最后增加**:

```markdown
- 部署失败处理流程：
  1. `Swarm Adapter.deploy_runtime_service()`失败时立即捕获异常
  2. 标记`Deployment.runtime_status = failed`
  3. 标记`RentalOrder.order_status = failed`
  4. 同步执行退款：解冻余额，更新`payment_status = refunded`
  5. 返回失败响应给前端，包含失败原因
```

#### 修改3: 业务流程文档 - 完善异常分支F

**文件**: `技术规划\业务流程\03_买家直租NodeRentalListing并创建Deployment.md`
**章节**: 第5.6节

**修改后**:

```markdown
### 5.6 异常分支 F：订单已创建，但部署失败

**触发点**

`RentalOrder` 已经创建，冻结金额也已经成功，但 `Swarm Adapter` 返回部署失败。

**涉及接口**

- `POST /rental-orders`
- `GET /rental-orders/{order_id}`
- `GET /rental-orders/{order_id}/deployment`

**后端内部处理**

1. 捕获`Swarm Adapter.deploy_runtime_service()`异常
2. **【立即执行】** 标记`Deployment.runtime_status = failed`
3. **【立即执行】** 标记`RentalOrder.order_status = failed`
4. **【立即执行】** 执行退款：
   - 解冻余额：`wallet.frozen_balance -= frozen_amount`
   - 退回可用余额：`wallet.available_balance += frozen_amount`
   - 更新订单：`payment_status = refunded`, `refund_amount = frozen_amount`
5. 记录失败原因到`Deployment.failure_reason`
6. 返回失败响应给前端

**POST /rental-orders 失败响应示例**

```json
{
  "error_code": "ORDER_006",
  "message": "container startup failed",
  "rental_order": {
    "id": 9001,
    "order_no": "RO202603180001",
    "order_status": "failed",
    "payment_status": "refunded",
    "frozen_amount": 37.2,
    "refund_amount": 37.2
  },
  "deployment": {
    "id": 9101,
    "runtime_status": "failed",
    "failure_reason": "swarm service creation timeout"
  }
}
```

**前端效果**

- 页面显示"部署失败"错误提示
- 显示退款信息："已退款 ¥37.2"
- 不跳转到详情页，停留在listing详情页
- 允许买家重新尝试或选择其他实例
```

## 4. 实现方案

### 4.1 完整的订单创建与部署流程

```python
from django.db import transaction

def handle_order_creation_and_deployment(request_data: dict) -> dict:
    """
    处理订单创建和部署的完整流程，包含失败处理
    """
    order = None
    deployment = None

    try:
        # 第1步：事务内创建订单和部署记录
        with transaction.atomic():
            result = create_rental_order_in_transaction(**request_data)
            order = result['rental_order']
            deployment = result['deployment']

        # 第2步：事务外调用Swarm部署
        swarm_result = swarm_adapter.deploy_runtime_service(
            deployment_id=deployment.id,
            compute_node_id=order.listing.compute_node_id,
            image=deployment.container_image,
            command=deployment.start_command,
            env_vars=deployment.env_vars,
            exposed_port=deployment.exposed_port,
            timeout=60  # 60秒超时
        )

        # 部署成功，更新状态
        deployment.runtime_status = "starting"
        deployment.swarm_service_id = swarm_result['service_id']
        deployment.save()

        order.order_status = "running"
        order.business_completed = True
        order.started_at = timezone.now()
        order.expire_at = order.started_at + timedelta(minutes=order.duration_minutes)
        order.save()

        return {
            "rental_order": order.to_dict(),
            "deployment": deployment.to_dict()
        }

    except SwarmDeploymentError as e:
        # 部署失败，立即处理
        logger.error(f"Swarm deployment failed for order {order.id}: {e}")
        handle_deployment_failure(order, deployment, str(e))

        # 返回失败响应
        raise OrderCreationError(
            error_code="ORDER_006",
            message="container startup failed",
            rental_order=order.to_dict(),
            deployment=deployment.to_dict()
        )

@transaction.atomic
def handle_deployment_failure(order: RentalOrder, deployment: Deployment, reason: str):
    """
    处理部署失败：标记失败状态并立即退款
    """
    # 1. 标记部署失败
    deployment.runtime_status = "failed"
    deployment.failure_reason = reason
    deployment.failed_at = timezone.now()
    deployment.save()

    # 2. 标记订单失败
    order.order_status = "failed"
    order.save()

    # 3. 立即退款
    refund_result = refund_frozen_amount_immediately(order)

    # 4. 记录退款流水
    create_wallet_transaction(
        user_id=order.buyer_user_id,
        transaction_type="refund",
        amount=order.frozen_amount,
        order_id=order.id,
        reason="deployment_failed"
    )

    logger.info(f"Order {order.id} failed and refunded: {refund_result}")

@transaction.atomic
def refund_frozen_amount_immediately(order: RentalOrder) -> dict:
    """
    立即退款：解冻余额
    """
    wallet = WalletAccount.objects.select_for_update().get(
        user_id=order.buyer_user_id
    )

    # 解冻余额
    wallet.frozen_balance = F('frozen_balance') - order.frozen_amount
    wallet.available_balance = F('available_balance') + order.frozen_amount
    wallet.save()

    # 刷新以获取实际值
    wallet.refresh_from_db()

    # 更新订单支付状态
    order.payment_status = "refunded"
    order.refund_amount = order.frozen_amount
    order.refunded_at = timezone.now()
    order.save()

    return {
        "refunded": True,
        "refund_amount": order.frozen_amount,
        "new_available_balance": wallet.available_balance
    }
```

### 4.2 API响应处理

```python
@api_view(['POST'])
def create_rental_order_api(request):
    """
    创建租用订单API
    """
    try:
        # 参数校验
        validate_rental_order_params(request.data)

        # 处理订单创建和部署
        result = handle_order_creation_and_deployment(request.data)

        return Response(result, status=status.HTTP_201_CREATED)

    except OrderCreationError as e:
        # 部署失败，但已完成退款
        return Response({
            "error_code": e.error_code,
            "message": e.message,
            "rental_order": e.rental_order,
            "deployment": e.deployment
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    except InsufficientBalanceError as e:
        return Response({
            "error_code": "ORDER_003",
            "message": "insufficient balance"
        }, status=status.HTTP_400_BAD_REQUEST)

    except Exception as e:
        logger.exception("Unexpected error in order creation")
        return Response({
            "error_code": "INTERNAL_ERROR",
            "message": "unexpected error occurred"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
```

## 5. 修改前后对比

### 修改前
```python
# ❌ 部署失败后不立即处理
def create_order_old():
    order = create_rental_order()
    deployment = create_deployment()

    try:
        swarm_adapter.deploy_runtime_service()
    except Exception as e:
        # 只记录日志，不处理
        logger.error(f"Deployment failed: {e}")
        # 退款需要等待后台任务

    return order
```

### 修改后
```python
# ✅ 部署失败立即退款
def create_order_new():
    order = create_rental_order()
    deployment = create_deployment()

    try:
        swarm_adapter.deploy_runtime_service()
    except Exception as e:
        # 立即处理失败
        handle_deployment_failure(order, deployment, str(e))
        raise OrderCreationError(...)

    return order
```

## 6. 验证方法

### 6.1 单元测试

```python
def test_deployment_failure_immediate_refund():
    """测试部署失败时立即退款"""
    buyer = create_test_user(balance=100.0)

    # 模拟Swarm部署失败
    with patch('swarm_adapter.deploy_runtime_service', side_effect=SwarmDeploymentError("timeout")):
        with pytest.raises(OrderCreationError) as exc_info:
            handle_order_creation_and_deployment({
                'buyer_user_id': buyer.id,
                'listing_id': 1,
                'frozen_amount': 50.0
            })

    # 验证：订单已创建但标记为失败
    order = RentalOrder.objects.get(buyer_user_id=buyer.id)
    assert order.order_status == 'failed'
    assert order.payment_status == 'refunded'

    # 验证：余额已立即退款
    wallet = WalletAccount.objects.get(user_id=buyer.id)
    assert wallet.available_balance == 100.0
    assert wallet.frozen_balance == 0.0
```

### 6.2 集成测试

```python
def test_deployment_failure_api_response():
    """测试部署失败时的API响应"""
    client = APIClient()
    buyer = create_test_user(balance=100.0)
    client.force_authenticate(user=buyer)

    with patch('swarm_adapter.deploy_runtime_service', side_effect=SwarmDeploymentError()):
        response = client.post('/rental-orders', {
            'listing_id': 1,
            'duration_minutes': 120,
            'frozen_amount': 50.0
        })

    # 验证：返回500错误，但包含退款信息
    assert response.status_code == 500
    assert response.data['error_code'] == 'ORDER_006'
    assert response.data['rental_order']['payment_status'] == 'refunded'
```

## 7. 监控与告警

```python
# 监控部署失败率
def monitor_deployment_failure_rate():
    """监控部署失败率，超过阈值告警"""
    recent_orders = RentalOrder.objects.filter(
        created_at__gte=timezone.now() - timedelta(hours=1)
    )

    total = recent_orders.count()
    failed = recent_orders.filter(order_status='failed').count()

    if total > 0:
        failure_rate = failed / total
        if failure_rate > 0.1:  # 失败率超过10%
            send_alert(f"High deployment failure rate: {failure_rate:.2%}")
```

## 8. 优先级与时间估算

- **优先级**: P0（立即修复）
- **开发时间**: 3小时
- **测试时间**: 2小时
- **总计**: 5小时
