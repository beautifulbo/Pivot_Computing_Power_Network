# Swarm基础设施模块

版本：V1.0  
日期：2026-03-18

## 1. 模块目标

`Swarm Infrastructure` 模块承载平台自持的 `Swarm Manager`、卖家提供的 `Swarm Worker`，以及 benchmark 专用 worker。

## 2. 模块内部关系图

```mermaid
flowchart TB
    Contract[Infrastructure Contracts]
    Manager[Swarm Manager]
    SellerWorkers[Seller Worker Nodes]
    BenchWorkers[Benchmark Worker Nodes]
    Services[Runtime / Benchmark Services]

    Contract --> Manager
    Manager --> SellerWorkers
    Manager --> BenchWorkers
    Manager --> Services
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 无 |
| 对其他后端模块 | 通过契约被 `Swarm Adapter`、`AI Benchmark Worker` 使用 |
| 对外 | 实际承载 Docker Swarm 运行环境 |
| 内部 | Manager、Worker、标签规范、运行约束 |

## 4. 后端接口

### 4.1 Infrastructure Contract Unit

| 接口单元 | 作用 |
|---|---|
| `manager_health_contract` | 定义 Manager 健康检查标准 |
| `worker_join_contract` | 定义 Worker 加入规则 |
| `node_label_contract` | 定义节点标签规范 |
| `benchmark_worker_runtime_contract` | 定义测算容器运行约束 |
| `service_placement_contract` | 定义 service 调度约束 |

## 5. 依赖模块

- 无上游业务依赖

## 6. MVP 备注

- 平台必须自持 `Swarm Manager`。
- 卖家只提供 `Swarm Worker`。
