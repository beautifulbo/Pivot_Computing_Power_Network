# BenchmarkJob模块

版本：V1.1
日期：2026-03-18

## 1. 模块目标

`BenchmarkJob` 模块负责创建测算任务、存储测算输入、调度 benchmark worker、解析结果，并返回推荐的 `NodeRentalListing`。

## 2. 模块内部关系图

```mermaid
flowchart TB
    API[Benchmark APIs]
    Task[run_benchmark_job_task]
    Service[BenchmarkJobService]
    Upload[Archive Upload Store]
    Manifest[Input Manifest Builder]
    Parser[Result Parser]
    Matcher[Listing Matcher]
    JobRepo[BenchmarkJob Repository]
    SwarmClient[Swarm Adapter Client]
    AIWorker[AI Benchmark Worker]
    ListingClient[Listing Client]
    DB[(MySQL)]
    Redis[(Redis)]

    API --> Service
    Service --> Upload
    Service --> Manifest
    Service --> Task
    Task --> Service
    Service --> Parser
    Service --> Matcher
    Service --> JobRepo
    Service --> SwarmClient
    Service --> AIWorker
    Service --> ListingClient
    JobRepo --> DB
    Upload --> Redis
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 创建测算任务、查询任务、获取推荐结果 |
| 对其他后端模块 | 向 `NodeRentalListing Market` 读取推荐对象；被 `Admin Dashboard` 间接读取任务结果 |
| 对外 | 通过 `Swarm Adapter` 调度测算容器，调用 `AI Benchmark Worker` 执行实际测算 |
| 内部 | 任务创建、异步派发、结果解析、推荐匹配 |

## 4. 后端接口

### 4.1 HTTP API Unit

| 接口单元 | 作用 |
|---|---|
| `POST /benchmark-jobs/code-archive-uploads` | 上传完整代码压缩包并返回 `code_archive_token` |
| `POST /benchmark-jobs/validate-git` | 预校验Git仓库可访问性和分支存在性<br>**注意**：提交前校验，避免clone失败(Bug-05-02) |
| `POST /benchmark-jobs` | 创建测算任务<br>**注意**：严格校验输入源互斥性(Bug-05-06) |
| `GET /benchmark-jobs` | 获取任务列表 |
| `GET /benchmark-jobs/{job_id}` | 获取任务详情 |
| `GET /benchmark-jobs/{job_id}/recommendations` | 获取推荐结果<br>**注意**：实时查询listing状态，标注当前可租性(Bug-05-04) |
| `POST /benchmark-jobs/{job_id}/refresh-recommendations` | 刷新推荐结果<br>**注意**：复用测算结果，重新匹配当前可用listing(Bug-05-04) |

### 4.2 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `store_code_archive_upload()` | 存储代码压缩包并生成上传令牌 |
| `create_benchmark_job()` | 创建任务记录 |
| `prepare_benchmark_input_manifest()` | 生成统一输入清单，描述压缩包或 git 源 |
| `dispatch_benchmark_worker()` | 调度测算 worker |
| `parse_benchmark_result()` | 解析结果 |
| `match_recommended_listings()` | 关联推荐上架记录 |

### 4.3 Async Task Unit

| 接口单元 | 作用 |
|---|---|
| `run_benchmark_job_task` | 异步执行测算任务 |

## 5. 依赖模块

- `Auth & Access`
- `Swarm Adapter`
- `AI测算模块`
- `NodeRentalListing Market`

## 6. MVP 备注

- 第一阶段只要求占位结果。
- 结果字段后续单独冻结。
- `POST /benchmark-jobs` 必须支持两种输入来源：`source_type = code_archive | git_repository`。
- 当 `source_type = code_archive` 时，请求体必须携带 `code_archive_token`；当 `source_type = git_repository` 时，请求体必须携带 `git_clone_url`，可选 `git_ref`。
- **输入源互斥校验**(Bug-05-06)：严格校验只能提供一种代码源，同时提供或都不提供均返回400错误
- **Git仓库校验**(Bug-05-02)：使用git ls-remote预校验仓库可访问性，clone时使用--depth 1浅克隆，超时时间300秒
- **依赖安装优化**(Bug-05-03)：使用共享卷缓存依赖(/cache/npm、/cache/pip)，分阶段超时(依赖安装10分钟+执行5分钟)
- **推荐时效性**(Bug-05-04)：返回推荐时实时查询listing状态，显示推荐生成时间，提供刷新推荐功能
- **结果持久化**(Bug-05-07)：使用卷挂载将结果直接写入宿主机，确保容器销毁前结果已保存
- `BenchmarkJob` 模块负责把上传令牌或 git 信息整理成统一的 `benchmark input manifest`，再交给 `Swarm Adapter.create_benchmark_service()`。
- `GET /benchmark-jobs/{job_id}` 对前端至少要返回这些字段：`job_status`、`current_stage`、`source_type`、`source_summary`、`failure_reason`。
- 该模块对前端至少要返回这些明确业务错误：`benchmark_source_missing`、`code_archive_upload_missing`、`invalid_git_clone_url`。

## 7. 并发控制策略

### 7.1 并发限制

- **全局并发限制**：最多 3 个 benchmark 任务同时运行
- **单用户并发限制**：每个用户最多 1 个运行中任务
- **超出限制处理**：任务进入 `queued` 状态等待

### 7.2 实现逻辑

在 `POST /benchmark-jobs` 中：

```python
def create_benchmark_job(user_id: int, payload: dict):
    # 检查用户并发
    running_count = count_user_running_jobs(user_id)
    if running_count >= 1:
        raise HTTPException(
            status_code=429,
            detail={"error_code": "BENCHMARK_003"}
        )

    # 检查全局并发
    global_running = count_global_running_jobs()
    if global_running >= 3:
        job.job_status = 'queued'
    else:
        job.job_status = 'preparing'

    return job
```

## 8. 超时与重试机制

### 8.1 超时控制

- 默认超时：`timeout_seconds = 1800`（30 分钟）
- 可在创建任务时自定义（最大 3600 秒）
- 超时后任务状态变为 `timeout`

### 8.2 重试机制

- 默认不重试：`max_retries = 0`
- MVP 阶段失败任务需手动重新提交
- 后续可支持自动重试

## 9. 推荐结果一致性处理

### 9.1 推荐策略

采用**乐观展示 + 下单时二次校验**方案：

1. `BenchmarkJob` 完成后，推荐结果只是快照，不锁定节点
2. 推荐结果存储在 `benchmark_recommendations` 表
3. 前端展示推荐时，需实时查询每个 listing 的当前状态
4. 买家下单时，后端再次校验 listing 是否可租

### 9.2 前端展示建议

```javascript
// 获取推荐结果
const recommendations = await api.getBenchmarkRecommendations(jobId);

// 并行查询每个 listing 的当前状态
const listingIds = recommendations.map(r => r.listing_id);
const listingStatuses = await api.getListingStatuses(listingIds);

// 标注状态
recommendations.forEach(rec => {
  const status = listingStatuses[rec.listing_id];
  rec.current_rentable = status.rentable_status === 'rentable';
  rec.current_price = status.current_price_hourly;
});
```

### 9.3 用户提示

前端应显示："推荐结果仅供参考，实际可租状态以下单时为准"

## 10. 状态机

详见 [状态机设计文档](../底层框架+数据库/状态机设计文档.md) 第 5 节。

关键转换：
- `queued` → `preparing`（获得执行资格）
- `preparing` → `deploying`（准备完成，设置 `business_completed = TRUE`）
- `deploying` → `running`（容器启动）
- `running` → `analyzing`（执行完成）
- `analyzing` → `succeeded`（分析完成）

## 11. 错误码清单

| 错误码 | HTTP 状态码 | 错误信息 | 说明 |
|-------|-----------|---------|------|
| `BENCHMARK_001` | 404 | 测算任务不存在 | BenchmarkJob 不存在 |
| `BENCHMARK_002` | 403 | 无权访问该任务 | 任务不属于当前用户 |
| `BENCHMARK_003` | 429 | 并发任务数超限 | 用户运行中任务数达到上限 |
| `BENCHMARK_004` | 503 | 系统繁忙，请稍后重试 | 全局并发任务数达到上限 |
| `BENCHMARK_005` | 400 | 代码包上传失败 | 代码包上传或验证失败 |
| `BENCHMARK_006` | 400 | Git 地址无效 | Git clone URL 格式错误 |
| `BENCHMARK_007` | 408 | 任务执行超时 | 任务超过 timeout_seconds |
| `BENCHMARK_008` | 500 | 任务执行失败 | Benchmark 容器执行失败 |
| `BENCHMARK_009` | 409 | 任务状态不允许取消 | 当前状态不允许取消 |

详细错误码规范见 [错误码规范文档](../底层框架+数据库/错误码规范文档.md)。

