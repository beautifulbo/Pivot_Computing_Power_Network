# NodeRentalListing市场模块

版本：V1.0  
日期：2026-03-18

## 1. 模块目标

`NodeRentalListing Market` 模块负责市场列表、筛选、详情、上架状态控制，以及从 `ComputeNode` 自动生成并发布 `NodeRentalListing`。

## 2. 模块内部关系图

```mermaid
flowchart TB
    MarketAPI[Market APIs]
    SellerAPI[Seller Listing APIs]
    Service[ListingService]
    Metadata[Metadata Builder]
    Rentable[Rentable Checker]
    ListingRepo[Listing Repository]
    NodeClient[ComputeNode Client]
    PricingClient[PricingEngine Client]
    DB[(MySQL)]

    MarketAPI --> Service
    SellerAPI --> Service
    Service --> Metadata
    Service --> Rentable
    Service --> ListingRepo
    Service --> NodeClient
    Service --> PricingClient
    ListingRepo --> DB
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 列表、筛选、详情、卖家上架管理 |
| 对其他后端模块 | 向 `RentalOrder`、`BenchmarkJob`、`Admin Dashboard` 提供上架记录和可租状态 |
| 对外 | 无直接外部系统交互 |
| 内部 | 列表组装、详情组装、可租判断、上架状态切换 |

## 4. 后端接口

### 4.1 HTTP API Unit

| 接口单元 | 作用 |
|---|---|
| `GET /market/listings` | 获取市场列表<br>**注意**：使用游标分页(cursor)而非offset,避免翻页时数据重复或遗漏(Bug-02-03) |
| `GET /market/listings/filters` | 获取筛选条件 |
| `GET /market/listings/{listing_id}` | 获取详情<br>**注意**：返回version字段,支持乐观锁校验(Bug-02-04) |
| `GET /market/listings/{listing_id}/status` | 获取listing实时状态<br>**注意**：供前端轮询或WebSocket推送使用(Bug-02-04) |
| `GET /seller/listings` | 获取卖家自己的上架记录 |
| `GET /seller/listings/{listing_id}` | 获取卖家自己的上架详情 |
| `PATCH /seller/listings/{listing_id}` | 更新标题、描述、镜像策略 |
| `POST /seller/listings/{listing_id}/publish` | 上架 |
| `POST /seller/listings/{listing_id}/off-shelf` | 下架 |

### 4.2 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `create_listing_from_compute_node()` | 从 `ComputeNode` 生成上架记录 |
| `auto_build_listing_metadata()` | 根据硬件信息和默认模板自动生成标题、摘要、默认描述 |
| `create_and_publish_listing_from_compute_node()` | 从 `ComputeNode` 自动生成并直接上架 |
| `build_listing_summary()` | 组装市场摘要 |
| `build_listing_detail()` | 组装详情页数据 |
| `check_listing_rentable()` | 校验是否可租 |

## 5. 依赖模块

- `Auth & Access`
- `ComputeNode Access`
- `PricingEngine`

## 6. MVP 备注

- 一个 `ComputeNode` 对应一个 `NodeRentalListing`。
- 卖家只能上下架，不能改价格。
- onboarding 阶段不要求卖家手工补录 listing 文案。
- listing 的默认标题、配置摘要、默认描述由后端自动生成。
- **价格过期判断**(Bug-02-01)：价格有效期30分钟，后台任务每10分钟刷新即将过期的价格(提前5分钟)，前端显示price_stale标记
- **分页机制**(Bug-02-03)：使用游标分页(cursor-based)，以listing_id作为游标，避免offset分页在数据变化时的重复或遗漏问题
- **状态实时性**(Bug-02-04)：详情页返回version字段，前端可选择WebSocket订阅或3秒轮询获取状态变化，下单时校验version防止状态已变
