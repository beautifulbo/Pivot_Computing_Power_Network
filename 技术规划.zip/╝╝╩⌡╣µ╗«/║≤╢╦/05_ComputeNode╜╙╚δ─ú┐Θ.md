# ComputeNode接入模块

版本：V1.1
日期：2026-03-18

## 1. 模块目标

`ComputeNode Access` 模块负责卖家节点接入说明、bootstrap 会话、节点自注册、节点认领、状态同步和节点基础信息维护。

## 2. 模块内部关系图

```mermaid
flowchart TB
    API[HTTP APIs]
    Job[Status Sync Job]
    Service[ComputeNodeAccessService]
    BootstrapRepo[BootstrapSession Repository]
    NodeRepo[ComputeNode Repository]
    SwarmClient[Swarm Adapter Client]
    PricingClient[PricingEngine Client]
    DB[(MySQL)]

    API --> Service
    Job --> Service
    Service --> BootstrapRepo
    Service --> NodeRepo
    Service --> SwarmClient
    Service --> PricingClient
    BootstrapRepo --> DB
    NodeRepo --> DB
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 获取接入说明、生成接入命令、轮询接入状态、查看节点、编辑节点、手动同步 |
| 对其他后端模块 | 向 `NodeRentalListing`、`Runtime Reconcile`、`Admin Dashboard` 提供节点事实数据 |
| 对外 | 通过 `Swarm Adapter` 读取真实 Swarm 节点状态 |
| 内部 | `API -> service -> repository`，bootstrap session 管理、自注册处理、定时任务触发状态同步 |

## 4. 后端接口

### 4.1 HTTP API Unit

| 接口单元 | 作用 |
|---|---|
| `GET /seller/compute-nodes/access-guide` | 获取接入说明 |
| `POST /seller/compute-nodes/bootstrap-sessions` | 创建接入会话并返回本地执行命令<br>**注意**：registration_token有效期30分钟(Bug-01-02) |
| `GET /seller/compute-nodes/bootstrap-sessions/{session_id}` | 轮询接入会话状态<br>**注意**：前端应设置5分钟轮询超时和指数退避重试(Bug-01-05) |
| `POST /seller/compute-nodes/register-self` | 由本地 bootstrap 脚本自注册节点，并自动触发 listing 元数据生成与自动上架<br>**注意**：需实现重试机制，因为Swarm节点加入存在1-5秒异步延迟<br>**注意**：校验token剩余时间，少于1分钟拒绝并提示重新生成(Bug-01-02) |
| `GET /seller/compute-nodes` | 查询卖家名下节点列表 |
| `GET /seller/compute-nodes/{node_id}` | 查询节点详情 |
| `PATCH /seller/compute-nodes/{node_id}` | 更新节点基础信息 |
| `POST /seller/compute-nodes/{node_id}/sync` | 手动触发节点状态同步 |

### 4.2 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `create_bootstrap_session()` | 创建短时有效的接入会话 |
| `build_bootstrap_command()` | 组装本地执行命令 |
| `validate_registration_token()` | 校验 bootstrap 自注册令牌 |
| `validate_hardware_info()` | 验证本地上报的硬件信息与Swarm API查询结果是否一致(Bug-01-02) |
| `register_self_joined_node()` | 处理本地脚本的自注册请求<br>**注意**：需检查swarm_node_id是否已被注册,同一卖家重复注册返回已有记录(幂等),不同卖家注册同一节点拒绝(Bug-01-03) |
| `validate_worker_joined()` | 校验节点是否已加入 Swarm<br>**实现要点**：应包含重试逻辑（最多5次，间隔1/2/3/5/8秒），处理节点加入的异步延迟 |
| `check_swarm_node_duplicate()` | 检查swarm_node_id是否已被注册(Bug-01-03) |
| `sync_compute_node_status()` | 同步节点状态 |
| `map_swarm_node_to_compute_node()` | 绑定 swarm 节点与业务节点 |
| `claim_swarm_node_ownership()` | 给已认领节点写入平台标签并绑定卖家归属 |

### 4.3 Scheduled Job Unit

| 接口单元 | 作用 |
|---|---|
| `sync_compute_node_status_job` | 周期同步节点状态 |

## 5. 依赖模块

- `Auth & Access`
- `Swarm Adapter`
- `PricingEngine`

## 6. MVP 备注

- 卖家接入不再要求网页手工登记节点表单。
- 推荐流程是”网页生成 bootstrap 命令 -> 卖家本地执行 join -> 本地脚本自动调用 `/register-self` -> 平台自动生成 `ComputeNode` 与已上架 `NodeRentalListing`”。
- 创建 `ComputeNode` 成功后，不等于自动可租。
- 正常情况下，校验完成、定价完成后应自动进入市场链路。
- **Token有效期**(Bug-01-02)：registration_token有效期30分钟，register-self时检查剩余时间，少于1分钟拒绝并返回TOKEN_EXPIRING_SOON错误
- **前端轮询**(Bug-01-05)：前端轮询bootstrap-sessions应设置5分钟超时，网络错误时使用指数退避重试(3秒/6秒/12秒)，提供手动刷新按钮
- **定价失败重试**(Bug-01-04)：后台定时任务每5分钟重试pending状态的listing，最多重试3次，失败后标记为pricing_failed并通知卖家

## 7. 状态机

### 7.1 BootstrapSession 状态转换

详见 [状态机设计文档](../底层框架+数据库/状态机设计文档.md) 第 6 节。

关键转换：
- `waiting_local_execution` → `registering`（本地脚本回调）
- `registering` → `verified`（验证成功）

### 7.2 ComputeNode 状态转换

详见 [状态机设计文档](../底层框架+数据库/状态机设计文档.md) 第 4 节。

关键转换：
- `online` ⇄ `busy`（可逆）
- `online` ⇄ `offline`（可逆）

## 8. 错误码清单

| 错误码 | HTTP 状态码 | 错误信息 | 说明 |
|-------|-----------|---------|------|
| `NODE_001` | 404 | 节点不存在 | ComputeNode 不存在 |
| `NODE_002` | 404 | Bootstrap 会话不存在 | BootstrapSession 不存在 |
| `NODE_003` | 400 | Bootstrap 会话已过期 | Session 超过有效期 |
| `NODE_004` | 400 | 注册令牌无效 | Registration token 不正确 |
| `NODE_005` | 409 | 节点已被注册 | Swarm 节点已被其他用户注册 |
| `NODE_006` | 500 | 节点验证失败 | Swarm 节点验证失败 |
| `NODE_007` | 409 | 节点状态不允许操作 | 节点当前状态不允许该操作 |
| `NODE_008` | 503 | 节点离线 | 节点心跳超时 |
| `NODE_009` | 200 | 节点已存在（幂等） | 该节点已被当前用户注册，返回已有记录(Bug-01-03) |
| `NODE_010` | 400 | Token即将过期 | 剩余时间少于1分钟，请重新生成(Bug-01-02) |

详细错误码规范见 [错误码规范文档](../底层框架+数据库/错误码规范文档.md)。

