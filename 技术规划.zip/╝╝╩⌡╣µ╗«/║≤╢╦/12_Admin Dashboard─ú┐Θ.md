# Admin Dashboard模块

版本：V1.0  
日期：2026-03-18

## 1. 模块目标

`Admin Dashboard` 模块负责读取聚合快照并组装前端视图，为管理员大屏提供总览、负载矩阵、排行、异常事件、时间线等只读接口。

## 2. 模块内部关系图

```mermaid
flowchart TB
    API[Admin APIs]
    Guard[Admin Auth Guard]
    View[Read-only View Builder]
    Snapshot[Snapshot Reader]
    Filter[Query / Window Parser]
    Metric[(Metric Snapshot / Cache)]

    API --> Guard
    Guard --> View
    API --> Filter
    Filter --> View
    View --> Snapshot
    Snapshot --> Metric
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 提供 dashboard 总览、负载矩阵、排行、异常事件、时间线 |
| 对其他后端模块 | 默认只读取 `Metric Collector + Snapshot / Cache` 的聚合结果；不在总览请求路径上直接拼事实表大 SQL |
| 对外 | 无直接外部系统交互 |
| 内部 | 读取快照、组装视图模型、分页钻取、结果裁剪 |

## 4. 后端接口

### 4.1 HTTP API Unit

| 接口单元 | 作用 |
|---|---|
| `GET /admin/dashboard/overview` | 获取总体指标 |
| `GET /admin/dashboard/snapshot` | 获取统一快照数据<br>**注意**：单次返回所有widget数据，确保数据一致性(Bug-07-01,Bug-07-02) |
| `GET /admin/dashboard/kpi-summary` | 获取顶部 KPI 摘要 |
| `GET /admin/dashboard/platform-health` | 获取平台健康度摘要 |
| `GET /admin/dashboard/platform-load` | 获取平台负载概览 |
| `GET /admin/dashboard/resource-capacity` | 获取全平台资源容量 |
| `GET /admin/dashboard/resource-utilization-trend` | 获取资源利用率趋势 |
| `GET /admin/dashboard/node-load-matrix` | 获取单机负载矩阵 |
| `GET /admin/dashboard/compute-node-stats` | 获取节点状态分布 |
| `GET /admin/dashboard/listing-stats` | 获取上架记录统计 |
| `GET /admin/dashboard/order-stats` | 获取订单状态分布 |
| `GET /admin/dashboard/benchmark-stats` | 获取测算任务统计 |
| `GET /admin/dashboard/runtime-events` | 获取异常事件列表 |
| `GET /admin/dashboard/activity-timeline` | 获取关键操作时间线 |
| `GET /admin/nodes/overview` | 获取节点总览 |
| `GET /admin/nodes/status-distribution` | 获取节点状态分布 |
| `GET /admin/nodes/load-matrix` | 获取节点负载矩阵 |
| `GET /admin/nodes/top-cpu` | 获取 CPU 负载最高节点排行 |
| `GET /admin/nodes/top-memory` | 获取内存负载最高节点排行 |
| `GET /admin/nodes/top-gpu` | 获取 GPU 负载最高节点排行 |
| `GET /admin/nodes/top-network-in` | 获取网络入流量最高节点排行 |
| `GET /admin/nodes/top-network-out` | 获取网络出流量最高节点排行 |
| `GET /admin/nodes/top-idle` | 获取最空闲节点排行 |
| `GET /admin/nodes/risk-ranking` | 获取风险节点排行 |
| `GET /admin/nodes/heartbeat-latency` | 获取节点心跳延迟分布 |
| `GET /admin/nodes/{node_id}/detail` | 获取单节点详情 |
| `GET /admin/market/overview` | 获取市场总览 |
| `GET /admin/market/listing-status-distribution` | 获取上架状态分布 |
| `GET /admin/market/gpu-distribution` | 获取 GPU 型号分布 |
| `GET /admin/market/cpu-tier-distribution` | 获取 CPU 档位分布 |
| `GET /admin/market/region-distribution` | 获取区域分布 |
| `GET /admin/market/price-trend` | 获取价格趋势 |
| `GET /admin/market/top-hot-listings` | 获取热门上架排行 |
| `GET /admin/market/top-expensive-listings` | 获取高价上架排行 |
| `GET /admin/market/top-cheap-listings` | 获取低价上架排行 |
| `GET /admin/orders/overview` | 获取订单总览 |
| `GET /admin/orders/status-distribution` | 获取订单状态分布 |
| `GET /admin/orders/create-trend` | 获取订单创建趋势 |
| `GET /admin/orders/release-type-distribution` | 获取释放类型占比 |
| `GET /admin/orders/expiring-soon` | 获取即将到期订单 |
| `GET /admin/orders/high-value` | 获取高价值订单排行 |
| `GET /admin/deployments/overview` | 获取部署总览 |
| `GET /admin/deployments/runtime-distribution` | 获取部署运行态分布 |
| `GET /admin/deployments/web-entry-distribution` | 获取网页入口状态分布 |
| `GET /admin/deployments/runtime-failure-top` | 获取部署失败原因排行 |
| `GET /admin/benchmarks/overview` | 获取测算任务总览 |
| `GET /admin/benchmarks/status-distribution` | 获取测算任务状态分布 |
| `GET /admin/benchmarks/mode-distribution` | 获取测算模式分布 |
| `GET /admin/benchmarks/source-type-distribution` | 获取测算输入来源分布 |
| `GET /admin/benchmarks/duration-trend` | 获取测算耗时趋势 |
| `GET /admin/benchmarks/failure-top` | 获取测算失败原因排行 |
| `GET /admin/risk/overview` | 获取风险总览 |
| `GET /admin/risk/runtime-events` | 获取运行异常事件流 |
| `GET /admin/risk/severity-distribution` | 获取异常严重度分布 |
| `GET /admin/risk/event-type-distribution` | 获取异常类型分布 |
| `GET /admin/risk/refund-compensation-stats` | 获取退款与补偿统计 |
| `GET /admin/risk/risk-nodes` | 获取高风险节点列表 |
| `GET /admin/audit/timeline` | 获取审计时间线 |
| `GET /admin/audit/action-type-distribution` | 获取审计动作分布 |
| `GET /admin/audit/recent-admin-logins` | 获取最近管理员登录记录 |

### 4.2 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `read_overview_snapshot()` | 读取总览快照 |
| `read_kpi_summary()` | 读取 KPI 摘要 |
| `read_platform_health()` | 读取平台健康度 |
| `read_platform_load_snapshot()` | 读取平台负载快照 |
| `read_resource_capacity_snapshot()` | 读取资源容量快照 |
| `read_resource_utilization_trend()` | 读取资源利用率趋势 |
| `read_node_load_matrix()` | 读取单机负载矩阵 |
| `read_node_status_distribution()` | 读取节点状态分布 |
| `read_node_top_ranking(metric_key)` | 读取指定节点排行 |
| `read_node_detail_view(node_id)` | 读取节点详情视图 |
| `read_market_overview()` | 读取市场总览 |
| `read_market_distribution(metric_key)` | 读取市场分布数据 |
| `read_market_price_trend()` | 读取价格趋势 |
| `read_market_listing_ranking(metric_key)` | 读取上架排行 |
| `read_order_overview()` | 读取订单总览 |
| `read_order_status_distribution()` | 读取订单状态分布 |
| `read_order_create_trend()` | 读取订单创建趋势 |
| `read_order_release_type_distribution()` | 读取释放类型分布 |
| `read_order_expiring_soon()` | 读取即将到期订单 |
| `read_order_high_value_ranking()` | 读取高价值订单排行 |
| `read_deployment_overview()` | 读取部署总览 |
| `read_deployment_runtime_distribution()` | 读取部署运行态分布 |
| `read_deployment_web_entry_distribution()` | 读取网页入口状态分布 |
| `read_deployment_failure_ranking()` | 读取部署失败原因排行 |
| `read_benchmark_overview()` | 读取测算总览 |
| `read_benchmark_status_distribution()` | 读取测算状态分布 |
| `read_benchmark_mode_distribution()` | 读取测算模式分布 |
| `read_benchmark_source_type_distribution()` | 读取测算来源分布 |
| `read_benchmark_duration_trend()` | 读取测算耗时趋势 |
| `read_benchmark_failure_ranking()` | 读取测算失败排行 |
| `read_risk_overview()` | 读取风险总览 |
| `read_runtime_event_feed()` | 读取异常事件流 |
| `read_risk_distribution(metric_key)` | 读取风险分布数据 |
| `read_refund_compensation_stats()` | 读取退款与补偿统计 |
| `read_risk_node_ranking()` | 读取风险节点排行 |
| `read_activity_timeline_view()` | 读取时间线视图 |
| `read_action_type_distribution()` | 读取审计动作分布 |
| `read_recent_admin_logins()` | 读取最近管理员登录记录 |

## 5. 依赖模块

- `Auth & Access`
- `Metric Collector + Snapshot / Cache`

## 6. MVP 备注

- 这是只读视图模块，不应成为新的业务写入口。
- 总览接口必须优先读快照或缓存，不能在页面打开时现场聚合大 SQL。
- 管理员前端应优先通过大量 widget 级只读接口并行取数，而不是把所有视觉区块强行塞进一个超大接口。
- **数据一致性**(Bug-07-01)：提供统一快照接口，所有widget数据来自同一时间点，避免逻辑矛盾
- **请求优化**(Bug-07-02)：使用聚合接口或分批加载，避免并行请求雪崩，添加限流保护(10 req/s)
- **敏感信息保护**(Bug-07-04)：节点详情接口使用字段白名单，不返回seller_user_id等敏感信息
- **参数校验**(Bug-07-06)：time_window参数限制最大90天，超过则返回400错误
