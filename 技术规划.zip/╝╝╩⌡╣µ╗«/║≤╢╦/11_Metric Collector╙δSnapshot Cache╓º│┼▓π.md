# Metric Collector与Snapshot Cache支撑层

版本：V1.1
日期：2026-03-18

## 1. 模块目标

`Metric Collector + Snapshot / Cache` 支撑层负责从业务模块读取事实数据，生成管理员大屏需要的聚合指标、趋势、排行和矩阵，并写入快照或缓存。

## 2. 模块内部关系图

```mermaid
flowchart TB
    Scheduler[Scheduled Jobs]
    Tasks[Async Metric Tasks]
    Collector[Metric Collector Service]
    Builder[Trend / Ranking / Matrix Builders]
    Snapshot[Snapshot Writer]
    Cache[Cache Writer]
    Sources[Business Module Readers]
    DB[(MySQL Snapshot Tables)]
    Redis[(Redis)]

    Scheduler --> Tasks
    Tasks --> Collector
    Collector --> Builder
    Collector --> Sources
    Builder --> Snapshot
    Builder --> Cache
    Snapshot --> DB
    Cache --> Redis
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 无直接前端接口 |
| 对其他后端模块 | 读取 `ComputeNode`、`NodeRentalListing`、`PricingEngine`、`RentalOrder`、`BenchmarkJob`、`Runtime Reconcile` 的事实数据；向 `Admin Dashboard` 提供可读快照 |
| 对外 | 读写 `MySQL` 快照表、`Redis` 缓存，依赖 `Celery / Scheduler` 定时刷新 |
| 内部 | 聚合计算、快照回写、缓存失效、趋势序列生成、排行计算 |

## 4. 后端接口

### 4.1 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `refresh_platform_metric_snapshot()` | 刷新平台总体指标 |
| `refresh_compute_node_metric_snapshot()` | 刷新单机负载与节点矩阵 |
| `refresh_market_metric_snapshot()` | 刷新市场与价格聚合 |
| `refresh_benchmark_metric_snapshot()` | 刷新测算模块聚合 |
| `refresh_risk_metric_snapshot()` | 刷新风险与异常聚合 |
| `read_dashboard_snapshot(snapshot_key)` | 提供统一快照读取能力 |

### 4.2 Async Task Unit

| 接口单元 | 作用 |
|---|---|
| `build_platform_metrics_task()` | 异步构建平台总览指标 |
| `build_node_load_matrix_task()` | 异步构建单机负载矩阵 |
| `build_market_stats_task()` | 异步构建市场供给与价格统计 |
| `build_benchmark_stats_task()` | 异步构建测算统计 |
| `build_risk_stats_task()` | 异步构建异常统计 |

### 4.3 Scheduled Job Unit

| 接口单元 | 作用 |
|---|---|
| `schedule_platform_metrics_refresh()` | 周期刷新总览指标 |
| `schedule_node_metrics_refresh()` | 周期刷新单机负载指标 |
| `schedule_market_metrics_refresh()` | 周期刷新市场指标 |
| `schedule_benchmark_metrics_refresh()` | 周期刷新测算指标 |
| `schedule_activity_timeline_refresh()` | 周期刷新活动时间线缓存 |

## 5. 依赖模块

- `ComputeNode Access`
- `NodeRentalListing Market`
- `PricingEngine`
- `RentalOrder & Deployment`
- `BenchmarkJob`
- `Runtime Reconcile`
- `MySQL`
- `Redis`
- `Celery / Scheduler`

## 6. MVP 备注

- 这是管理员模块的正式支撑层，不只是实现细节。
- 总览页和大屏接口默认只读这里生成的快照或缓存。
- 只有小范围、强过滤的详情接口才允许有限度回查事实表。

## 7. 数据一致性策略

### 7.1 一致性模型

采用**最终一致性**模型：
- 管理员看到的数据允许 1-5 分钟延迟
- 不追求实时强一致性
- 适合 Dashboard 场景

### 7.2 业务完成标记

为避免统计中间状态，只聚合已完成的业务操作：

```sql
-- 统计运行中订单（只统计业务完成的）
SELECT COUNT(*)
FROM rental_orders
WHERE business_completed = TRUE
  AND order_status = 'running';

-- 统计成功的测算任务
SELECT COUNT(*)
FROM benchmark_jobs
WHERE business_completed = TRUE
  AND job_status = 'succeeded';
```

### 7.3 聚合时机

- 订单：在 Deployment 创建成功后设置 `business_completed = TRUE`
- 测算：在结果写入完成后设置 `business_completed = TRUE`

## 8. 错误码清单

| 错误码 | HTTP 状态码 | 错误信息 | 说明 |
|-------|-----------|---------|------|
| `METRIC_001` | 404 | 快照不存在 | 指定的 metric snapshot 不存在 |
| `METRIC_002` | 500 | 聚合任务失败 | 指标聚合过程失败 |
| `METRIC_003` | 503 | 数据暂时不可用 | 快照正在生成中 |

详细错误码规范见 [错误码规范文档](../底层框架+数据库/错误码规范文档.md)。

