# 后端模块实施计划

## 1. 目录目标

本目录的文档已经把后端固定为“模块化单体”，并明确每个模块都要按以下单元描述和实现：

- `HTTP API Unit`
- `Internal Service Unit`
- `Async Task Unit`
- `Scheduled Job Unit`
- `Infrastructure Contract Unit`

因此当前项目的后端实施不能继续沿用现有 `system-template/system-springboot` 的通用后台思路，而应在仓库内新增平台专属后端主工程。

建议在以下位置实现：

- `../../Pivot_Computing_Power_Network/platform-backend`
- `../../Pivot_Computing_Power_Network/platform-worker`

同时，本目录里的 Mermaid 图和表格不是辅助说明，而是后端实施边界的一部分：

- Mermaid 图用于固定模块交互、调用方向、异步任务关系和依赖边界
- 表格用于固定 API、模块职责、输入输出、错误分支和测试矩阵

如果后续修改了后端模块边界、调用链、接口集合、任务职责或返回结构，必须同步修改相应 Mermaid 图和表格。

---

## 2. 推荐后端目录结构

```text
platform-backend/
  app/
    api/
      auth/
      seller/
      market/
      orders/
      benchmarks/
      admin/
    application/
      auth/
      compute_nodes/
      listings/
      orders/
      benchmark/
      reconcile/
      metrics/
    modules/
      auth/
      compute_nodes/
      listings/
      pricing/
      orders/
      benchmark/
      runtime_events/
      admin_dashboard/
    integrations/
      swarm/
      market_refs/
    repositories/
    models/
    schemas/
    core/
  tests/
    unit/
    integration/
    api/

platform-worker/
  app/
    tasks/
      compute_nodes/
      pricing/
      orders/
      benchmark/
      reconcile/
      metrics/
  tests/
```

---

## 3. 后端模块总实现原则

依据本目录全部文档，当前项目后端必须满足以下约束：

1. 只做模块化单体，不拆微服务。
2. 只有 `Swarm Adapter` 可以直接操作 Docker Swarm。
3. 只有 `PricingEngine` 可以生成平台价格。
4. 只有 `Runtime Reconcile` 负责周期异常发现。
5. 只有 `RentalOrder & Deployment.apply_runtime_abnormal_result()` 能推进异常订单主写入。
6. 只有 `Metric Collector + Snapshot / Cache` 负责管理员大盘重聚合。
7. 管理员模块默认读快照，不直接在请求路径上拼大 SQL。
8. 所有时间统一 UTC 存储与传输。
9. 所有接口必须带统一错误码、日志、trace_id。

### 3.1 根据问题目录补充的后端硬规则

依据 `技术规划\问题` 下的文档，后端计划需进一步收紧为以下刚性要求：

- `Auth & Access`
  - 必须采用 `access_token(15m) + refresh_token(7d)` 双 token
  - refresh token 必须可轮换、可撤销
  - 401 语义必须稳定，前端可自动刷新后重试
- `ComputeNode Access`
  - `bootstrap session` 标识必须高熵，不可枚举
  - `registration_token` 30 分钟，剩余不足 1 分钟拒绝注册
  - `register-self` 必须内置 1/2/3/5/8 秒重试
  - `swarm_node_id` 重复注册必须幂等或拒绝
  - 节点硬件信息必须通过 Swarm 侧独立校验
- `NodeRentalListing Market`
  - 价格过期阈值固定为 30 分钟
  - 提前 5 分钟刷新价格
  - 列表使用 cursor 分页，不用 offset
  - listing 详情必须有 `version` 和实时状态接口
- `RentalOrder & Deployment`
  - 下单必须在同一事务内完成 listing 加锁、余额冻结、订单、部署记录创建
  - 同一 listing 租用必须使用 `SELECT FOR UPDATE`
  - 支持 `idempotency_key`
  - 部署失败必须立即退款，不等待后台补偿
  - `expire_at` 必须从真正 `running` 时刻计算
  - 详情接口应返回 `remaining_seconds`
  - 申请网页连接前必须实时查询容器状态
- `BenchmarkJob`
  - 代码压缩包必须安全解压
  - git clone 必须支持预校验、浅克隆、阶段超时
  - benchmark 结果必须通过卷挂载或等效方式持久化
  - benchmark 容器必须有限权、限资源、限网络
- `Runtime Reconcile`
  - 巡检与连接校验要能联动优先同步
  - 异常事件必须幂等
  - 清理动作必须“最佳努力”，不可导致无限循环
  - 超过重试阈值后转人工处理
- `Admin Dashboard`
  - 必须有统一快照接口或统一快照时间戳
  - 管理接口必须走统一 admin 权限保护
  - 节点详情必须字段白名单
  - `time_window` 最大 90 天
  - 需要限流或批量加载策略，避免请求雪崩

---

## 4. 模块级实施方案

## 4.1 Auth & Access

依据 [01_账号与权限模块.md](./01_账号与权限模块.md)，本模块负责：

- 注册、登录、刷新、退出
- 当前用户解析
- buyer / seller / admin 能力校验

### 实现位置

- `platform-backend/app/api/auth/`
- `platform-backend/app/modules/auth/`
- `platform-backend/app/repositories/user_repository.py`
- `platform-backend/app/repositories/token_repository.py`

### 重点要求

- access token 15 分钟
- refresh token 7 天
- refresh token 可撤销、可轮换
- 普通用户与管理员入口隔离

### 测试方法

- API 测试：注册、登录、刷新、退出、获取当前用户
- 权限测试：buyer/seller/admin 权限边界
- 安全测试：过期 token、禁用用户、刷新后旧 token 失效

### 测试位置

- `platform-backend/tests/api/test_auth_flow.py`
- `platform-backend/tests/unit/test_access_guard.py`

## 4.2 Swarm Infrastructure

依据 [02_Swarm基础设施模块.md](./02_Swarm基础设施模块.md)，该模块不是业务代码主模块，而是基础契约和运维约束集合。

### 实现位置

- `infra/swarm/`
- `platform-backend/app/integrations/swarm/contracts.py`

### 重点要求

- 平台自持 manager
- 卖家只做 worker
- benchmark worker 独立隔离
- 固定标签和 placement 约束规范

### 测试方法

- 契约测试：节点标签规则、join 规则、placement 规则
- 环境 smoke：manager 健康、worker 加入、benchmark worker 标签存在

### 测试位置

- `tests/contracts/test_swarm_infra_contract.py`
- `tests/smoke/test_swarm_topology.py`

## 4.3 Swarm Adapter

依据 [03_Swarm Adapter模块.md](./03_Swarm Adapter模块.md)，该模块是所有 Swarm 操作唯一入口。

### 实现位置

- `platform-backend/app/integrations/swarm/`
- `platform-worker/app/integrations/swarm/`

### 重点要求

- join token 和 join command
- inspect node / service
- 获取硬件信息
- 标签认领和 availability 更新
- runtime service 与 benchmark service 创建/删除
- 标准化错误码 `SWARM_*`

### 测试方法

- 契约测试：统一返回结构
- 集成测试：service 参数翻译正确
- 故障测试：pending、missing、offline、label update failed

### 测试位置

- `platform-backend/tests/contracts/test_swarm_adapter_contract.py`
- `platform-backend/tests/integration/test_swarm_adapter_real_or_mock.py`

## 4.4 AI Benchmark Worker

依据 [04_AI测算模块.md](./04_AI测算模块.md)，该模块是 benchmark 容器内部执行体系。

### 实现位置

- `platform-benchmark/runner/`
- `platform-benchmark/scripts/`
- `platform-benchmark/prompts/`

### 重点要求

- 工作目录准备
- 输入注入
- 固定提示词执行
- 结果导出
- 清理测算环境

### 测试方法

- 单元测试：workspace、input injector、result exporter
- 容器测试：runner 在容器内能启动并输出结果文件

### 测试位置

- `platform-benchmark/tests/test_workspace_prepare.py`
- `platform-benchmark/tests/test_result_export.py`

## 4.5 ComputeNode Access

依据 [05_ComputeNode接入模块.md](./05_ComputeNode接入模块.md)，该模块负责：

- bootstrap 会话
- 本地自注册
- 节点认领
- 节点状态同步

### 实现位置

- `platform-backend/app/api/seller/compute_nodes.py`
- `platform-backend/app/modules/compute_nodes/`
- `platform-worker/app/tasks/compute_nodes/`

### 重点要求

- registration token 30 分钟
- `register-self` 有 Swarm 异步延迟重试
- 防重复注册和幂等返回
- 自动触发 listing 创建和定价链路

### 测试方法

- API 测试：创建 bootstrap session、查询 session、register-self、节点查询、手动 sync
- 集成测试：节点加入延迟重试、重复注册幂等、跨卖家冲突
- 状态机测试：bootstrap session 与 compute node 状态流转

### 测试位置

- `platform-backend/tests/api/test_compute_node_access_api.py`
- `platform-backend/tests/integration/test_register_self_flow.py`
- `platform-backend/tests/unit/test_bootstrap_retry_policy.py`

## 4.6 NodeRentalListing Market

依据 [06_NodeRentalListing市场模块.md](./06_NodeRentalListing市场模块.md)，该模块负责市场可见对象。

### 实现位置

- `platform-backend/app/api/market/listings.py`
- `platform-backend/app/api/seller/listings.py`
- `platform-backend/app/modules/listings/`

### 重点要求

- 一个 `ComputeNode` 对应一个 listing
- 标题、摘要、默认描述自动生成
- 卖家只能上下架，不能改价格
- 列表使用 cursor 分页
- 详情返回 `version` 支持乐观锁

### 测试方法

- API 测试：列表、详情、筛选、发布、下架
- 分页测试：cursor 翻页无重复、无遗漏
- 联动测试：节点状态变化对 rentable 状态的影响

### 测试位置

- `platform-backend/tests/api/test_market_listing_api.py`
- `platform-backend/tests/integration/test_listing_cursor_pagination.py`
- `platform-backend/tests/integration/test_listing_rentable_sync.py`

## 4.7 PricingEngine

依据 [07_PricingEngine定价模块.md](./07_PricingEngine定价模块.md)，本模块负责平台价格与价格说明。

### 实现位置

- `platform-backend/app/modules/pricing/`
- `platform-worker/app/tasks/pricing/`

### 重点要求

- 节点定价
- 外部参考数据获取
- listing 价格刷新
- 价格说明生成
- placeholder price 先可用

### 测试方法

- 单元测试：价格规则、占位价格、价格解释
- 集成测试：refresh job 刷新 listing 价格
- 过期测试：stale 标记与回退逻辑

### 测试位置

- `platform-backend/tests/unit/test_pricing_service.py`
- `platform-worker/tests/integration/test_price_refresh_job.py`

## 4.8 RentalOrder & Deployment

依据 [08_RentalOrder与Deployment模块.md](./08_RentalOrder与Deployment模块.md)，这是交易主链路核心模块。

### 实现位置

- `platform-backend/app/api/orders/`
- `platform-backend/app/modules/orders/`
- `platform-backend/app/modules/deployments/`
- `platform-worker/app/tasks/orders/`

### 重点要求

- 创建订单前校验 listing、价格、余额
- `idempotency_key` 防重下单
- 事务内完成冻结、订单、部署记录创建
- 部署失败立即退款
- 到期释放和结算
- SSE 或 WebSocket 推送部署状态
- 运行时间从 deployment `running` 开始计时

### 测试方法

- API 测试：创建订单、列表、详情、deployment 状态、release、web-connect
- 事务测试：冻结失败、部署记录失败、回滚完整
- 并发测试：同一 listing 并发下单防超售
- 结算测试：预冻结、实际使用、退款金额
- 推送测试：SSE 状态事件顺序正确

### 测试位置

- `platform-backend/tests/api/test_rental_order_api.py`
- `platform-backend/tests/integration/test_order_atomicity.py`
- `platform-backend/tests/integration/test_listing_locking.py`
- `platform-backend/tests/unit/test_order_billing.py`
- `platform-backend/tests/api/test_deployment_stream.py`

## 4.9 BenchmarkJob

依据 [09_BenchmarkJob模块.md](./09_BenchmarkJob模块.md)，该模块负责业务测算任务。

### 实现位置

- `platform-backend/app/api/benchmarks/`
- `platform-backend/app/modules/benchmark/`
- `platform-worker/app/tasks/benchmark/`

### 重点要求

- 支持 `code_archive` 和 `git_repository`
- 输入源严格互斥
- git 预校验与浅克隆
- 全局并发 3、单用户并发 1
- 结果推荐实时补充 listing 当前状态

### 测试方法

- API 测试：上传压缩包、创建 job、查询 job、查询 recommendations、刷新 recommendations
- 校验测试：输入源互斥、git 合法性、并发限制
- 异步测试：run_benchmark_job_task 成功和失败路径

### 测试位置

- `platform-backend/tests/api/test_benchmark_job_api.py`
- `platform-backend/tests/unit/test_benchmark_input_validation.py`
- `platform-worker/tests/integration/test_benchmark_task.py`

## 4.10 Runtime Reconcile

依据 [10_Runtime Reconcile模块.md](./10_Runtime Reconcile模块.md)，它是异常链路核心。

### 实现位置

- `platform-worker/app/tasks/reconcile/`
- `platform-backend/app/application/reconcile/`
- `platform-backend/app/modules/runtime_events/`

### 重点要求

- 每 30 秒巡检
- 巡检 `pending_deploy/running/releasing` 订单和 `pending/starting/running/stopping` 部署
- 分类异常
- 创建 `RuntimeEvent`
- 调用订单模块写异常结果

### 测试方法

- 单元测试：异常分类
- 集成测试：节点离线、service 丢失、状态不一致
- 幂等测试：重复巡检不重复退款

### 测试位置

- `platform-worker/tests/unit/test_reconcile_classifier.py`
- `platform-worker/tests/integration/test_runtime_reconcile_job.py`
- `platform-backend/tests/integration/test_runtime_event_idempotency.py`

## 4.11 Metric Collector + Snapshot / Cache

依据 [11_Metric Collector与Snapshot Cache支撑层.md](./11_Metric Collector与Snapshot Cache支撑层.md)，该层是 Admin Dashboard 正式支撑层。

### 实现位置

- `platform-backend/app/modules/metrics/`
- `platform-worker/app/tasks/metrics/`

### 重点要求

- 平台总览、节点矩阵、市场、benchmark、风险聚合
- MySQL snapshot + Redis cache
- 最终一致性
- 只聚合 `business_completed = TRUE` 的事实

### 测试方法

- 单元测试：聚合器、trend builder、ranking builder
- 集成测试：从事实表构建快照
- 一致性测试：统一快照时间点

### 测试位置

- `platform-worker/tests/unit/test_metric_builders.py`
- `platform-worker/tests/integration/test_metric_snapshot_build.py`

## 4.12 Admin Dashboard

依据 [12_Admin Dashboard模块.md](./12_Admin Dashboard模块.md)，该模块是只读聚合视图层。

### 实现位置

- `platform-backend/app/api/admin/`
- `platform-backend/app/modules/admin_dashboard/`

### 重点要求

- 管理员权限独立校验
- 优先读 snapshot/cache
- 支持 overview、nodes、market、orders、deployments、benchmarks、risk、audit 多组接口
- 提供统一 snapshot 接口保证同一时点数据一致

### 测试方法

- API 测试：overview、snapshot、各区块接口
- 权限测试：非 admin 禁止访问
- 限流与参数测试：窗口最大 90 天、请求速率控制

### 测试位置

- `platform-backend/tests/api/test_admin_dashboard_api.py`
- `platform-backend/tests/api/test_admin_guard.py`

---

## 5. 推荐开发顺序

后端必须按下面顺序推进：

1. 公共基础：枚举、错误码、trace_id、UTC 时间、日志、迁移
2. `Auth & Access`
3. `Swarm Infrastructure` 契约
4. `Swarm Adapter`
5. `ComputeNode Access`
6. `PricingEngine`
7. `NodeRentalListing Market`
8. `RentalOrder & Deployment`
9. `AI Benchmark Worker`
10. `BenchmarkJob`
11. `Runtime Reconcile`
12. `Metric Collector + Snapshot / Cache`
13. `Admin Dashboard`

原因：

- 节点、价格、listing、订单是交易主链路
- benchmark 和 dashboard 依赖主链路事实数据
- reconcile 依赖订单和 Swarm 状态
- admin 依赖 metrics 快照

---

## 6. 通用测试框架要求

后端所有模块至少要覆盖：

- 单元测试：规则、状态机、builder、guard
- API 测试：请求响应契约、错误码、权限
- 集成测试：数据库 + Redis + worker + adapter
- 异步任务测试：成功、失败、重试、超时
- 并发测试：下单、注册、退款幂等

并且必须补齐以下已知问题回归：

- token 刷新与过期重试
- 重复节点注册与跨卖家抢注
- 价格 stale 标记与刷新
- listing cursor 分页一致性
- 事务回滚后钱包余额恢复
- deployment 失败立即退款
- listing 并发超售拦截
- `idempotency_key` 重放
- `connect_url` 前实时容器校验
- benchmark 安全解压、超时、结果持久化
- reconcile 防循环、防重复事件
- admin 权限、快照一致性、时间窗口校验

推荐测试目录：

```text
platform-backend/tests/
  unit/
  api/
  integration/

platform-worker/tests/
  unit/
  integration/

tests/contracts/
tests/smoke/
```

---

## 7. 当前项目中的最小可交付切片

如果按最小闭环推进，后端第一批必须交付：

1. 用户登录与能力校验
2. 卖家 bootstrap 接入与节点认领
3. listing 自动生成与基础定价
4. 订单创建、冻结、deployment、释放
5. runtime reconcile 基础巡检
6. 一个管理员 overview 接口

这 6 项完成后，后端就具备最小可演示能力。

---

## 8. 当前阶段结论

本目录文档已经把后端边界收得很清楚。实现时最关键的不是“把接口数量写够”，而是保证：

- 交易主链路有唯一主写入口
- Swarm 与业务逻辑彻底隔离
- 异步任务不绕过状态机
- Dashboard 不去直查重聚合事实表

后续任何后端代码编写，都应以本 `PLAN.md` 作为目录级实施基线。
