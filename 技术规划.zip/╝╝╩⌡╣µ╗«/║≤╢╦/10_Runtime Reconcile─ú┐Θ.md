# Runtime Reconcile模块

版本：V1.0  
日期：2026-03-18

## 1. 模块目标

`Runtime Reconcile` 模块负责周期巡检节点和部署状态、识别异常释放、创建 `RuntimeEvent`，并推进退款或补偿链路。

## 2. 模块内部关系图

```mermaid
flowchart TB
    Job[runtime_reconcile_job]
    Loader[Target Loader]
    NodeInspector[ComputeNode Inspector]
    DeployInspector[Deployment Inspector]
    Classifier[Anomaly Classifier]
    EventWriter[RuntimeEvent Writer]
    OrderWriter[Abnormal Result Applier]
    SwarmClient[Swarm Adapter Client]
    NodeClient[ComputeNode Client]
    OrderClient[RentalOrder & Deployment Client]
    DB[(MySQL)]

    Job --> Loader
    Loader --> NodeInspector
    Loader --> DeployInspector
    NodeInspector --> SwarmClient
    DeployInspector --> SwarmClient
    NodeInspector --> NodeClient
    DeployInspector --> OrderClient
    NodeInspector --> Classifier
    DeployInspector --> Classifier
    Classifier --> EventWriter
    Classifier --> OrderWriter
    EventWriter --> DB
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 无直接前端接口 |
| 对其他后端模块 | 推进 `ComputeNode`、`RentalOrder` 的异常状态；为 `Admin Dashboard` 提供异常事实数据 |
| 对外 | 通过 `Swarm Adapter` 获取真实运行状态 |
| 内部 | 周期巡检、异常判断、异常事件记录、退款补偿触发 |

## 4. 后端接口

### 4.1 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `load_reconcile_targets()` | 加载本轮巡检目标 |
| `reconcile_compute_nodes()` | 巡检节点状态 |
| `reconcile_deployments()` | 巡检部署状态 |
| `classify_runtime_anomaly()` | 把 Swarm 返回结果归类为节点离线、部署丢失或状态不一致 |
| `detect_abnormal_release()` | 判断是否异常释放 |
| `create_runtime_event()` | 创建异常事件 |
| `trigger_refund_or_compensation()` | 触发退款或补偿 |

### 4.2 Scheduled Job Unit

| 接口单元 | 作用 |
|---|---|
| `runtime_reconcile_job` | 周期巡检任务 |

## 5. 依赖模块

- `Swarm Adapter`
- `ComputeNode Access`
- `RentalOrder & Deployment`

## 6. MVP 备注

- 它是异常链路的核心模块。
- 异常处理结果由买家侧页面和管理员 dashboard 读取展示。
- `runtime_reconcile_job` 推荐每 30 秒执行一轮。
- 本轮扫描范围推荐固定为：`rental_orders.order_status in (pending_deploy, running, releasing)`，且 `deployments.runtime_status in (pending, starting, running, stopping)`。
- 如果巡检确认节点不可继续接单，可调用 `Swarm Adapter.set_node_availability(..., drain)` 阻止新的 runtime service 调度上去。
