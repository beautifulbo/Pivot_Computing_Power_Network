# PricingEngine定价模块

版本：V1.0  
日期：2026-03-18

## 1. 模块目标

`PricingEngine` 模块负责生成平台价格、定时刷新价格，并为其他模块提供价格说明和价格快照。

## 2. 模块内部关系图

```mermaid
flowchart TB
    Service[PricingService]
    RuleEngine[Pricing Rules]
    Source[External Market Source Adapter]
    SnapshotRepo[Price Snapshot Repository]
    RefreshJob[Price Refresh Jobs]
    DB[(MySQL)]

    RefreshJob --> Service
    Service --> RuleEngine
    Service --> Source
    Service --> SnapshotRepo
    SnapshotRepo --> DB
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 无直接前端接口 |
| 对其他后端模块 | 向 `ComputeNode Access`、`NodeRentalListing Market`、`RentalOrder & Deployment` 提供价格生成与价格解释 |
| 对外 | 联网抓取或读取市场参考数据 |
| 内部 | 定价计算、价格刷新、价格说明 |

## 4. 后端接口

### 4.1 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `price_compute_node()` | 计算节点平台价格 |
| `fetch_market_reference()` | 抓取或读取外部市场参考数据 |
| `refresh_listing_price()` | 刷新上架记录价格 |
| `explain_listing_price()` | 生成价格说明 |

### 4.2 Scheduled Job Unit

| 接口单元 | 作用 |
|---|---|
| `refresh_listing_price_job` | 定期刷新价格 |
| `mark_stale_price_job` | 标记过期价格 |

## 5. 依赖模块

- `ComputeNode Access`

## 6. MVP 备注

- 第一阶段允许内部先返回占位价格。
- 但卖家侧始终不能手工录入价格。
