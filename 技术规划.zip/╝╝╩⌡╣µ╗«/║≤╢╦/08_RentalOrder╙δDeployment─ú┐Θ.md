# RentalOrder与Deployment模块

版本：V1.1
日期：2026-03-18

## 1. 模块目标

`RentalOrder & Deployment` 模块负责创建租用订单、生成部署记录、查看运行状态、正常释放，以及 mock 扣费、结算、异常补偿写入。

## 2. 模块内部关系图

```mermaid
flowchart TB
    API[Rental APIs]
    ExpireJob[Auto Release Job]
    Service[RentalOrderService]
    Wallet[Mock Wallet / Billing Subservice]
    Deploy[Deployment Subservice]
    Gateway[Runtime Web Gateway Signer]
    OrderRepo[RentalOrder Repository]
    DeployRepo[Deployment Repository]
    ListingClient[Listing Client]
    PricingClient[Pricing Client]
    SwarmClient[Swarm Adapter Client]
    DB[(MySQL)]
    Redis[(Redis)]

    API --> Service
    ExpireJob --> Service
    Service --> Wallet
    Service --> Deploy
    Service --> Gateway
    Service --> OrderRepo
    Service --> DeployRepo
    Service --> ListingClient
    Service --> PricingClient
    Deploy --> SwarmClient
    OrderRepo --> DB
    DeployRepo --> DB
    Wallet --> Redis
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 创建订单、查询订单、查询运行状态、申请网页连接、主动释放 |
| 对其他后端模块 | 给 `Runtime Reconcile`、`Admin Dashboard` 提供订单和部署事实数据 |
| 对外 | 通过 `Swarm Adapter` 调度和释放运行 service；通过 `Runtime Web Gateway` 生成短时网页连接；访问 `Redis` 做临时状态和 mock 结算 |
| 内部 | 订单创建、部署创建、释放、结算、到期自动释放 |

## 4. 后端接口

### 4.1 HTTP API Unit

| 接口单元 | 作用 |
|---|---|
| `POST /rental-orders` | 创建租用订单 |
| `GET /rental-orders` | 获取订单列表 |
| `GET /rental-orders/{order_id}` | 获取订单详情 |
| `GET /rental-orders/{order_id}/deployment` | 获取运行状态 |
| `POST /rental-orders/{order_id}/web-connect` | 申请短时网页连接 |
| `POST /rental-orders/{order_id}/release` | 主动释放 |
| `GET /rental-orders/{order_id}/deployment/stream` | SSE实时推送部署状态<br>**注意**：替代轮询，减少服务器压力(Bug-04-04) |

### 4.2 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `create_rental_order()` | 创建业务订单<br>**注意**：包含余额冻结,使用数据库事务保证原子性(Bug-03-02) |
| `freeze_mock_balance()` | 冻结 mock 金额(内部方法,由create_rental_order调用) |
| `create_deployment()` | 创建部署记录 |
| `deploy_runtime_service()` | 发起实际部署 |
| `handle_deployment_failure()` | 处理部署失败,立即触发退款(Bug-03-03) |
| `prepare_runtime_web_connect()` | 校验运行态并生成短时 connect_url<br>**注意**：申请连接时实时查询Swarm容器状态(Bug-04-03) |
| `apply_runtime_abnormal_result()` | 接收巡检异常结果，推进订单、部署、退款和补偿状态 |
| `release_deployment()` | 释放部署 |
| `settle_order_amount()` | 结算订单金额 |

### 4.3 Scheduled Job Unit

| 接口单元 | 作用 |
|---|---|
| `auto_release_expired_order_job` | 到期自动释放 |

## 5. 依赖模块

- `Auth & Access`
- `NodeRentalListing Market`
- `PricingEngine`
- `Swarm Adapter`

## 6. MVP 备注

- mock 钱包和结算先放在该模块内部。
- `POST /rental-orders` 在创建订单前必须校验 3 件事：`listing` 当前是否可租、前端展示价格是否已过期、mock 余额是否足够冻结。
- **价格校验容忍度**(Bug-03-01)：允许±5%价格波动，超过则返回PRICE_CHANGED错误并提示用户确认新价格
- **并发控制**(Bug-03-04)：使用数据库行锁(SELECT FOR UPDATE)锁定listing,在事务内检查并更新rentable_status,防止并发超售。
- **幂等性保护**(Bug-03-05)：支持客户端传递idempotency_key,后端使用该key进行去重,避免网络超时后重复下单。
- **事务原子性**(Bug-03-02)：余额冻结、订单创建、部署记录创建必须在同一事务中,任一步骤失败全部回滚。
- **部署失败处理**(Bug-03-03)：Swarm部署失败时立即标记订单失败并同步执行退款,不等待后台任务。
- **到期时间计算**(Bug-03-06)：expire_at从容器running时开始计算，而非订单创建时，确保用户获得完整租用时长
- **状态推送**(Bug-04-04)：使用SSE或WebSocket推送部署状态变化，避免前端轮询造成服务器压力
- **工作区能力**(Bug-04-05)：从镜像Label自动提取workspace_capabilities，确保能力声明与实际一致
- 该模块对前端至少要返回这些明确业务错误：`listing_not_rentable`、`price_changed`、`insufficient_balance`。
- `GET /rental-orders/{order_id}/deployment` 对前端至少要返回这些字段：`runtime_status`、`access_url`、`web_entry_status`、`workspace_mode`、`workspace_capabilities`、`runtime_event_summary`。
- `POST /rental-orders/{order_id}/web-connect` 对前端至少要返回这些明确业务错误：`deployment_not_running`、`web_entry_unavailable`、`connect_prepare_failed`。
- `apply_runtime_abnormal_result()` 是 `Runtime Reconcile` 推进异常链路时的唯一订单写入口，用于把 `RentalOrder`、`Deployment`、退款和补偿状态保持一致。

## 7. 扣费机制详细说明

### 7.1 扣费模型

采用**预冻结 + 按实际使用结算**模型：

1. **下单时**：
   - 计算预估费用：`frozen_amount = duration_minutes / 60 * unit_price_hourly`
   - 冻结该金额到 `wallet_accounts.frozen_balance`
   - 前端显示：预估费用 ¥X.XX（基于租期和单价）

2. **运行中**：
   - 每 10 分钟记录一次实际运行时长到 `rental_orders.actual_runtime_minutes`
   - 不立即扣费，只更新已使用时长

3. **释放时**：
   - 计算实际费用：`actual_amount = (actual_runtime_minutes / 60) * unit_price_hourly`
   - 结算：从冻结金额中扣除实际费用
   - 退还差额：`refund_amount = frozen_amount - actual_amount`
   - 更新 `wallet_accounts`：
     - `frozen_balance -= frozen_amount`
     - `available_balance += refund_amount`
   - 标记业务完成：`business_completed = TRUE`

### 7.2 接口变更

**`POST /rental-orders` 请求**：
```json
{
  "listing_id": 123,
  "duration_minutes": 300,
  "template_image_id": 1
}
```

**`POST /rental-orders` 响应**：
```json
{
  "order_id": 456,
  "order_no": "ORD_20260318_001",
  "frozen_amount": 50.00,
  "estimated_amount_min": 10.00,
  "estimated_amount_max": 50.00,
  "unit_price_hourly": 10.00,
  "message": "实际费用将按使用时长结算"
}
```

### 7.3 结算逻辑

在 `settle_order_amount()` 中实现：

```python
def settle_order_amount(order_id: int):
    order = get_order(order_id)

    # 计算实际费用（精确到分钟）
    actual_amount = (order.actual_runtime_minutes / 60.0) * order.unit_price_hourly

    # 计算退款
    refund_amount = order.frozen_amount - actual_amount

    # 更新订单
    order.actual_amount = actual_amount
    order.refund_amount = refund_amount
    order.business_completed = True

    # 更新钱包
    wallet.frozen_balance -= order.frozen_amount
    wallet.available_balance += refund_amount

    # 记录流水
    create_wallet_transaction(
        type='settlement',
        amount=actual_amount,
        order_id=order_id
    )
```

## 8. 状态机

### 8.1 RentalOrder 状态转换

详见 [状态机设计文档](../底层框架+数据库/状态机设计文档.md) 第 2 节。

关键转换：
- `created` → `pending_deploy`（冻结成功）
- `pending_deploy` → `running`（部署成功，此时设置 `business_completed = TRUE`）
- `running` → `releasing`（用户释放或到期）
- `releasing` → `released`（结算完成）

### 8.2 Deployment 状态转换

详见 [状态机设计文档](../底层框架+数据库/状态机设计文档.md) 第 3 节。

关键转换：
- `pending` → `starting`（Swarm service 创建）
- `starting` → `running`（容器启动成功）
- `running` → `stopping`（收到释放请求）
- `stopping` → `released`（清理完成）

## 9. 错误码清单

| 错误码 | HTTP 状态码 | 错误信息 | 说明 |
|-------|-----------|---------|------|
| `ORDER_001` | 404 | 订单不存在 | RentalOrder 不存在 |
| `ORDER_002` | 403 | 无权访问该订单 | 订单不属于当前用户 |
| `ORDER_003` | 400 | 余额不足 | 钱包余额不足以冻结 |
| `ORDER_004` | 409 | 订单状态不允许操作 | 当前订单状态不允许该操作 |
| `ORDER_005` | 500 | 部署创建失败 | Deployment 创建失败 |
| `ORDER_006` | 500 | 容器启动失败 | Swarm service 启动失败 |
| `ORDER_007` | 404 | 部署不存在 | Deployment 不存在 |
| `ORDER_008` | 409 | 网页入口未就绪 | web_entry_status 不是 ready |
| `ORDER_009` | 400 | 租期超出限制 | 租期超过最大允许值 |
| `ORDER_010` | 400 | 租期低于最小值 | 租期低于最小允许值 |
| `ORDER_011` | 409 | 上架记录不可租用 | listing rentable_status 不是 rentable |
| `ORDER_012` | 400 | 价格已变更 | 当前价格与前端展示不一致 |

详细错误码规范见 [错误码规范文档](../底层框架+数据库/错误码规范文档.md)。

