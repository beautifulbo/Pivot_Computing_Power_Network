# Swarm Adapter模块

版本：V1.1
日期：2026-03-18

## 1. 模块目标

`Swarm Adapter` 是所有 Docker Swarm 操作的唯一入口，负责屏蔽 Docker CLI / SDK 细节，并向业务模块提供标准化内部接口。

## 2. 模块内部关系图

```mermaid
flowchart TB
    Facade[SwarmFacadeService]
    Command[SwarmCommandService]
    Normalizer[Result Normalizer]
    Wrapper[Docker SDK / CLI Wrapper]
    Swarm[Docker Swarm]

    Facade --> Command
    Facade --> Normalizer
    Command --> Wrapper
    Wrapper --> Swarm
    Wrapper --> Normalizer
```

## 3. 交互分类说明

| 交互方向 | 内容 |
|---|---|
| 对前端 | 无 |
| 对其他后端模块 | 提供节点查询、join token 读取、节点标签认领、service 创建与删除等内部接口 |
| 对外 | 直接调用 Docker Swarm |
| 内部 | `service facade -> adapter -> sdk/cli wrapper` |

## 4. 后端接口

### 4.1 Internal Service Unit

| 接口单元 | 作用 |
|---|---|
| `get_join_token()` | 获取 Worker 接入信息 |
| `build_worker_join_command()` | 组装 worker join 命令 |
| `inspect_swarm_node()` | 查询节点状态 |
| `inspect_swarm_node_by_id()` | 按 `swarm_node_id` 查询节点状态 |
| `get_node_hardware_info()` | 从Swarm API查询节点真实硬件信息(CPU/内存/GPU)(Bug-01-02) |
| `list_swarm_nodes()` | 获取集群节点列表 |
| `claim_swarm_node_labels()` | 认领节点并写入平台标签 |
| `create_runtime_service()` | 创建租用运行 service |
| `inspect_runtime_service()` | 查询运行 service 状态 |
| `stop_runtime_service()` | 停止运行 service |
| `remove_runtime_service()` | 删除运行 service |
| `create_benchmark_service()` | 创建测算容器 |
| `remove_benchmark_service()` | 删除测算容器 |

## 5. 依赖模块

- `Swarm Infrastructure`

## 6. MVP 备注

- 这是最关键的后端隔离层。
- 其他模块禁止直接调用 Docker SDK 或 CLI。

## 7. Benchmark Service 资源限制配置

### 7.1 资源限制

`create_benchmark_service()` 必须包含以下资源限制：

```python
benchmark_service_config = {
    'resources': {
        'limits': {
            'cpus': '2.0',      # 最多 2 核
            'memory': '4G',     # 最多 4GB 内存
        },
        'reservations': {
            'cpus': '1.0',
            'memory': '2G',
        }
    }
}
```

### 7.2 安全配置

```python
security_config = {
    'cap_drop': ['ALL'],                    # 移除所有 Linux capabilities
    'security_opt': ['no-new-privileges'],  # 禁止提权
    'read_only': False,                     # 工作目录可写
    'networks': ['benchmark_isolated']      # 隔离网络
}
```

### 7.3 超时配置

- 通过 `stop_grace_period` 设置优雅停止时间
- 配合 Celery task 的 `time_limit` 实现超时控制

## 8. 错误码清单

| 错误码 | HTTP 状态码 | 错误信息 | 说明 |
|-------|-----------|---------|------|
| `SWARM_001` | 404 | Swarm 节点不存在 | Swarm 节点 ID 不存在 |
| `SWARM_002` | 503 | Swarm 节点未就绪 | 节点状态不是 ready |
| `SWARM_003` | 500 | 节点认领失败 | 节点标签写入失败 |
| `SWARM_004` | 503 | Swarm 节点离线 | 节点状态为 down |
| `SWARM_005` | 202 | Service 等待调度 | Service 状态为 pending |
| `SWARM_006` | 500 | Service 创建失败 | Swarm service 创建失败 |
| `SWARM_007` | 404 | Service 不存在 | Swarm service 不存在 |
| `SWARM_008` | 500 | Service 删除失败 | Swarm service 删除失败 |
| `SWARM_009` | 408 | Benchmark 执行超时 | Benchmark service 超时 |
| `SWARM_010` | 500 | 标签更新失败 | 节点标签更新失败 |

详细错误码规范见 [错误码规范文档](../底层框架+数据库/错误码规范文档.md)。

