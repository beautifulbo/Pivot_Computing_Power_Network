# Pivot Computing Power Network 实施方案

## 1. 文档目标

本方案用于指导当前仓库（`..`）项目后续代码编写，基于以下两部分现状整理：

- `技术规划` 目录下的产品、架构、数据库、业务流程、专项设计、问题分析文档
- 当前仓库中的已有代码，尤其是 `Pivot_Computing_Power_Network` 目录内的门户、模板系统与相关子项目

本方案不以“继续堆叠现有通用后台模板”为主，而是以“在当前仓库内新增一个真正面向算力交易平台的新系统”为主线，逐步与现有门户集成。

同时，本文件不是为了替代各子目录的 `PLAN.md`，而是作为整个 `技术规划` 目录的执行主导航：

- `综述/00_全局总述文档.md`
  - 负责统一项目目标、核心名词、总体架构、文档分类和推荐阅读顺序
- `技术规划/PLAN.md`
  - 负责把整套文档收敛成总实施顺序、阶段划分、代码落点、优先级和测试基线
- `底层框架+数据库/PLAN.md`
  - 负责数据库、错误码、状态机、幂等与并发等基础设施约束
- `后端/PLAN.md`
  - 负责后端模块化单体的模块边界、目录结构、API / service / task / contract 的组织方式
- `前端/PLAN.md`
  - 负责独立 `platform-frontend` 的新页面落点、分层规则、页面约束与 AI 协作方式
- `业务流程/PLAN.md`
  - 负责 7 条核心业务链路的实现顺序、流程边界、代码落点和流程测试
- `复杂独立模块专项文档/PLAN.md`
  - 负责 `Swarm Adapter`、`BenchmarkJob`、`PricingEngine`、`Runtime Reconcile`、`Admin Dashboard` 这类高复杂模块的专项落地
- `通用规范/PLAN.md`
  - 负责时间、错误码、前后端公共约束与统一工具落点

后续开发时，应把本文件视为“总调度计划”，把各子目录 `PLAN.md` 视为“模块级实施手册”。

---

## 1.1 核心模块与主参考计划

根据 `综述/00_全局总述文档.md` 中的模块划分，后续开发和回看文档时应按下面的映射理解：

- `Auth & Access`
  - 主参考：`后端/PLAN.md`
  - 补充参考：`底层框架+数据库/PLAN.md`、`通用规范/PLAN.md`
- `ComputeNode Access`
  - 主参考：`业务流程/PLAN.md`
  - 补充参考：`后端/PLAN.md`、`复杂独立模块专项文档/PLAN.md`、`底层框架+数据库/PLAN.md`
- `NodeRentalListing Market`
  - 主参考：`业务流程/PLAN.md`
  - 补充参考：`后端/PLAN.md`、`前端/PLAN.md`
- `PricingEngine`
  - 主参考：`复杂独立模块专项文档/PLAN.md`
  - 补充参考：`业务流程/PLAN.md`、`后端/PLAN.md`
- `RentalOrder & Deployment`
  - 主参考：`业务流程/PLAN.md`
  - 补充参考：`后端/PLAN.md`、`底层框架+数据库/PLAN.md`、`复杂独立模块专项文档/PLAN.md`
- `BenchmarkJob`
  - 主参考：`复杂独立模块专项文档/PLAN.md`
  - 补充参考：`业务流程/PLAN.md`、`后端/PLAN.md`、`前端/PLAN.md`
- `Runtime Reconcile`
  - 主参考：`复杂独立模块专项文档/PLAN.md`
  - 补充参考：`业务流程/PLAN.md`、`后端/PLAN.md`、`底层框架+数据库/PLAN.md`
- `Metric Collector + Snapshot / Cache`
  - 主参考：`后端/PLAN.md`
  - 补充参考：`复杂独立模块专项文档/PLAN.md`
- `Admin Dashboard`
  - 主参考：`业务流程/PLAN.md`
  - 补充参考：`复杂独立模块专项文档/PLAN.md`、`后端/PLAN.md`、`前端/PLAN.md`

## 1.2 推荐阅读与使用顺序

如果要进入具体开发，应按下面顺序使用文档：

1. 先读 `综述/00_全局总述文档.md`，统一项目目标、名词和总体架构。
2. 再读当前总 `PLAN.md`，明确阶段顺序、优先级和全局代码落点。
3. 开始某个领域开发前，重新回看所有子目录 `PLAN.md`，再重点阅读与当前任务最相关的 1 到 3 个子计划。
4. 若实现的是主流程页面或主写接口，再补读对应的 `业务流程` 文档和 `问题` 目录中的 bug 文档。
5. 若实现的是高复杂模块，再补读对应的专项设计文档，而不是只读接口名称就开始编码。

## 1.3 Mermaid 图与表格的正式作用

后续阅读和维护所有 `PLAN.md` 时，必须把 Mermaid 图和表格视为正式设计输入，而不是排版装饰。

- Mermaid 图的作用：
  - 定义流程顺序
  - 定义模块边界
  - 定义调用方向
  - 定义状态推进关系
- 表格的作用：
  - 定义接口矩阵
  - 定义字段集合
  - 定义错误码与状态映射
  - 定义优先级、测试覆盖和模块职责分工

执行时必须遵守以下约束：

- 如果实现改变了流程顺序、页面跳转、模块依赖、状态机、接口集合、字段集合或测试矩阵，必须同步更新对应 Mermaid 图和表格。
- 不允许出现“正文已变、图没变”或“代码已变、表没变”的情况。
- 评审 `PLAN.md` 时，图、表、正文三者必须相互一致；若不一致，应视为规划未收敛，不能直接据此推进代码。

## 2. 当前代码与目标差距

### 2.1 当前已有内容

- 已有一个通用后台模板体系：
  - 前端：Vue2 + Element UI 的系统管理壳
  - 后端：Spring Boot 的用户、角色、菜单、日志、JWT 基础能力
- 已有若干子系统入口与代理配置，但大多不是算力交易平台核心业务实现
- 当前数据库结构主要还是通用权限系统表，尚未落地算力平台领域模型

### 2.2 目标能力

根据 `技术规划`，目标系统需要完整覆盖：

- 节点接入与节点状态管理
- 算力商品发布与价格计算
- 租用订单、支付占位、生命周期状态机
- 部署任务、容器编排、运行态对账
- 基准测试（BenchmarkJob）
- 指标采集与管理后台
- 用户端门户与管理员端控制台
- 完整日志、错误码、审计、告警和测试体系

### 2.2.1 当前必须统一的产品口径

根据 `综述/00_全局总述文档.md`，后续所有实现都必须先统一以下口径：

- 当前平台卖的是“按时长租用的浏览器可访问运行环境”，不是“可 SSH 的裸机器”
- 卖家接入走“本地 bootstrap + 自动认领 + 自动生成 listing”，不是网页手工登记节点
- `ComputeNode` 是基础设施对象，`NodeRentalListing` 是市场对象，当前阶段一对一绑定
- `PricingEngine` 是唯一合法定价入口，卖家不能自己定价
- `BenchmarkJob` 与市场直租是两条独立入口、独立流程，Benchmark 只负责推荐，不自动下单
- 所有 Docker Swarm 操作必须收敛到 `Swarm Adapter`
- 管理员大盘依赖 `Metric Collector + Snapshot / Cache`，不能靠页面打开时现场聚合大查询

### 2.3 结论

当前代码只能复用“门户整合、历史系统参考、旧代理配置”这类外围能力，无法直接承载目标业务。应在仓库内新增平台专属后端、任务服务和独立前端，而不是为了沿用旧门户去扭曲新平台边界。
同时前端实现必须遵守两条硬约束：

- 所有新前端页面都应优先落地到独立 `platform-frontend`，当前阶段不要求 `platform-backend` 兼容旧 `system-template/system-vue`
- 页面数量、页面职责、区域划分和核心跳转关系，统一严格遵循 `./前端/前端页面规划文档.md`
- 前端实现必须遵守 `./一些背景信息文档/01-前端分层与AI协作规则.md`，先定接口、状态、业务流程和测试，再让 AI 接 UI

---

## 3. 建议目录与代码落点

建议在 `../Pivot_Computing_Power_Network` 下新增如下目录：

```text
Pivot_Computing_Power_Network/
  platform-backend/          # FastAPI 主业务服务
  platform-worker/           # Celery 异步任务服务
  platform-frontend/         # 新平台主前端
  platform-benchmark/        # benchmark 执行器、脚本、适配器
  platform-bootstrap/        # 启动脚本、初始化脚本、样例配置
  system-template/
    system-vue/              # 历史门户与旧系统壳，后续再决定是否接入新平台
  infra/
    mysql/
    redis/
    nginx/
    docker/
    swarm/
  tests/
    e2e/
    contracts/
    fixtures/
```

### 3.1 推荐职责

- `platform-backend`
  - 负责 API、鉴权、核心业务状态机、数据库访问、Swarm 调用编排
- `platform-worker`
  - 负责异步任务：部署轮询、回收、指标采集、对账、BenchmarkJob 调度
- `platform-frontend`
  - 负责新平台用户端页面、管理后台页面、订单与节点交互页面
- `platform-benchmark`
  - 负责实际基准测试程序与结果解析
- `tests`
  - 负责端到端测试、契约测试、统一测试夹具

---

## 4. 环境要求

## 4.1 开发环境

- Windows 11 或 Linux/macOS 开发机均可
- Python 3.11+
- Node.js 20+
- pnpm 8+ 或 npm 10+
- Docker Desktop 24+
- Git

## 4.2 运行依赖

- MySQL 8.0
- Redis 7
- Celery Worker
- Nginx
- Docker Engine
- Docker Swarm（开发环境可先 mock，再接真实环境）

## 4.3 Python 依赖建议

- FastAPI
- SQLAlchemy 2.x
- Alembic
- Pydantic v2
- Celery
- redis
- httpx
- pytest
- pytest-asyncio
- pytest-cov

## 4.4 前端依赖建议

- `platform-frontend` 采用独立前端工程实现
- 建议直接使用 `Vue 3 + Vite + Pinia + Vue Router`
- 前端页面实现必须按 `前端页面规划文档.md` 既定结构推进，不能因为兼容旧门户而改写主流程
- 前端分层必须至少包括：UI 层、页面编排层、状态层、网络层、业务层、基础组件层
- Axios
- Vitest
- Vue Test Utils
- Playwright

说明：

- 当前仓库中的旧门户不再作为新平台前端主实现依据。
- 当前正式实现口径以独立 `platform-frontend` 为准。
- 如需后续与旧门户整合，应单列为“门户集成阶段”，不得影响当前主线的后端契约和前端页面结构。

---

## 5. 优先级模型

本项目不应平均推进，必须按交易主链路优先。

### 5.1 P0：必须先完成

这些部分决定系统是否能形成最小可运行闭环：

1. 新平台骨架与基础工程
2. 数据库与迁移体系
3. 统一鉴权、用户体系、错误码、审计日志
4. 节点接入与节点状态管理
5. 商品发布与基础定价
6. 订单创建、资源锁定、部署与释放
7. 运行态对账（Runtime Reconcile）
8. 最小可用前端页面
9. 测试基线与 CI 基础

其中第 8 项的前端工作必须满足：

- 基于独立 `platform-frontend` 推进
- 当前阶段不强制兼容旧门户、旧路由骨架、旧登录壳和旧全局菜单体系
- 严格对齐 `前端页面规划文档.md` 已定义的页面与跳转关系
- 页面不得直接写请求和复杂业务规则，统一通过 `api + service + page-model + store` 分层实现
- AI 协作开发顺序固定为：接口契约 -> 状态模型 -> 业务流程 -> 测试 -> UI

### 5.2 P1：主链路稳定后立即补齐

这些部分决定系统是否能稳定运营：

1. BenchmarkJob
2. 指标采集与后台看板
3. 告警、补偿任务、失败重试
4. 门户与现有壳系统集成
5. 部署脚本与联调环境

### 5.3 P2：后续增强

这些部分提升效率、精度和可运营性：

1. 更复杂的 PricingEngine 策略
2. 排名、画像、推荐
3. 更细粒度的运营配置中心
4. 压测、混沌演练、容量规划

### 5.4 问题目录驱动的刚性要求

根据 `技术规划\问题` 下的文档，以下能力不再是“建议”，而是第一批实现必须落地的刚性要求：

1. `Auth & Access` 必须实现 `access_token + refresh_token` 双 token 机制，支持自动刷新、撤销和轮换。
2. 所有关键写路径必须具备并发控制：
   - listing 租用使用数据库行锁
   - 关键表使用 `version` 乐观锁
   - 下单接口支持 `idempotency_key`
3. 钱包相关操作必须统一经过钱包服务，冻结、解冻、扣减、退款全部写交易流水，且与订单主流程保持事务一致性。
4. 卖家节点接入必须补齐：
   - `swarm_node_id` 唯一约束
   - 重复注册幂等返回
   - `register-self` 重试
   - 硬件信息服务端校验
5. 市场模块必须补齐：
   - 30 分钟价格过期阈值
   - 提前 5 分钟刷新
   - cursor 分页
   - listing 详情 `version` 与实时状态接口
6. 订单与部署模块必须补齐：
   - 冻结余额、创建订单、创建部署记录同事务
   - 部署失败立即退款
   - 到期时间从真正 `running` 开始计算
   - 连接前实时校验运行容器状态
7. Benchmark 模块必须补齐：
   - 压缩包安全解压
   - 分阶段超时
   - 依赖缓存
   - 结果卷挂载持久化
   - 容器资源与权限隔离
8. Runtime Reconcile 必须补齐：
   - 事件幂等
   - 最佳努力清理
   - 最大重试次数
   - 超阈值转人工处理，防止循环依赖
9. Admin Dashboard 必须补齐：
   - 统一快照或统一快照时间戳
   - 限流或批量加载
   - admin 路由统一鉴权
   - 节点详情字段白名单
   - `time_window <= 90d`

同时应明确区分两类事项：

- 比赛 MVP 内必须做：上面 1-9 项
- 上线前安全加固必须补：bootstrap token 明文传输规避、git 白名单/SSRF 防护、连接 URL 访问次数/绑定控制、参数化查询与注入防护

---

## 6. 总体测试策略

每一部分都必须同步设计测试，不允许“代码先写完、测试后补”。

### 6.1 测试分层

- 单元测试
  - 验证纯函数、规则判断、状态迁移、数据转换
- 集成测试
  - 验证数据库、Redis、任务队列、外部适配器协作
- API/契约测试
  - 验证请求响应结构、错误码、幂等行为、权限边界
- 前端组件测试
  - 验证页面组件渲染、表单校验、状态切换
- 端到端测试
  - 验证从页面到后端到任务执行的完整业务链路
- 故障测试
  - 验证外部依赖失败、超时、重复回调、并发竞争

### 6.2 测试目录建议

```text
platform-backend/tests/
  unit/
  integration/
  api/

platform-worker/tests/
  unit/
  integration/

platform-frontend/src/__tests__/platform/
platform-frontend/tests/e2e/

tests/
  contracts/
  fixtures/
  smoke/
```

### 6.3 基本要求

- 每个新增模块必须至少有单元测试
- 每个核心业务 API 必须有 API 测试
- 每个状态机必须有状态迁移测试
- 每个异步任务必须有成功、失败、重试三类测试
- 每个用户关键路径必须有 E2E 测试
- CI 中至少执行：
  - 后端单元测试
  - 后端 API 测试
  - 前端单元测试
  - 一组最小 smoke E2E

---

## 7. 分阶段实施计划

## 阶段 0：新平台工程骨架

- 优先级：P0
- 目标：
  - 建立独立的平台主工程结构
  - 明确后端、worker、benchmark、infra 边界
  - 明确独立新前端与新后端的契约边界
  - 不在旧 Spring Boot 通用模板中硬塞业务逻辑
- 代码位置：
  - `Pivot_Computing_Power_Network/platform-backend`
  - `Pivot_Computing_Power_Network/platform-worker`
  - `Pivot_Computing_Power_Network/platform-frontend`
  - `Pivot_Computing_Power_Network/platform-benchmark`
  - `Pivot_Computing_Power_Network/infra`
- 具体执行：
  1. 初始化 FastAPI 项目结构
  2. 初始化 `platform-frontend` 业务目录、路由模块、API 模块与测试目录
  3. 初始化 Celery worker 结构
  4. 建立统一配置加载方式（dev/test/prod）
  5. 建立日志、环境变量、代码风格、CI 基础脚手架
- 达成要求：
  - 所有服务可本地启动
  - 配置项清晰且环境隔离
  - 项目具备最小测试和 lint 入口
- 测试方法：
  - 后端 smoke：启动 FastAPI，验证 `/health` 返回 200
  - Worker smoke：启动 Celery，验证 worker 注册成功
  - 前端 smoke：本地构建与启动通过
  - 配置测试：不同环境配置能正确加载
- 测试代码位置：
  - `platform-backend/tests/smoke/test_health.py`
  - `platform-worker/tests/smoke/test_worker_boot.py`
  - `platform-frontend/tests/e2e/platform-smoke.spec.ts`

## 阶段 1：数据库模型与迁移体系

- 优先级：P0
- 目标：
  - 按技术规划落地第一批核心表结构
  - 建立可重复执行的迁移机制
- 首批表建议：
  - `user`
  - `compute_node`
  - `node_rental_listing`
  - `rental_order`
  - `deployment`
  - `runtime_event`
  - `metric_snapshot`
  - `benchmark_job`
- 代码位置：
  - `platform-backend/app/models/`
  - `platform-backend/alembic/`
  - `platform-backend/app/repositories/`
- 具体执行：
  1. 根据技术规划梳理字段、索引、唯一约束、状态枚举
  2. 使用 SQLAlchemy 定义模型
  3. 使用 Alembic 生成迁移
  4. 建立初始化种子数据
  5. 明确审计字段与软删除策略
- 达成要求：
  - 数据模型命名统一
  - 索引覆盖主查询路径
  - 所有枚举字段有明确含义与迁移说明
- 测试方法：
  - 迁移测试：从空库升级到最新版本成功
  - 回滚测试：关键迁移可回退
  - Repository 测试：增删改查与唯一约束生效
  - 数据完整性测试：外键、索引、状态默认值正确
- 测试代码位置：
  - `platform-backend/tests/integration/test_migrations.py`
  - `platform-backend/tests/integration/test_repositories_*.py`

## 阶段 2：后端基础设施

- 优先级：P0
- 目标：
  - 统一 API 规范、错误码、trace_id、日志、鉴权中间件
- 代码位置：
  - `platform-backend/app/core/`
  - `platform-backend/app/middlewares/`
  - `platform-backend/app/schemas/common.py`
- 具体执行：
  1. 定义统一响应格式
  2. 定义错误码枚举与异常映射
  3. 接入 trace_id、请求日志、审计日志
  4. 统一权限注解与用户上下文
  5. 建立幂等键支持框架
- 达成要求：
  - 所有 API 使用统一错误响应
  - 请求能全链路追踪
  - 关键写操作支持幂等设计
- 测试方法：
  - API 契约测试：响应体结构、错误码结构统一
  - 中间件测试：trace_id 自动注入
  - 鉴权测试：未登录、越权、过期 token 的错误行为正确
  - 幂等测试：重复请求不会生成重复业务数据
- 测试代码位置：
  - `platform-backend/tests/api/test_common_response.py`
  - `platform-backend/tests/api/test_auth_middleware.py`
  - `tests/contracts/api_error_contract.json`

## 阶段 3：认证、用户、角色与权限

- 优先级：P0
- 目标：
  - 支撑平台用户、节点主、管理员的角色隔离
- 代码位置：
  - `platform-backend/app/modules/auth/`
  - `platform-backend/app/modules/users/`
  - `platform-frontend/src/views/platform/modules/auth/`
- 具体执行：
  1. 明确角色模型和权限点
  2. 登录、登出、刷新 token、个人信息接口
  3. 管理端用户与角色管理页面
  4. 前端路由守卫与按钮权限控制
- 达成要求：
  - 用户身份与操作边界清晰
  - 后端和前端权限模型一致
- 测试方法：
  - 单元测试：权限判断函数
  - API 测试：登录、刷新、获取当前用户
  - 权限矩阵测试：不同角色访问不同接口
  - 前端测试：未登录跳转、越权按钮隐藏
- 测试代码位置：
  - `platform-backend/tests/unit/test_permission_rules.py`
  - `platform-backend/tests/api/test_auth_flow.py`
  - `platform-frontend/src/__tests__/platform/auth-guard.spec.js`

## 阶段 4：Swarm Adapter 契约与 Mock 实现

- 优先级：P0
- 目标：
  - 先做统一适配层与 mock，不直接把业务代码绑死在真实 Swarm API 上
- 代码位置：
  - `platform-backend/app/integrations/swarm/`
  - `platform-worker/app/integrations/swarm/`
- 具体执行：
  1. 定义 create/remove/inspect/list/logs 等接口契约
  2. 提供 mock adapter
  3. 定义真实 adapter 的入参与返回结构
  4. 统一异常映射、超时与重试策略
- 达成要求：
  - 业务代码依赖抽象接口，不依赖具体实现
  - 本地开发可不接真实 Swarm
- 测试方法：
  - 契约测试：mock 与 real adapter 返回结构一致
  - 超时测试：外部调用超时后异常正确转换
  - 重试测试：可重试错误重试次数符合配置
  - 故障测试：Swarm 不可达时业务返回预期错误码
- 测试代码位置：
  - `platform-backend/tests/contracts/test_swarm_adapter_contract.py`
  - `platform-worker/tests/integration/test_swarm_retry.py`

## 阶段 5：节点接入与节点状态管理

- 优先级：P0
- 目标：
  - 实现节点注册、审核、上下线、心跳、资源状态同步
- 代码位置：
  - `platform-backend/app/modules/compute_nodes/`
  - `platform-frontend/src/views/platform/modules/compute-nodes/`
- 具体执行：
  1. 设计节点接入 API
  2. 落地节点状态机
  3. 实现节点详情、列表、审核、上下线接口
  4. 前端节点管理页面
  5. 记录节点事件流
- 达成要求：
  - 节点可从接入走到可租用状态
  - 状态流转可审计
  - 状态异常可识别
- 测试方法：
  - 单元测试：节点状态机迁移
  - API 测试：注册、审核、上线、下线、心跳
  - 集成测试：节点心跳更新数据库状态
  - 并发测试：重复心跳、重复上线请求不导致脏状态
- 测试代码位置：
  - `platform-backend/tests/unit/test_compute_node_state_machine.py`
  - `platform-backend/tests/api/test_compute_node_api.py`
  - `platform-backend/tests/integration/test_compute_node_heartbeat.py`

## 阶段 6：商品发布与 PricingEngine

- 优先级：P0
- 目标：
  - 实现节点转商品、商品发布、基础价格计算
- 代码位置：
  - `platform-backend/app/modules/listings/`
  - `platform-backend/app/modules/pricing/`
  - `platform-frontend/src/views/platform/modules/listings/`
- 具体执行：
  1. 定义 listing 模型与状态
  2. 实现发布、下架、查询、筛选
  3. 先实现基础定价规则
  4. 保留复杂动态定价扩展点
- 达成要求：
  - 商品查询结果与节点可用状态一致
  - 基础价格计算稳定可解释
- 测试方法：
  - 单元测试：定价规则函数
  - API 测试：发布、下架、查询、筛选
  - 集成测试：节点状态变化时 listing 状态联动
  - 边界测试：价格上下限、非法输入、重复发布
- 测试代码位置：
  - `platform-backend/tests/unit/test_pricing_engine.py`
  - `platform-backend/tests/api/test_listing_api.py`
  - `platform-backend/tests/integration/test_listing_sync.py`

## 阶段 7：订单、部署与资源生命周期

- 优先级：P0
- 目标：
  - 形成交易主链路：下单、占用、部署、运行、释放
- 代码位置：
  - `platform-backend/app/modules/orders/`
  - `platform-backend/app/modules/deployments/`
  - `platform-worker/app/tasks/orders/`
  - `platform-frontend/src/views/platform/modules/orders/`
- 具体执行：
  1. 定义订单状态机与部署状态机
  2. 实现下单与资源锁定
  3. 实现部署任务下发与轮询
  4. 实现取消、到期释放、失败回滚
  5. 前端完成订单流程页面
- 达成要求：
  - 订单状态流转可回溯
  - 部署失败时资源可回滚
  - 同一资源不会被双重占用
- 测试方法：
  - 单元测试：订单状态机、部署状态机
  - 集成测试：订单创建后资源锁定成功
  - API 测试：下单、取消、查询详情、查询状态
  - Worker 测试：部署任务成功、失败、重试、回滚
  - 并发测试：同一 listing 并发下单只能成功一个
  - E2E 测试：用户从商品页下单到看到部署结果
- 测试代码位置：
  - `platform-backend/tests/unit/test_order_state_machine.py`
  - `platform-backend/tests/integration/test_order_locking.py`
  - `platform-backend/tests/api/test_order_api.py`
  - `platform-worker/tests/integration/test_deployment_tasks.py`
  - `platform-frontend/tests/e2e/platform-order-flow.spec.ts`

## 阶段 8：BenchmarkJob

- 优先级：P1
- 目标：
  - 对节点或商品进行基准测试，支撑展示与定价依据
- 代码位置：
  - `platform-backend/app/modules/benchmark/`
  - `platform-worker/app/tasks/benchmark/`
  - `platform-benchmark/`
- 具体执行：
  1. 定义 benchmark job 生命周期
  2. 先实现 mock benchmark 结果
  3. 再接真实 benchmark 执行脚本
  4. 保存原始结果、解析结果、摘要结果
- 达成要求：
  - benchmark 可重试、可终止、可追踪
  - 结果结构统一，可供页面展示与价格计算使用
- 测试方法：
  - 单元测试：结果解析器
  - 集成测试：job 创建到结果回写
  - 契约测试：benchmark 输出 JSON 结构符合规范
  - 故障测试：执行超时、结果为空、解析失败
- 测试代码位置：
  - `platform-backend/tests/unit/test_benchmark_parser.py`
  - `platform-worker/tests/integration/test_benchmark_job_flow.py`
  - `tests/contracts/benchmark_result.schema.json`

## 阶段 9：运行态对账 Runtime Reconcile

- 优先级：P0
- 目标：
  - 解决数据库状态与真实容器状态不一致问题
- 代码位置：
  - `platform-worker/app/tasks/reconcile/`
  - `platform-backend/app/modules/runtime_events/`
- 具体执行：
  1. 周期扫描 deployment 与 runtime 状态
  2. 对比 Swarm 实际状态与数据库状态
  3. 落地事件、修正状态、触发告警
  4. 建立人工处理入口
- 达成要求：
  - 运行态偏差可检测
  - 可自动修正常见异常
  - 高风险异常可告警并保留审计
- 测试方法：
  - 单元测试：状态对账规则
  - 集成测试：模拟数据库状态与 Swarm 状态不一致
  - Worker 测试：自动修正路径与告警路径
  - 故障测试：Swarm 返回空、延迟、部分丢失
- 测试代码位置：
  - `platform-worker/tests/unit/test_reconcile_rules.py`
  - `platform-worker/tests/integration/test_reconcile_flow.py`

## 阶段 10：指标采集与管理后台

- 优先级：P1
- 目标：
  - 管理员能看到节点、订单、部署、异常与资源情况
- 代码位置：
  - `platform-worker/app/tasks/metrics/`
  - `platform-backend/app/modules/admin_dashboard/`
  - `platform-frontend/src/views/platform/modules/admin-dashboard/`
- 具体执行：
  1. 设计指标快照与聚合接口
  2. 实现定时采集与入库
  3. 实现后台看板和筛选能力
  4. 加入告警视图和异常列表
- 达成要求：
  - 指标能按时间、节点、订单维度查询
  - 看板可直接支撑日常运维
- 测试方法：
  - 单元测试：指标聚合计算
  - 集成测试：采集任务入库与查询一致
  - API 测试：看板接口分页、筛选、时间范围
  - 前端测试：图表筛选切换与异常展示
- 测试代码位置：
  - `platform-worker/tests/unit/test_metric_aggregator.py`
  - `platform-backend/tests/api/test_admin_dashboard_api.py`
  - `platform-frontend/src/__tests__/platform/admin-dashboard.spec.js`

## 阶段 11：用户端门户与系统页面

- 优先级：P0
- 目标：
  - 用户能完成浏览商品、下单、查看部署、管理节点等核心操作
- 首批页面建议：
  - 登录页
  - 首页/商品列表页
  - 商品详情页
  - 下单页
  - 我的订单页
  - 订单详情页
  - 我的节点页
  - 节点详情页
  - 管理员节点审核页
  - 管理员订单/部署监控页
- 代码位置：
  - `platform-frontend/src/views/platform/`
  - `platform-frontend/src/views/platform/modules/`
- 具体执行：
  1. 先完成最小闭环页面
  2. 页面状态与后端接口对齐
  3. 接入统一错误提示、重试、空状态
  4. 再与现有门户入口集成
- 达成要求：
  - P0 页面可支撑交易主链路
  - 页面权限、状态、异常提示完整
- 测试方法：
  - 组件测试：表单校验、状态展示、按钮行为
  - 页面测试：列表筛选、详情展示、错误提示
  - E2E 测试：登录、浏览商品、下单、查看部署
  - 可用性测试：移动端基本适配、常用分辨率显示正常
- 测试代码位置：
  - `platform-frontend/src/__tests__/platform/listing-page.spec.js`
  - `platform-frontend/src/__tests__/platform/order-detail.spec.js`
  - `platform-frontend/tests/e2e/platform-user-core-flow.spec.ts`

## 阶段 12：联调、部署与 CI/CD

- 优先级：P1
- 目标：
  - 形成可持续交付能力，支持本地、测试、预发布环境
- 代码位置：
  - `infra/docker/`
  - `infra/nginx/`
  - `platform-bootstrap/`
  - `.github/workflows/` 或对应 CI 配置目录
- 具体执行：
  1. 编写 docker compose / 启动脚本
  2. 定义环境变量模板
  3. 接入 CI：lint、test、build
  4. 建立 smoke 发布验证流程
  5. 与现有 nginx / 门户代理做集成
- 达成要求：
  - 一键拉起开发环境
  - 合并前可自动完成关键测试
  - 部署过程可重复
- 测试方法：
  - CI 测试：自动执行后端、前端、worker 关键测试
  - 部署 smoke：环境拉起后执行健康检查
  - 回归测试：核心 API 与核心页面回归
  - 配置测试：dev/test/prod 配置完整性校验
- 测试代码位置：
  - `tests/smoke/test_environment_boot.py`
  - `platform-bootstrap/checks/`

---

## 8. 推荐开发顺序

必须严格按下面顺序推进：

1. 阶段 0：工程骨架
2. 阶段 1：数据库与迁移
3. 阶段 2：后端基础设施
4. 阶段 3：认证与权限
5. 阶段 4：Swarm Adapter Mock
6. 阶段 5：节点接入
7. 阶段 6：商品发布与基础定价
8. 阶段 7：订单与部署主链路
9. 阶段 9：运行态对账
10. 阶段 11：最小闭环前端页面
11. 阶段 8：BenchmarkJob
12. 阶段 10：指标与管理后台
13. 阶段 12：联调部署与 CI/CD

原因如下：

- 订单与部署是商业闭环核心，必须优先于花哨功能
- Runtime Reconcile 是平台可运营的底线，不能放到最后
- Benchmark 和后台看板虽然重要，但不应阻塞交易闭环

---

## 9. 里程碑验收标准

### 里程碑 M1：工程可启动

- 前后端、worker 可本地启动
- 数据库迁移可执行
- 测试框架已接入

### 里程碑 M2：节点可接入、商品可发布

- 节点可注册、审核、上线
- 商品可发布、下架、查询
- 基础定价可用

### 里程碑 M3：交易闭环跑通

- 用户可下单
- 资源可锁定
- 部署可创建
- 订单失败可回滚

### 里程碑 M4：运行态稳定

- 对账任务可发现异常
- 常见偏差可自动修复
- 管理员可查看异常

### 里程碑 M5：具备上线条件

- 基准测试、指标看板、告警补齐
- 端到端测试覆盖核心路径
- 部署流程可重复执行

### 9.1 里程碑检查点机制

从现在开始，每次形成一个里程碑验收结果时，都必须建立一个检查点文件夹，用于固化该阶段的实现结果。

这里的“验收结果”包括：

- 里程碑通过
- 里程碑未通过但已形成阶段性可复盘结果

建议统一在仓库根目录下建立：

- `../checkpoints/`

每个里程碑结果建立一个子文件夹，命名建议为：

- `M1_pass_20260320_191516`
- `M2_fail_20260321_103000`

即：

- 里程碑编号
- 验收结果 `pass/fail`
- 时间戳 `yyyyMMdd_HHmmss`

### 9.2 检查点文件夹结构

建议每个检查点目录固定为：

```text
checkpoints/
  M1_pass_20260320_191516/
    CHANGE.md
    code_snapshot/
      platform-backend/...
      platform-worker/...
      platform-frontend/...
    test_logs/
```

要求：

- `CHANGE.md`
  - 必须记录该阶段改了什么代码、对应什么功能、修改前是什么样、修改后变成什么样
- `code_snapshot/`
  - 必须保存该阶段改进后的代码副本
  - 建议只拷贝本阶段改动过的文件，并保持相对路径结构
- `test_logs/`
  - 建议同步放入该阶段验收测试日志，便于复盘

### 9.3 CHANGE.md 必填内容

每个检查点目录下的 `CHANGE.md` 至少要包含：

```md
# CHANGE

## 1. 阶段信息
- 里程碑：
- 验收结果：
- 验收时间：
- 对应分支/提交：

## 2. 本阶段实现的功能
- 功能 1：
- 功能 2：

## 3. 代码变更清单
| 文件路径 | 对应功能 | 修改前是什么样 | 修改后是什么样 |
|---|---|---|---|
| `platform-backend/app/...` | 例如：节点接入 | 例如：只有占位接口 | 例如：接入会话与 register-self 已打通 |

## 4. 测试与验收
- 运行了哪些测试：
- 测试结果：
- 已知问题：

## 5. 备注
- 需要后续继续推进的事项：
```

其中“修改前是什么样”不能只写“旧代码”，而应写出可复盘的状态，例如：

- 没有这个文件
- 只有空占位接口
- 只有 mock 返回
- 只有页面骨架，没有联调
- 旧接口路径与新契约不一致

### 9.4 建议执行命令

以下命令建议在每个里程碑验收结束后执行一次。

#### 1. 创建检查点目录

```powershell
$CheckpointRoot = "..\\checkpoints"
$Milestone = "M1"
$Result = "pass"
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$CheckpointDir = Join-Path $CheckpointRoot "${Milestone}_${Result}_${Timestamp}"

New-Item -ItemType Directory -Force -Path $CheckpointDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $CheckpointDir "code_snapshot") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $CheckpointDir "test_logs") | Out-Null
New-Item -ItemType File -Force -Path (Join-Path $CheckpointDir "CHANGE.md") | Out-Null
```

#### 2. 拷贝本阶段修改后的代码

推荐做法是维护一个“本阶段改动文件清单”，然后按相对路径复制到 `code_snapshot/`。

```powershell
$ProjectRoot = "..\\Pivot_Computing_Power_Network"
$SnapshotRoot = Join-Path $CheckpointDir "code_snapshot"

$ChangedFiles = @(
  "platform-backend/app/main.py",
  "platform-backend/app/api/router.py",
  "platform-frontend/src/router/modules/platform.js"
)

foreach ($RelativePath in $ChangedFiles) {
  $SourcePath = Join-Path $ProjectRoot $RelativePath
  $TargetPath = Join-Path $SnapshotRoot $RelativePath
  New-Item -ItemType Directory -Force -Path (Split-Path $TargetPath) | Out-Null
  Copy-Item -Path $SourcePath -Destination $TargetPath -Force
}
```

#### 3. 拷贝本阶段测试日志

```powershell
$TestLogSource = "..\\test_log"
$TestLogTarget = Join-Path $CheckpointDir "test_logs"

Copy-Item -Path (Join-Path $TestLogSource "*") -Destination $TestLogTarget -Recurse -Force
```

#### 4. 建议辅助命令：导出本阶段改动文件清单

如果当前阶段的改动已经进入 git 管理，建议用下面的命令辅助生成改动文件列表：

```powershell
git diff --name-only > (Join-Path $CheckpointDir "changed_files.txt")
```

### 9.5 执行要求

后续实施时必须遵守：

1. 每个里程碑验收结果都要建立一个对应检查点目录，不能只在最终阶段留档。
2. 每个检查点都必须有 `CHANGE.md`，且必须写清楚“改了什么、对应什么功能、修改前是什么样、修改后是什么样”。
3. 每个检查点都必须保存该阶段改进后的代码副本，不能只留文字说明。
4. 如果里程碑验收失败，也应保留失败检查点，便于下一阶段回滚、比较和复盘。
5. 后续如需继续增强，可以在新检查点中引用上一检查点，而不是覆盖旧检查点。

---

## 10. 测试覆盖要求

建议最低覆盖标准如下：

- 后端核心域服务单元测试覆盖率不低于 80%
- 状态机相关代码覆盖率不低于 90%
- 核心 API 全部具备契约测试
- 订单主链路、节点主链路、部署主链路全部具备 E2E
- 所有 P0 缺陷修复必须补回归测试

### 10.1 每次提交前至少执行

- 后端单元测试
- 后端 API 测试
- 前端单元测试
- 订单主链路 smoke E2E

### 10.2 每次里程碑前必须执行

- 完整集成测试
- 关键失败场景测试
- 基本并发测试
- 部署 smoke 验证

### 10.3 Bug 回归矩阵

以下回归测试必须进入长期测试集合：

- `Bug-00-01`：token 即将过期自动刷新、401 自动重试、refresh token 轮换
- `Bug-00-03`：listing 并发写入、钱包并发写入、乐观锁冲突
- `Bug-00-06`：冻结、解冻、退款、扣减后的钱包一致性
- `Bug-01-01/01-03`：节点加入延迟重试、重复注册幂等、跨卖家抢注拒绝
- `Bug-02-01/02-03/02-04`：价格过期标记、cursor 分页一致性、详情页状态并发变化
- `Bug-03-02/03-03/03-04/03-05/03-06`：事务原子性、部署失败退款、并发超售、幂等下单、实际到期时间
- `Bug-04-01/04-03/04-04/04-06`：连接 URL 去重、连接前实时校验、SSE/推送替代高频轮询、剩余秒数倒计时
- `Bug-05-01/05-03/05-05/05-07`：安全解压、阶段超时、容器隔离、结果文件持久化
- `Bug-07-01/07-02/07-03/07-05/07-07`：快照一致性、请求雪崩、管理员权限保护、前端定时器清理、空数据与错误态区分

---

## 11. 不建议做的事情

- 不要把核心算力交易逻辑继续堆进旧 Spring Boot 通用管理模板
- 不要在没有状态机测试的前提下实现订单与部署流程
- 不要先接真实 Swarm 再设计 adapter 抽象
- 不要先做复杂运营大屏，再做交易主链路
- 不要只做接口联调，不做失败场景和并发场景测试

---

## 12. 问题目录修订要求

基于 `技术规划\问题` 的最新文档，后续所有实现和测试必须遵守以下执行原则：

1. 每个 P0 bug 必须在对应模块编码前先落实设计和测试用例骨架。
2. 每个已知 bug 修复都必须配一条回归测试，禁止只改业务逻辑不补测试。
3. 前端轮询类逻辑默认要考虑：
   - 超时
   - 手动刷新
   - 清理定时器
   - 多标签页压力
4. 后端所有跨模块写操作默认要考虑：
   - 事务边界
   - 幂等
   - 并发冲突
   - 失败补偿
5. 所有“状态展示”页面默认都要考虑状态滞后问题，关键动作前做实时二次校验。

## 13. 下一步执行建议

如果按工程落地顺序推进，下一步应直接开始：

1. 创建 `platform-backend`、`platform-worker`、`platform-benchmark`、`platform-frontend` 基础目录
2. 初始化 FastAPI、Celery，并在独立新前端内补平台页面骨架与测试骨架
3. 建立 Alembic、pytest、Vitest、Playwright、CI 最小框架
4. 先写阶段 0 和阶段 1 的测试骨架，再开始业务实现

这一步完成后，再进入节点、商品、订单三大核心域开发。
