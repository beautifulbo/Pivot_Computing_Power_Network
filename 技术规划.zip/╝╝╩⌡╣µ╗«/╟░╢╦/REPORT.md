# 虚拟前端后端契约报告

版本：V1.0  
日期：2026-03-21

## 1. 文档定位

`技术规划/前端` 下除 `PLAN.md` 外的文档，并不是在描述当前仓库里已经存在的真实前端代码，而是在先“虚构”一套完整平台前端，借此固定：

- 这个平台前端一共有多少页面
- 每个页面要做什么
- 页面之间如何跳转
- 页面依赖哪些后端接口
- 页面最少需要后端返回哪些信息
- 页面在什么状态下轮询、降级、报错、跳系统页

本报告的目标，是把这套“虚拟前端”翻译成一份可供后端直接编码使用的契约说明。

换句话说，本报告不是面向前端 UI 开发，而是面向后端、任务服务、接口设计、错误码设计、状态字段设计和测试设计。

---

## 2. 虚拟前端总览

## 2.1 页面与角色

该虚拟前端是一个统一 Web 应用，服务 3 类身份：

- 游客
- 普通用户
  - 可同时拥有 `buyer` 和 `seller` 两种能力
- 管理员

页面总数固定为 17 个：

- 13 个业务页面
- 4 个系统页面

区域固定为 5 个：

- `Public Area`
- `Market Area`
- `Benchmark Area`
- `Seller Area`
- `Admin Area`

## 2.2 页面集合

| 页面 | 角色 | 区域 | 核心作用 |
|---|---|---|---|
| `PortalPage` | 全部 | Public | 平台统一入口、角色入口、概况卡 |
| `AuthPage` | 全部 | Public | 注册、登录、登出、能力识别 |
| `MarketListPage` | 游客/买家 | Market | 市场浏览、筛选、排序、搜索 |
| `ListingDetailPage` | 买家 | Market | 查看 `NodeRentalListing` 详情并下单 |
| `BenchmarkSubmitPage` | 买家 | Benchmark | 创建 `BenchmarkJob` |
| `BenchmarkResultPage` | 买家 | Benchmark | 查看测算阶段、失败原因、推荐 listing |
| `RentalOrderListPage` | 买家 | Market | 查看自己名下全部实例 |
| `RentalOrderDetailPage` | 买家 | Market | 查看运行态、网页连接、释放动作 |
| `SellerWorkbenchPage` | 卖家 | Seller | 节点与 listing 概况入口 |
| `ComputeNodeAccessGuidePage` | 卖家 | Seller | 节点接入说明与 FAQ |
| `ComputeNodeBootstrapPage` | 卖家 | Seller | 生成 bootstrap 命令并轮询接入状态 |
| `ListingManagePage` | 卖家 | Seller | 管理自动生成的 listing |
| `AdminDashboardPage` | 管理员 | Admin | 单页多区块管理大盘 |
| `NoPermissionPage` | 全部 | System | 403/无权限兜底 |
| `NotFoundPage` | 全部 | System | 404/路由不存在兜底 |
| `ServiceErrorPage` | 全部 | System | 页面级服务异常兜底 |
| `MaintenancePage` | 全部 | System | 平台维护态兜底 |

## 2.3 核心跳转关系

后端在设计接口和权限时，需要默认前端会按下面这条关系链组织页面：

- `PortalPage -> AuthPage`
- `PortalPage -> MarketListPage`
- `MarketListPage -> ListingDetailPage`
- `ListingDetailPage -> RentalOrderDetailPage`
- `PortalPage -> BenchmarkSubmitPage`
- `BenchmarkSubmitPage -> BenchmarkResultPage`
- `BenchmarkResultPage -> ListingDetailPage`
- `PortalPage -> RentalOrderListPage`
- `RentalOrderListPage -> RentalOrderDetailPage`
- `PortalPage -> SellerWorkbenchPage`
- `SellerWorkbenchPage -> ComputeNodeAccessGuidePage`
- `SellerWorkbenchPage -> ComputeNodeBootstrapPage`
- `SellerWorkbenchPage -> ListingManagePage`
- `PortalPage -> AdminDashboardPage`

因此后端不能把系统设计成只有一条线性流程，而必须支撑：

- 从任意页面进入详情页
- 从详情页反向查看最新状态
- 多条入口同时访问同一资源
- 同一资源在不同页面下以不同粒度被读取

## 2.4 后端必须默认承担的事实源

根据页面文档和业务流程文档，以下状态全部以后端为准，前端只负责展示：

- `NodeRentalListing.rentable_status`
- `NodeRentalListing.publish_status`
- 平台价格与价格是否过期
- `RentalOrder.order_status`
- `Deployment.runtime_status`
- `Deployment.web_entry_status`
- `BenchmarkJob.job_status`
- `ComputeNode` 在线/离线与最近同步状态
- 异常事件是否已收敛
- 网页连接是否可申请、申请后返回什么模式的连接

---

## 3. 后端必须理解的全局页面规则

## 3.1 统一权限模型

前端至少需要以下能力判断：

- 未登录
- 已登录但仅普通用户
- 已登录且具备 `buyer` 能力
- 已登录且具备 `seller` 能力
- 已登录且具备 `admin` 能力

因此后端至少要能稳定提供：

- 当前用户信息
- 当前用户能力集合
- 403 无权限返回
- 401 未认证返回

## 3.2 统一页面状态模型

几乎所有业务页面都要求后端支撑前端区分以下状态：

- `loading`
- `empty`
- `partial_error`
- `page_error`
- `permission_error`
- `maintenance`

这意味着后端返回不能只满足“有没有数据”，还要满足：

- 是接口失败还是空结果
- 是局部区块失败还是整页不可用
- 是权限问题还是服务问题
- 是非预期 5xx 还是受控维护态

## 3.3 系统页触发规则

后端和网关至少要支持前端触发以下系统页：

| 页面 | 触发来源 | 后端要求 |
|---|---|---|
| `NoPermissionPage` | 路由无权限，或接口返回 403 | 必须稳定返回权限错误，而不是伪装成 404/500 |
| `NotFoundPage` | 路由不存在 | 主要由前端路由承担；后端无专属接口要求 |
| `ServiceErrorPage` | 关键页面请求失败且无法局部降级 | 必须能区分页面级致命失败和局部可降级失败 |
| `MaintenancePage` | 平台受控维护 | 最好有统一维护态信号或维护接口 |

## 3.4 统一轮询与刷新约束

虚拟前端强依赖以下轮询行为：

| 页面 | 轮询对象 | 条件 | 周期 |
|---|---|---|---|
| `ComputeNodeBootstrapPage` | bootstrap session | session 未结束 | 5-10 秒 |
| `BenchmarkResultPage` | benchmark job | job 未结束 | 文档未冻结，建议 5-10 秒 |
| `RentalOrderListPage` | order list | 存在 `pending_deploy/running/releasing` 记录 | 30 秒 |
| `RentalOrderDetailPage` | deployment | `starting/stopping` | 10 秒 |
| `RentalOrderDetailPage` | order + deployment | 存在开放异常事件 | 建议 10 秒 |
| `RentalOrderDetailPage` | order + deployment | 已触发释放但未 `released` | 建议 10 秒 |
| `AdminDashboardPage` | widgets | 停留页面中 | 高频区块 10-30 秒，低频区块更长 |

这会直接影响后端的：

- 读接口幂等性
- 快照缓存策略
- 限流设计
- 轮询条件字段设计
- “状态变化是否足够细”这个问题

---

## 4. 页面级功能与后端依赖总表

| 页面 | 前端要做的事 | 后端必须提供的能力 |
|---|---|---|
| `PortalPage` | 导航到市场、Benchmark、卖家中心、管理员大盘；可选展示概况卡 | 可选公开摘要接口；能力判断后决定入口跳转 |
| `AuthPage` | 注册、登录、读用户信息、读能力、登出 | 认证接口、会话管理、能力查询 |
| `MarketListPage` | 首屏列表、筛选、排序、搜索、翻页 | 市场列表接口、筛选器接口、稳定分页和排序 |
| `ListingDetailPage` | 展示详情、填写参数、下单、失败后回刷 | listing 详情、下单接口、实时状态重查 |
| `BenchmarkSubmitPage` | 二选一提交测算输入并创建 job | 压缩包上传接口、benchmark 创建接口 |
| `BenchmarkResultPage` | 轮询 job、展示结果、读推荐列表 | job 状态接口、推荐结果接口 |
| `RentalOrderListPage` | 查看实例列表、筛选、运行态轮询 | 订单列表接口，带运行态和网页入口状态 |
| `RentalOrderDetailPage` | 查看订单与部署、申请网页连接、释放、异常态轮询 | 订单详情、部署详情、web-connect、release |
| `SellerWorkbenchPage` | 看节点概况和 listing 概况 | 卖家 compute node 列表、卖家 listing 列表 |
| `ComputeNodeAccessGuidePage` | 查看接入说明、FAQ、开始接入 | 接入说明接口 |
| `ComputeNodeBootstrapPage` | 生成会话、复制命令、轮询接入结果、手动同步 | bootstrap session、register-self、session 查询、手动同步 |
| `ListingManagePage` | 查看 listing、编辑、下架、重新上架、查看关联节点 | 卖家 listing 列表/详情/更新/上下架、node 详情 |
| `AdminDashboardPage` | 单页多区块读平台全量快照 | 大盘接口组、节点详情接口、可轮询快照接口 |

---

## 5. 全量接口清单

本节按业务域汇总前端文档中已经出现的全部接口。  
其中标记为“待确认”的接口，是页面文档明确提到但尚未正式冻结的可选接口。

## 5.1 Public / Portal

| 方法 | 路径 | 页面 | 作用 | 状态 |
|---|---|---|---|---|
| `GET` | `/portal/summary` | `PortalPage` | 首页概况卡：在线节点数、运行中订单数、异常数等 | 待确认 |

## 5.2 Auth & Session

| 方法 | 路径 | 页面 | 作用 |
|---|---|---|---|
| `POST` | `/auth/register` | `AuthPage` | 注册普通用户 |
| `POST` | `/auth/login` | `AuthPage` | 登录 |
| `GET` | `/auth/me` | `AuthPage` | 获取当前用户 |
| `GET` | `/auth/capabilities` | `AuthPage` | 获取能力集合 |
| `POST` | `/auth/logout` | `AuthPage` | 退出登录 |

## 5.3 Market / Listings

| 方法 | 路径 | 页面 | 作用 |
|---|---|---|---|
| `GET` | `/market/listings/filters` | `MarketListPage` | 读取筛选器 |
| `GET` | `/market/listings` | `MarketListPage` | 读取市场列表 |
| `GET` | `/market/listings/{listing_id}` | `ListingDetailPage`、`BenchmarkResultPage` | 读取 listing 详情和最新可租状态 |

## 5.4 Rental Orders / Deployments

| 方法 | 路径 | 页面 | 作用 |
|---|---|---|---|
| `POST` | `/rental-orders` | `ListingDetailPage` | 创建订单并触发部署 |
| `GET` | `/rental-orders` | `RentalOrderListPage` | 列表页读取实例 |
| `GET` | `/rental-orders/{order_id}` | `ListingDetailPage`、`RentalOrderDetailPage` | 读取订单详情 |
| `GET` | `/rental-orders/{order_id}/deployment` | `ListingDetailPage`、`RentalOrderDetailPage` | 读取部署详情与运行态 |
| `POST` | `/rental-orders/{order_id}/web-connect` | `RentalOrderDetailPage` | 申请短时连接地址 |
| `POST` | `/rental-orders/{order_id}/release` | `RentalOrderDetailPage` | 主动释放实例 |

## 5.5 Benchmark

| 方法 | 路径 | 页面 | 作用 |
|---|---|---|---|
| `POST` | `/benchmark-jobs/code-archive-uploads` | `BenchmarkSubmitPage` | 上传 zip 并获取 `code_archive_token` |
| `POST` | `/benchmark-jobs` | `BenchmarkSubmitPage` | 创建 `BenchmarkJob` |
| `GET` | `/benchmark-jobs/{job_id}` | `BenchmarkResultPage` | 查询任务状态 |
| `GET` | `/benchmark-jobs/{job_id}/recommendations` | `BenchmarkResultPage` | 查询推荐结果 |

## 5.6 Seller / Compute Nodes

| 方法 | 路径 | 页面 | 作用 |
|---|---|---|---|
| `GET` | `/seller/compute-nodes` | `SellerWorkbenchPage` | 读取卖家节点列表或概况 |
| `GET` | `/seller/compute-nodes/access-guide` | `ComputeNodeAccessGuidePage` | 读取接入说明 |
| `POST` | `/seller/compute-nodes/bootstrap-sessions` | `ComputeNodeBootstrapPage` | 创建 bootstrap session |
| `POST` | `/seller/compute-nodes/register-self` | 本地 bootstrap 脚本 | 本地 worker 自注册 |
| `GET` | `/seller/compute-nodes/bootstrap-sessions/{session_id}` | `ComputeNodeBootstrapPage` | 查询 session 状态 |
| `POST` | `/seller/compute-nodes/{node_id}/sync` | `ComputeNodeBootstrapPage` | 手动重试同步 |
| `GET` | `/seller/compute-nodes/{node_id}` | `ListingManagePage` | 读取关联 node 详情 |

## 5.7 Seller / Listings

| 方法 | 路径 | 页面 | 作用 |
|---|---|---|---|
| `GET` | `/seller/listings` | `SellerWorkbenchPage`、`ListingManagePage` | 读取卖家 listing 列表 |
| `GET` | `/seller/listings/{listing_id}` | `ListingManagePage` | 读取 listing 详情 |
| `PATCH` | `/seller/listings/{listing_id}` | `ListingManagePage` | 更新标题、描述、镜像策略 |
| `POST` | `/seller/listings/{listing_id}/off-shelf` | `ListingManagePage` | 下架 |
| `POST` | `/seller/listings/{listing_id}/publish` | `ListingManagePage` | 重新上架 |

## 5.8 Admin Dashboard

### 5.8.1 顶部 KPI 与平台区

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/admin/dashboard/kpi-summary` | 顶部 KPI |
| `GET` | `/admin/dashboard/platform-health` | 平台健康 |
| `GET` | `/admin/dashboard/platform-load` | 平台负载 |
| `GET` | `/admin/dashboard/resource-capacity` | 资源容量 |
| `GET` | `/admin/dashboard/resource-utilization-trend` | 资源利用率趋势 |

### 5.8.2 节点监控区

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/admin/nodes/overview` | 节点总览 |
| `GET` | `/admin/nodes/status-distribution` | 状态分布 |
| `GET` | `/admin/nodes/load-matrix` | 节点负载矩阵 |
| `GET` | `/admin/nodes/top-cpu` | CPU Top 榜 |
| `GET` | `/admin/nodes/top-memory` | 内存 Top 榜 |
| `GET` | `/admin/nodes/top-gpu` | GPU Top 榜 |
| `GET` | `/admin/nodes/top-network-in` | 入流量 Top 榜 |
| `GET` | `/admin/nodes/top-network-out` | 出流量 Top 榜 |
| `GET` | `/admin/nodes/top-idle` | 空闲节点 Top 榜 |
| `GET` | `/admin/nodes/risk-ranking` | 风险节点排行 |
| `GET` | `/admin/nodes/heartbeat-latency` | 心跳延迟 |
| `GET` | `/admin/nodes/{node_id}/detail` | 节点详情抽屉 |

### 5.8.3 市场价格区

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/admin/market/overview` | 市场总览 |
| `GET` | `/admin/market/listing-status-distribution` | listing 状态分布 |
| `GET` | `/admin/market/gpu-distribution` | GPU 分布 |
| `GET` | `/admin/market/cpu-tier-distribution` | CPU 档位分布 |
| `GET` | `/admin/market/region-distribution` | 区域分布 |
| `GET` | `/admin/market/price-trend` | 价格趋势 |
| `GET` | `/admin/market/top-hot-listings` | 热门 listing |
| `GET` | `/admin/market/top-expensive-listings` | 高价 listing |
| `GET` | `/admin/market/top-cheap-listings` | 低价 listing |

### 5.8.4 订单部署区

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/admin/orders/overview` | 订单总览 |
| `GET` | `/admin/orders/status-distribution` | 订单状态分布 |
| `GET` | `/admin/orders/create-trend` | 创建趋势 |
| `GET` | `/admin/orders/release-type-distribution` | 释放类型分布 |
| `GET` | `/admin/orders/expiring-soon` | 即将到期列表 |
| `GET` | `/admin/orders/high-value` | 高价值订单 |
| `GET` | `/admin/deployments/overview` | 部署总览 |
| `GET` | `/admin/deployments/runtime-distribution` | 运行态分布 |
| `GET` | `/admin/deployments/web-entry-distribution` | 网页入口分布 |
| `GET` | `/admin/deployments/runtime-failure-top` | 运行失败排行 |

### 5.8.5 Benchmark 区

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/admin/benchmarks/overview` | Benchmark 总览 |
| `GET` | `/admin/benchmarks/status-distribution` | 状态分布 |
| `GET` | `/admin/benchmarks/mode-distribution` | 模式分布 |
| `GET` | `/admin/benchmarks/source-type-distribution` | 输入来源分布 |
| `GET` | `/admin/benchmarks/duration-trend` | 时长趋势 |
| `GET` | `/admin/benchmarks/failure-top` | 失败排行 |

### 5.8.6 风险区

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/admin/risk/overview` | 风险总览 |
| `GET` | `/admin/risk/runtime-events` | 异常事件流 |
| `GET` | `/admin/risk/severity-distribution` | 严重度分布 |
| `GET` | `/admin/risk/event-type-distribution` | 事件类型分布 |
| `GET` | `/admin/risk/refund-compensation-stats` | 退款补偿统计 |
| `GET` | `/admin/risk/risk-nodes` | 风险节点 |

### 5.8.7 审计区

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/admin/audit/timeline` | 时间线 |
| `GET` | `/admin/audit/action-type-distribution` | 动作类型分布 |
| `GET` | `/admin/audit/recent-admin-logins` | 最近管理员登录 |

## 5.9 System / Ops（待确认）

| 方法 | 路径 | 页面 | 作用 | 状态 |
|---|---|---|---|---|
| `GET` | `/maintenance-status` 或等价接口 | `MaintenancePage` | 检查平台是否处于维护态 | 待确认 |

---

## 6. 后端最少字段要求

本节不是数据库设计，而是“为了让虚拟前端能工作，后端响应至少要带哪些字段”。

其中带“推断”的字段，表示页面文档没有直接写字段名，但页面功能和展示目标已经隐含要求后端必须返回这类信息。

## 6.1 Auth 相关

### `POST /auth/login`

前端最少需要：

- `access_token`
- `refresh_token` 或等价可续期会话标识
- `token_type`
- `expires_in`

### `GET /auth/me`

前端最少需要：

- `user_id`
- `username`
- `display_name`
- `is_authenticated`

### `GET /auth/capabilities`

前端最少需要：

- `capabilities`
  - 至少包含 `buyer`、`seller`、`admin`

## 6.2 Portal 概况卡

若实现 `GET /portal/summary`，最少需要：

- `online_compute_node_count`
- `running_order_count`
- `open_runtime_event_count`
- `generated_at`

## 6.3 Market List

### `GET /market/listings/filters`

最少需要：

- `gpu_options`
- `region_options`
- `price_range`
- `rentable_status_options`
- `sort_options`

### `GET /market/listings`

每条 listing 卡片最少需要：

- `listing_id`
- `title`
- `summary`
- `hardware_summary`
- `region_code`
- `current_price_hourly`
- `rentable_status`
- `publish_status`
- `updated_at`

列表级最少需要：

- `items`
- `next_cursor` 或分页信息
- `applied_filters`

## 6.4 Listing Detail

### `GET /market/listings/{listing_id}`

最少需要：

- `listing_id`
- `title`
- `summary`
- `description`
- `hardware_summary`
- `current_price_hourly`
- `price_stale`
- `publish_status`
- `rentable_status`
- `node_status_summary`
- `image_policy`
- `min_duration_minutes`
- `max_duration_minutes`
- `version`

页面填写表单时隐含还需要：

- 是否允许自定义镜像
- 是否允许环境变量
- 是否允许端口暴露
- 默认推荐租期或租期范围

这些字段名称文档未冻结，但后端必须留出表达能力。

## 6.5 Rental Order Create

### `POST /rental-orders`

请求体最少需要能表达：

- `listing_id`
- `duration_minutes`
- `image_source` 或等价镜像输入
- `command`
- `env_vars`
- `exposed_ports`
- `idempotency_key`

成功响应最少需要：

- `order_id`
- `order_status`
- `deployment_status` 或可用于跳转后拉取详情的最小状态

失败时前端明确会处理的错误类型至少包括：

- `listing_not_rentable`
- `price_changed`
- `insufficient_balance`

## 6.6 Rental Order List

### `GET /rental-orders`

每条记录最少需要：

- `order_id`
- `listing_id`
- `listing_title`
- `order_status`
- `runtime_status`
- `web_entry_status`
- `created_at`
- `remaining_seconds`
- `last_synced_at`

列表接口还需要支持：

- 按状态筛选
- 分页或无限滚动

## 6.7 Rental Order Detail

### `GET /rental-orders/{order_id}`

最少需要：

- `order_id`
- `order_status`
- `listing_summary`
- `created_at`
- `started_at`
- `expire_at`
- `remaining_seconds`
- `runtime_event_summary`
  - 至少包含 `has_open_event`
- `refund_summary` 或补偿/退款结果摘要

### `GET /rental-orders/{order_id}/deployment`

最少需要：

- `deployment_id`
- `runtime_status`
- `web_entry_status`
- `workspace_mode`
- `workspace_capabilities`
- `image_summary`
- `startup_command_summary`
- `access_url` 或访问入口摘要
- `last_synced_at`

### `POST /rental-orders/{order_id}/web-connect`

最少需要：

- `connect_url`
- `expires_at`
- `connect_mode`

建议额外支持：

- 返回现有未过期连接
- 返回连接是否复用

### `POST /rental-orders/{order_id}/release`

最少需要：

- `order_id`
- `order_status`
- `release_requested_at`

## 6.8 Benchmark

### `POST /benchmark-jobs/code-archive-uploads`

最少需要：

- `code_archive_token`
- `file_name`
- `uploaded_at`

### `POST /benchmark-jobs`

请求体最少需要能表达：

- `input_mode`
  - `code_archive` 或 `git_repository`
- `code_archive_token`
- `git_clone_url`
- `git_ref`
- `entry_hint`

成功响应最少需要：

- `job_id`
- `job_status`

### `GET /benchmark-jobs/{job_id}`

最少需要：

- `job_id`
- `job_status`
- `input_source_summary`
- `created_at`
- `updated_at`
- `failure_reason`

文档直接出现或隐含的状态至少包括：

- `queued`
- `preparing_input`
- `running`
- `analyzing`
- `succeeded`
- `failed`
- `timeout`

### `GET /benchmark-jobs/{job_id}/recommendations`

每条推荐最少需要：

- `listing_id`
- `title`
- `recommendation_reason` 或摘要
- `score` 或排序依据
- `price_snapshot`（推断）

注意：

- 结果页文档展示的是“推荐结果快照 + 再实时查询 listing 当前状态”
- 所以后端必须允许推荐结果页再调用 `/market/listings/{listing_id}` 做最新状态校验

## 6.9 Seller Compute Nodes

### `GET /seller/compute-nodes`

每条节点概况最少需要：

- `node_id`
- `node_name`
- `online_status`
- `runtime_status`
- `last_synced_at`
- `hardware_summary`
- `region_code`

### `GET /seller/compute-nodes/access-guide`

最少需要：

- `introduction`
- `environment_checklist`
- `step_list`
- `faq_items`

### `POST /seller/compute-nodes/bootstrap-sessions`

最少需要：

- `session_id`
- `bootstrap_command`
- `expires_at`
- `status`

### `GET /seller/compute-nodes/bootstrap-sessions/{session_id}`

最少需要：

- `session_id`
- `status`
- `expires_at`
- `node_id`
- `listing_id`
- `last_error`
- `last_synced_at`

文档明确或隐含的状态至少包括：

- `created`
- `pending`
- `verified`
- `failed`
- `expired`

此外还需要能表达：

- 节点已发现但价格未生成
- 节点已发现但状态未收敛

### `POST /seller/compute-nodes/register-self`

这是本地脚本接口，不是浏览器接口。  
前端文档没有冻结具体字段，但后端至少要能接收：

- `session_id` 或等价 bootstrap 凭据
- 节点侧身份信息
- 节点侧硬件信息
- Swarm 关联信息

### `POST /seller/compute-nodes/{node_id}/sync`

最少需要：

- `node_id`
- `sync_status`
- `listing_id`
- `message`

### `GET /seller/compute-nodes/{node_id}`

最少需要：

- `node_id`
- `online_status`
- `runtime_status`
- `last_synced_at`
- `hardware_summary`
- `linked_listing_summary`

## 6.10 Seller Listings

### `GET /seller/listings`

每条 listing 概况最少需要：

- `listing_id`
- `title`
- `summary`
- `platform_price_hourly`
- `publish_status`
- `rentable_status`
- `linked_node_status`

### `GET /seller/listings/{listing_id}`

最少需要：

- `listing_id`
- `title`
- `summary`
- `description`
- `platform_price_hourly`
- `publish_status`
- `rentable_status`
- `image_policy`
- `linked_node_id`

### `PATCH /seller/listings/{listing_id}`

请求体最少需要能表达：

- `title`
- `description`
- `image_policy`

成功响应最少需要返回更新后的详情。

### `POST /seller/listings/{listing_id}/off-shelf`

最少需要：

- `listing_id`
- `publish_status`

### `POST /seller/listings/{listing_id}/publish`

最少需要：

- `listing_id`
- `publish_status`
- `rentable_status`

## 6.11 Admin Dashboard

管理员大盘所有接口都建议至少统一带上：

- `generated_at`
- `time_window`
- `success`

因为页面文档明确要求：

- 区块独立渲染
- 高频刷新
- 空数据与错误状态区分
- 不依赖单一总接口

因此管理员接口的返回形态建议收敛为下面 5 类：

| 形态 | 典型用途 | 最少字段 |
|---|---|---|
| `summary_card` | KPI、overview | `label`、`value`、`unit`、`delta`、`generated_at` |
| `distribution` | 状态分布、区域分布 | `buckets[]`，每个 bucket 至少有 `key`、`label`、`count` |
| `trend` | 趋势图 | `points[]`，每个 point 至少有 `timestamp`、`value` |
| `ranking` | Top 榜、风险榜 | `items[]`，每项至少有 `id`、`label`、`value`、`rank` |
| `timeline` | 异常流、审计流 | `events[]`，每项至少有 `event_id`、`timestamp`、`type`、`summary` |

节点详情抽屉 `GET /admin/nodes/{node_id}/detail` 最少还需要：

- `node_id`
- `node_name`
- `seller_id`
- `region_code`
- `hardware_summary`
- `online_status`
- `runtime_status`
- `risk_level`
- `last_heartbeat_at`
- `last_synced_at`

---

## 7. 后端必须稳定输出的状态与枚举

前端文档虽然不是状态机文档，但已经强行要求后端稳定输出以下状态集合。

## 7.1 用户能力

- `buyer`
- `seller`
- `admin`

## 7.2 Listing 相关

- `publish_status`
  - 至少要能区分：已上架、已下架
- `rentable_status`
  - 至少要能区分：可租、已租、不可租
- `price_stale`
  - 布尔值或等价表达

## 7.3 Benchmark 相关

- `queued`
- `preparing_input`
- `running`
- `analyzing`
- `succeeded`
- `failed`
- `timeout`

## 7.4 Order / Deployment 相关

- `order_status`
  - 至少要能支撑：创建中、运行中、释放中、已释放、失败
- `runtime_status`
  - 至少要能支撑：`starting`、`running`、`stopping`、`failed`、`released`、`lost`
- `web_entry_status`
  - 至少要能支撑：`ready`、`unavailable`、`pending`

## 7.5 Bootstrap Session 相关

- `created`
- `pending`
- `verified`
- `failed`
- `expired`

## 7.6 异常摘要

前端没有要求完整异常事件体直接铺满所有页面，但要求订单详情页最少能知道：

- 当前是否存在开放异常事件
- 是否已经收敛
- 是否存在退款/补偿结果

---

## 8. 前端隐含要求后端提供的错误类型

页面文档没有完整错误码表，但已经明确要求前端识别下面这些错误场景。  
因此后端至少应稳定给出等价错误码或错误原因。

| 场景 | 页面 | 作用 |
|---|---|---|
| `auth_required` | 多页 | 未登录跳登录 |
| `permission_denied` | 多页 | 进入 `NoPermissionPage` |
| `listing_not_rentable` | `ListingDetailPage` | 保留输入并刷新详情 |
| `price_changed` | `ListingDetailPage` | 提示价格变化并回刷详情 |
| `insufficient_balance` | `ListingDetailPage` | 下单失败提示 |
| `deployment_not_running` | `RentalOrderDetailPage` | 网页连接失败 |
| `connect_prepare_failed` | `RentalOrderDetailPage` | 连接申请失败但留在当前页 |
| `bootstrap_session_expired` | `ComputeNodeBootstrapPage` | 提示重建 session |
| `node_sync_pending` | `ComputeNodeBootstrapPage` | 提示手动重试同步 |
| `benchmark_failed` | `BenchmarkResultPage` | 展示失败原因与重试入口 |
| `service_unavailable` | 多页 | 局部错误或进入 `ServiceErrorPage` |
| `platform_maintenance` | 多页 | 进入 `MaintenancePage` |

---

## 9. 页面对后端的特殊要求

## 9.1 `PortalPage`

这是公开入口。  
如果要做概况卡，后端必须决定：

- 是否允许游客读取
- 是否走缓存
- 失败时是否允许降级为空白卡片

## 9.2 `MarketListPage`

后端必须允许：

- 游客浏览或明确拒绝游客浏览
- 筛选器接口失败时列表接口仍可正常独立返回
- 列表与筛选器并行请求

这意味着后端不要把筛选器接口和列表接口硬耦合成同一份大对象。

## 9.3 `ListingDetailPage`

详情页不是静态展示页，而是一个强交互页面。  
后端必须保证：

- 详情接口能返回足够表单上下文
- 下单失败后详情可以立刻回刷
- 下单错误能够区分“价格变了”和“已不可租”

## 9.4 `BenchmarkResultPage`

推荐结果页明确采用：

- 先读推荐结果快照
- 再查每个 listing 当前状态

因此后端必须接受前端在同一页面上：

- 一次读 benchmark recommendations
- 多次再读 listing detail

## 9.5 `RentalOrderDetailPage`

这个页面对后端要求最高，因为它同时读取：

- 订单事实
- 部署事实
- 异常事实
- 网页连接动作
- 释放动作

后端如果把这些信息拆得过碎，前端会产生高频轮询风暴；如果把这些信息全塞到一个大接口，又会导致动作接口语义不清。

因此建议保持：

- `order detail`
- `deployment detail`
- `web connect`
- `release`

这 4 类接口边界清晰。

## 9.6 `ComputeNodeBootstrapPage`

这个页面不仅要浏览器接口，还要求“本地脚本接口”存在。  
所以后端不能只设计浏览器 API，还必须设计：

- bootstrap session 创建
- 本地命令消费的 register-self
- session 轮询读取
- 节点手动同步

## 9.7 `AdminDashboardPage`

大盘不是一个“单接口渲染整页”的页面，而是一个“单 route + 多 widget + 多接口 + 多刷新频率”的页面。  
后端必须按区块拆接口，且默认它们会被并行请求、独立刷新、独立失败。

---

## 10. 当前文档尚未冻结但后端必须留接口弹性的地方

以下内容在页面文档中被明确标记为待确认，但后端设计时应预留弹性：

| 事项 | 当前情况 | 后端建议 |
|---|---|---|
| `PortalPage` 概况卡接口 | 未冻结 | 预留 `portal summary` 只读聚合接口 |
| 管理员登录是否共用 `/auth/login` | 未冻结 | 先做统一登录，能力判定走 `/auth/capabilities` |
| 市场是否允许游客浏览 | 倾向允许 | 市场读接口设计成可匿名读 |
| 市场搜索字段范围 | 未冻结 | 后端搜索层预留标题+摘要+硬件字段扩展 |
| 列表分页还是无限滚动 | 未冻结 | 后端优先提供 cursor 分页 |
| 自定义镜像是否默认展示 | 未冻结 | 详情接口保留能力字段 |
| Benchmark 是否支持私有仓库 | 未冻结 | 当前先仅公开仓库，接口结构别写死 |
| `connect_url` 默认打开方式 | 未冻结 | `web-connect` 返回 `connect_mode` |
| 卖家工作台是否做 overview 聚合接口 | 未冻结 | 当前可先拆 `compute-nodes` 与 `listings` 两个接口 |
| 接入说明是否区分 OS | 未冻结 | `access-guide` 预留 `platform/os` 维度 |
| bootstrap 过期后的处理方式 | 未冻结 | session 状态里显式返回 `expired` |
| listing 管理是单页还是双 route | 未冻结 | 保持列表和详情接口独立即可 |
| 管理端是否以后拆多 route | 未冻结 | 先按多区块接口设计，不强依赖单 route |
| 维护态检测接口 | 未冻结 | 建议预留统一维护态接口或响应头 |

---

## 11. 对后端编码顺序的直接建议

如果以后端先行为目标，应先做下面这几组接口，刚好覆盖虚拟前端的主链路：

1. `Auth`
   - `/auth/register`
   - `/auth/login`
   - `/auth/me`
   - `/auth/capabilities`
   - `/auth/logout`
2. `Market + Order`
   - `/market/listings/filters`
   - `/market/listings`
   - `/market/listings/{listing_id}`
   - `/rental-orders`
   - `/rental-orders`
   - `/rental-orders/{order_id}`
   - `/rental-orders/{order_id}/deployment`
3. `Seller`
   - `/seller/compute-nodes`
   - `/seller/compute-nodes/access-guide`
   - `/seller/compute-nodes/bootstrap-sessions`
   - `/seller/compute-nodes/register-self`
   - `/seller/compute-nodes/bootstrap-sessions/{session_id}`
   - `/seller/listings`
   - `/seller/listings/{listing_id}`
4. `Runtime Action`
   - `/rental-orders/{order_id}/web-connect`
   - `/rental-orders/{order_id}/release`
   - `/seller/compute-nodes/{node_id}/sync`
5. `Benchmark`
   - `/benchmark-jobs/code-archive-uploads`
   - `/benchmark-jobs`
   - `/benchmark-jobs/{job_id}`
   - `/benchmark-jobs/{job_id}/recommendations`
6. `Admin Dashboard`
   - 最后按区块拆分实现

---

## 12. 结论

这套“虚拟前端”已经把后端需要面对的事实固定得很清楚：

- 不是只有市场和下单两页，而是一整套 17 页统一应用
- 不是只有浏览器 API，还包含本地 bootstrap 脚本接入接口
- 不是只有读列表和写订单，还包含高频轮询、短时连接、异常收敛、卖家工作台和管理员大盘
- 不是只有成功路径，还要求后端能稳定区分权限问题、维护态、局部错误、页面级错误和业务错误

因此，后端如果要真正支撑这套虚拟前端，至少要同时设计：

- 角色与能力体系
- 市场读取体系
- 订单与部署读取/动作体系
- Benchmark 任务体系
- 卖家节点接入体系
- 管理员快照与 widget 体系
- 统一错误码和状态字段体系

本报告可以直接作为：

- 后端 API 清单起稿依据
- 后端 schema 与 DTO 设计依据
- 前后端联调契约依据
- Playwright / API 合同测试用例设计依据

