# BenchmarkResultPage

版本：V1.1
日期：2026-03-18

## 1. 页面定位

`BenchmarkResultPage` 是 `BenchmarkJob` 的结果页，负责展示任务阶段、失败原因和推荐的 `NodeRentalListing`。

## 2. 所属业务流程

- `05 买家发起 BenchmarkJob 并查看推荐`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 任务状态轮询 | 轮询任务当前阶段 |
| 结果展示 | 展示成功、失败、超时等状态 |
| 推荐列表 | 展示推荐的 `NodeRentalListing` 并实时查询可租状态 |
| 跳转详情 | 点击推荐项跳转 `ListingDetailPage` |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开结果页 | 从提交页成功跳转进入 | 页面立即进入 polling 模式 | `GET /benchmark-jobs/{job_id}` |
| 任务运行中 | 用户停留在结果页 | 每轮轮询更新 `queued`、`running`、`analyzing` 等阶段展示 | `GET /benchmark-jobs/{job_id}` |
| 任务成功 | 页面检测到 `job_status = succeeded` | 停止基础轮询，加载推荐列表 | `GET /benchmark-jobs/{job_id}/recommendations` |
| 任务失败 | 页面检测到 `failed` 或超时 | 展示失败原因、重试按钮和返回提交页入口 | `GET /benchmark-jobs/{job_id}` |
| 点击推荐项 | 点击某个推荐 listing | 路由跳转到 `ListingDetailPage` | 无 |

## 5. 当前待确认点

1. 推荐列表是否需要在结果页内继续轮询”当前是否可租”，还是跳到详情页后再校验，当前资料倾向后者。

## 6. 推荐结果实时状态查询

### 6.1 查询策略

采用**乐观展示 + 实时状态标注**方案：

1. 获取推荐结果（快照）
2. 并行查询每个 listing 的当前状态
3. 在 UI 上标注状态

### 6.2 实现示例

```javascript
async function loadRecommendations(jobId) {
  // 1. 获取推荐结果
  const recommendations = await api.getBenchmarkRecommendations(jobId);

  // 2. 并行查询当前状态
  const listingIds = recommendations.map(r => r.listing_id);
  const statuses = await Promise.all(
    listingIds.map(id => api.getListingDetail(id))
  );

  // 3. 合并状态
  recommendations.forEach((rec, index) => {
    const current = statuses[index];
    rec.current_rentable = current.rentable_status === 'rentable';
    rec.current_price = current.current_price_hourly;
  });

  return recommendations;
}
```

### 6.3 UI 状态标注

- ✅ **可租用**：`rentable_status = 'rentable'`，正常显示
- ⚠️ **已被租用**：`rentable_status = 'rented'`，灰色显示，标注”已被占用”
- ❌ **已下架**：`publish_status != 'listed'`，灰色显示，标注”已下架”

### 6.4 用户提示

在推荐列表顶部显示：

```
💡 推荐结果仅供参考，实际可租状态以下单时为准
```

