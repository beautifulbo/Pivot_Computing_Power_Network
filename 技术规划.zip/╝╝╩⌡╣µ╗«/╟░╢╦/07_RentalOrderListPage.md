# RentalOrderListPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`RentalOrderListPage` 是买家查看自己全部已租实例的列表页，前端展示上把一条实例记录理解为 `RentalOrder + Deployment`。

## 2. 所属业务流程

- `03 买家直租 NodeRentalListing 并创建 Deployment`
- `04 买家控制台查看容器与网页连接`
- `06 轮询状态与异常巡检`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 实例列表展示 | 展示买家名下全部实例 |
| 状态筛选 | 按 `running`、`starting`、`released` 等筛选 |
| 网页入口状态展示 | 显示 `web_entry_status` |
| 进入详情 | 点击某条记录进入 `RentalOrderDetailPage` |
| 轮询更新 | 在运行态下周期刷新列表 |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开列表页 | 从导航进入“我的实例” | 页面骨架后加载列表数据 | `GET /rental-orders` |
| 切换状态筛选 | 选择 `running`、`starting`、`released` 等 | 局部刷新列表区，不刷新整页 | `GET /rental-orders?...` |
| 点击实例卡片 | 点击某一条记录 | 路由跳转到 `RentalOrderDetailPage` | 无 |
| 运行态轮询 | 页面发现存在 `pending_deploy`、`running`、`releasing` 记录 | 每 30 秒刷新一次列表 | `GET /rental-orders` |

## 5. 当前待确认点

1. 列表页是使用分页还是无限滚动，当前资料未冻结。
