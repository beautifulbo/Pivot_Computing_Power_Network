# RentalOrderDetailPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`RentalOrderDetailPage` 是买家查看单个实例运行状态、网页入口和释放动作的核心页面。

## 2. 所属业务流程

- `03 买家直租 NodeRentalListing 并创建 Deployment`
- `04 买家控制台查看容器与网页连接`
- `06 轮询状态与异常巡检`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 订单详情展示 | 展示 `RentalOrder` 基本信息 |
| 运行态展示 | 展示 `Deployment` 当前状态 |
| 网页连接 | 申请短时 `connect_url` |
| 主动释放 | 发起释放动作 |
| 异常展示 | 展示 `runtime_event_summary` 和退款补偿结果 |
| 轮询刷新 | 在 `starting`、`stopping` 或异常处理中轮询 |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开详情页 | 从列表页或下单成功后进入 | 页面并行拉订单和部署状态 | `GET /rental-orders/{order_id}`、`GET /rental-orders/{order_id}/deployment` |
| 启动中轮询 | 页面发现 `runtime_status = starting` 或 `stopping` | 每 10 秒刷新部署状态 | `GET /rental-orders/{order_id}/deployment` |
| 异常态轮询 | 页面发现 `runtime_event_summary.has_open_event = true` | 轮询订单与部署，等待异常结果收敛 | `GET /rental-orders/{order_id}`、`GET /rental-orders/{order_id}/deployment` |
| 网页连接 | 点击“网页连接” | 按钮 loading；成功后打开新标签页或嵌入连接面板 | `POST /rental-orders/{order_id}/web-connect` |
| 主动释放 | 点击“释放实例” | 弹出确认框；确认后提交释放；按钮进入提交态 | `POST /rental-orders/{order_id}/release` |
| 释放后刷新 | 释放请求成功返回 | 继续刷新订单和部署状态，直到变成 `released` | `GET /rental-orders/{order_id}`、`GET /rental-orders/{order_id}/deployment` |
| 工作区内上传代码 | 进入浏览器工作区后在工作区上传文件 | 这是运行实例自身能力，不经过平台前端页面 | 无平台固定接口 |
| 工作区内 `git clone` | 进入浏览器终端后执行 `git clone` | 这是运行实例自身能力，不经过平台前端页面 | 无平台固定接口 |

## 5. 当前待确认点

1. `connect_url` 成功后默认新标签页打开还是内嵌面板，当前资料允许两种模式，但默认方式未冻结。
2. 释放成功后是否自动跳回列表页，当前资料更倾向停留详情页并显示最终状态。

## 6. 注意事项

**Bug-04-01：短时连接URL并发生成问题**
- 网页连接按钮需防抖处理（1秒）
- 请求期间禁用按钮，避免重复点击
- **建议**：后端返回已存在的有效连接URL

**Bug-04-02：连接URL过期后用户体验问题**
- 显示连接过期提示并提供重新连接按钮
- **建议**：网关层自动续期即将过期的连接

**Bug-04-06：剩余时长计算不准确**
- 使用后端返回的 `remaining_seconds` 字段进行倒计时
- 每5分钟同步一次服务器时间，避免累积误差
