# ListingManagePage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`ListingManagePage` 是卖家查看和管理自己 `NodeRentalListing` 的页面，重点是上下架与状态查看，而不是定价。

## 2. 所属业务流程

- `01 卖家接入 ComputeNode`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 上架记录列表 | 展示卖家自己的 listing |
| 上架详情查看 | 查看自动生成的标题、摘要、描述、平台价格 |
| 上下架操作 | 控制 listing 是否出现在市场中 |
| 基础编辑 | 修改标题、描述、镜像策略 |
| 关联节点查看 | 查看对应 `ComputeNode` 当前在线与运行状态 |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开管理页 | 从工作台进入上架管理页 | 加载 listing 列表 | `GET /seller/listings` |
| 打开 listing 详情 | 点击某条记录 | 拉取该 listing 详情，显示右侧详情区或详情页 | `GET /seller/listings/{listing_id}` |
| 修改基础信息 | 编辑标题、描述、镜像策略后保存 | 表单提交态；成功后刷新当前详情 | `PATCH /seller/listings/{listing_id}` |
| 下架 | 点击“下架” | 弹出确认框；确认后刷新当前状态 | `POST /seller/listings/{listing_id}/off-shelf` |
| 重新上架 | 点击“重新上架” | 按钮 loading；成功后更新状态 | `POST /seller/listings/{listing_id}/publish` |
| 查看关联节点 | 需要查看节点运行状态时 | 可额外拉取关联 `ComputeNode` 详情 | `GET /seller/compute-nodes/{node_id}` |

## 5. 当前待确认点

1. `ListingManagePage` 是单页带抽屉，还是列表页 + 详情页双 route，当前资料未冻结。
2. 卖家是否允许长期修改标题和描述，当前接口允许，但运营约束还没单独定义。
