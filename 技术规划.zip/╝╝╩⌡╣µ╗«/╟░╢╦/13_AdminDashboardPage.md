# AdminDashboardPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`AdminDashboardPage` 是管理员统一大盘页，当前按“单 route + 多 widget 分区”设计，不拆成多个独立后台 route。

## 2. 所属业务流程

- `07 管理员查看平台 Dashboard`
- `06 轮询状态与异常巡检` 的结果读取页

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 顶部 KPI 区 | 展示平台总量、运行量、异常量 |
| 平台负载区 | 展示 CPU、内存、GPU、容量和趋势 |
| 节点监控区 | 展示节点矩阵、Top 榜、风险节点 |
| 市场价格区 | 展示供给分布、价格趋势、热门上架 |
| 订单部署区 | 展示订单状态、部署状态、到期预警 |
| Benchmark 区 | 展示测算任务状态、来源分布、失败原因 |
| 风险区 | 展示异常事件流、严重度、补偿统计 |
| 审计区 | 展示时间线、动作分布、管理员登录记录 |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开大盘 | 管理员进入页面 | 页面先渲染骨架，再按区块并行取数 | `GET /admin/dashboard/kpi-summary`、`GET /admin/dashboard/platform-health`、`GET /admin/dashboard/platform-load`、`GET /admin/dashboard/resource-capacity`、`GET /admin/dashboard/resource-utilization-trend` |
| 节点监控区加载 | 页面首屏自动请求节点区数据 | 每个 widget 独立渲染，失败不影响整页 | `GET /admin/nodes/overview`、`GET /admin/nodes/status-distribution`、`GET /admin/nodes/load-matrix`、`GET /admin/nodes/top-cpu`、`GET /admin/nodes/top-memory`、`GET /admin/nodes/top-gpu`、`GET /admin/nodes/top-network-in`、`GET /admin/nodes/top-network-out`、`GET /admin/nodes/top-idle`、`GET /admin/nodes/risk-ranking`、`GET /admin/nodes/heartbeat-latency` |
| 点击节点卡片 | 点击矩阵中的某台节点 | 打开抽屉或侧栏展示详情 | `GET /admin/nodes/{node_id}/detail` |
| 市场价格区加载 | 页面首屏自动请求市场区数据 | 渲染供给分布图、价格趋势图、排行卡 | `GET /admin/market/overview`、`GET /admin/market/listing-status-distribution`、`GET /admin/market/gpu-distribution`、`GET /admin/market/cpu-tier-distribution`、`GET /admin/market/region-distribution`、`GET /admin/market/price-trend`、`GET /admin/market/top-hot-listings`、`GET /admin/market/top-expensive-listings`、`GET /admin/market/top-cheap-listings` |
| 订单部署区加载 | 页面首屏自动请求订单和部署区数据 | 渲染状态环图、趋势图、即将到期列表 | `GET /admin/orders/overview`、`GET /admin/orders/status-distribution`、`GET /admin/orders/create-trend`、`GET /admin/orders/release-type-distribution`、`GET /admin/orders/expiring-soon`、`GET /admin/orders/high-value`、`GET /admin/deployments/overview`、`GET /admin/deployments/runtime-distribution`、`GET /admin/deployments/web-entry-distribution`、`GET /admin/deployments/runtime-failure-top` |
| Benchmark 区加载 | 页面首屏自动请求测算区数据 | 渲染状态分布、失败榜、来源图 | `GET /admin/benchmarks/overview`、`GET /admin/benchmarks/status-distribution`、`GET /admin/benchmarks/mode-distribution`、`GET /admin/benchmarks/source-type-distribution`、`GET /admin/benchmarks/duration-trend`、`GET /admin/benchmarks/failure-top` |
| 风险区加载 | 页面首屏自动请求风险区数据 | 渲染异常滚动流、风险排行、补偿统计 | `GET /admin/risk/overview`、`GET /admin/risk/runtime-events`、`GET /admin/risk/severity-distribution`、`GET /admin/risk/event-type-distribution`、`GET /admin/risk/refund-compensation-stats`、`GET /admin/risk/risk-nodes` |
| 审计区加载 | 页面首屏自动请求审计区数据 | 渲染时间线和动作分布 | `GET /admin/audit/timeline`、`GET /admin/audit/action-type-distribution`、`GET /admin/audit/recent-admin-logins` |
| 周期刷新 | 管理员停留在页面中 | 高频 widget 10-30 秒刷新，中低频区块按更长周期刷新 | 同上各区块接口 |

## 5. 当前待确认点

1. 管理员是否最终拆成多 route 后台，而不是单页多区块。
2. 节点详情、订单详情未来是否需要从 dashboard 中继续钻取到单独详情页，当前资料只覆盖抽屉式读取。

## 6. 注意事项

**Bug-07-07：空数据与错误状态混淆**
- 后端使用统一响应格式，包含 `success` 字段区分成功和失败
- 前端区分处理：加载中、错误、空数据三种状态
- **建议**：空数据显示"暂无数据"，错误显示具体错误信息
