# 前端页面实施计划

## 1. 目录目标

本目录文档已经把当前项目的前端实现原则重新收敛为：

- 新建独立 `platform-frontend` 作为算力交易平台主前端
- 新前端优先围绕新后端契约实现，不要求先兼容旧门户、旧路由和旧登录态
- 原有 `system-template/system-vue` 保持历史系统壳定位，是否接入留到后续集成阶段再决定
- 当前阶段允许“新平台前端 + 旧门户”并行存在，优先保证新后端业务逻辑和新前端主流程先跑通

同时需要新增一条执行硬约束：

- 后续前端主实现以 `platform-frontend` 为准，禁止为了提前兼容旧门户而反向扭曲新后端契约和页面结构
- 页面数量、页面职责、区域划分和核心跳转关系，必须严格遵循 `./前端页面规划文档.md`
- 若页面规划需要变化，应先修改页面规划文档，再同步修改本 `PLAN.md` 与代码，不能绕开规划文档直接改实现

此外，前端相关文档中的 Mermaid 图和表格必须被视为页面实现约束：

- Mermaid 图用于固定页面跳转、区域关系、状态流和数据流方向
- 表格用于固定页面职责、接口清单、字段显示要求、状态映射和测试覆盖范围

后续如果页面职责、路由跳转、页面状态、接口清单或展示字段发生变化，必须同步更新对应 Mermaid 图和表格，而不是只改页面正文说明。

建议实现位置：

- `../../Pivot_Computing_Power_Network/platform-frontend`

建议新增业务区域：

- `src/views/platform/`
- `src/page-models/platform/`
- `src/router/modules/platform.js`
- `src/api/platform/`
- `src/services/platform/`
- `src/store/modules/platform*.js`
- `src/components/platform/`

---

## 2. 推荐前端目录结构

```text
platform-frontend/
  src/
    api/
      platform/
        auth.js
        market.js
        orders.js
        benchmarks.js
        seller.js
        admin.js
    page-models/
      platform/
        market/
        orders/
        benchmark/
        seller/
        admin/
        auth/
        portal/
    services/
      platform/
        auth-service.js
        market-service.js
        order-service.js
        benchmark-service.js
        seller-service.js
        admin-service.js
    components/
      platform/
        common/
    router/
      modules/
        platform.js
    store/
      modules/
        platform-session.js
        platform-app.js
    views/
      platform/
        PortalPage/
        AuthPage/
        MarketListPage/
        ListingDetailPage/
        BenchmarkSubmitPage/
        BenchmarkResultPage/
        RentalOrderListPage/
        RentalOrderDetailPage/
        SellerWorkbenchPage/
        ComputeNodeAccessGuidePage/
        ComputeNodeBootstrapPage/
        ListingManagePage/
        AdminDashboardPage/
        NoPermissionPage/
        NotFoundPage/
        ServiceErrorPage/
        MaintenancePage/
        modules/
          market/
          benchmark/
          orders/
          seller/
          admin-dashboard/
          system-pages/
    utils/
      platform-request.js
    styles/
      platform/
    __tests__/
      platform/
  tests/
    e2e/
```

说明：

- 新业务页面统一放在 `platform-frontend/src/views/platform/`
- 页面编排逻辑统一放在 `src/page-models/platform/`，避免把流程控制全部塞进 `.vue` 页面
- 新业务 API 统一放在 `src/api/platform/` 下按域拆分
- 业务规则、提交资格判断、状态推进逻辑统一沉淀到 `src/services/platform/`
- 新平台状态管理在 `platform-frontend` 内独立维护，不与旧门户 store 直接耦合

---

## 3. 前端整体实现原则

依据本目录文档和前面已读测试文档，当前项目的前端必须遵守：

1. 新平台主前端固定为独立 `platform-frontend`，不再以旧 `system-vue` 作为主实现工程。
2. 当前阶段不要求新前端先接入旧门户壳、旧登录态、旧菜单体系。
3. 新页面按规划文档中的 route 实现，并在 `platform-frontend` 内独立组织路由体系。
4. 普通用户、卖家、管理员前端入口逻辑隔离，但都在同一个新前端工程内实现。
5. 页面只负责展示和交互，不承接后端业务规则。
6. 订单、部署、benchmark、节点接入状态都以后端返回事实为准。
7. 页面要明确区分：加载中、空状态、局部错误、页面级错误、维护态、无权限。
8. 核心联调必须使用 `Playwright`，不能只靠手点。
9. 所有可交互元素应优先增加 `data-testid`。
10. 当前前端主线可以直接采用独立工程推荐技术栈，不再受旧门户技术栈绑定。
11. 前端改动必须保持“小步、可回归、可联调”，但约束对象是 `platform-frontend` 自身的公共层，不是旧门户壳。
12. `前端页面规划文档.md` 是前端页面实现的唯一页面级约束来源，未经文档变更不得擅自新增主页面、合并页面、拆分页面或修改主跳转链路。
13. 页面 UI 组件内不得直接写 `axios` / `fetch` / token 处理 / 通用重试逻辑；页面层只负责展示和触发动作。
14. 页面 UI 组件内不得直接堆积复杂业务规则，例如“能不能提交”“什么状态能重试”“是否允许重新接入”这类判断必须下沉到业务层或页面编排层。
15. AI 协作开发前端时，默认顺序固定为：接口契约 -> 状态模型 -> 业务流程 -> 自动化测试 -> UI 接入，不允许反过来先生成整页 UI 再回填逻辑。

### 3.2 页面规划文档约束落地

前端实现时，必须把 `前端页面规划文档.md` 中已经冻结的内容直接视为编码约束：

- 页面集合固定为文档定义的 17 个页面，当前实现不得自行扩展为另一套主页面体系
- 页面区域固定为 `Public`、`Market`、`Benchmark`、`Seller`、`Admin` 五个区域
- 核心跳转必须对齐文档中的既定关系，例如：
  - `PortalPage -> AuthPage / MarketListPage / BenchmarkSubmitPage / SellerWorkbenchPage / AdminDashboardPage`
  - `MarketListPage -> ListingDetailPage`
  - `ListingDetailPage -> RentalOrderDetailPage`
  - `BenchmarkSubmitPage -> BenchmarkResultPage`
  - `BenchmarkResultPage -> ListingDetailPage`
  - `RentalOrderListPage -> RentalOrderDetailPage`
  - `SellerWorkbenchPage -> ComputeNodeAccessGuidePage / ComputeNodeBootstrapPage / ListingManagePage`
- 若代码实现与页面规划文档冲突，以页面规划文档为准，先回修规划对齐，再允许继续开发

### 3.3 前端改动控制要求

- 新业务页面、组件、API、store 统一落在 `platform-frontend` 内的 `platform` 目录下
- 对 `platform-frontend/src/router/index.*`、`src/store/index.*`、`src/api/platform/client.*` 等全局文件的修改必须限制在新平台主线所必需的最小范围
- 不要求为新平台页面保留旧门户首页、旧模块入口、旧登录体系、旧权限守卫的兼容代码
- 每个前端开发任务开始前，都需要先回看本 `PLAN.md` 与 `前端页面规划文档.md`，确认没有偏离“独立新前端、先跑通主流程”的路线

### 3.4 前端分层规范

依据 `01-前端分层与AI协作规则.md`，前端实现至少要明确拆成以下 6 层，并固定落位：

- UI 层
  - 负责页面结构、展示、表单控件、弹窗开关、表格列和视觉状态
  - 建议位置：`src/views/platform/**`、`src/components/platform/**`
- 页面编排层
  - 负责把用户动作串成页面流程，例如“点击发布后先校验、再提交、再刷新列表”
  - 建议位置：`src/page-models/platform/**`
- 状态层
  - 负责页面级或全局状态，如列表数据、分页、筛选器、loading、error、selectedId
  - 建议位置：`src/store/modules/platform*.js`
- 网络层
  - 负责请求封装、token 注入、超时、统一错误转换、分页协议适配
  - 建议位置：`src/api/platform/**`、`src/utils/platform-request.js` 或 `src/api/platform/client.js`
- 业务层
  - 负责业务规则，如提交资格判断、状态可操作性判断、表单转领域请求、结果归一化
  - 建议位置：`src/services/platform/**`
- 基础组件层
  - 负责平台通用按钮、状态块、空态、错误态、时间组件、通用表格包装
  - 建议位置：`src/components/platform/common/**`

### 3.5 单向数据流与禁区

推荐数据流固定为：

- `UI 层 -> 页面编排层 -> 状态层 / 业务层 -> 网络层 -> 后端 API`

编码时禁止出现以下反模式：

- `.vue` 页面中直接发 `axios` / `fetch`
- `.vue` 页面中直接拼复杂请求参数和复杂业务条件
- 页面层自己处理 token 刷新、401 恢复、统一重试、全局错误码映射
- 同一接口在多个页面里复制一份调用逻辑
- 一个页面文件同时承担 UI、请求、业务规则、轮询、错误恢复和样式控制

### 3.6 AI 协作开发顺序

后续凡是让 AI 参与前端开发，必须按下面顺序拆任务：

1. 先锁定接口契约：路径、方法、请求参数、响应字段、错误码、分页规则、鉴权方式
2. 再锁定状态模型：至少明确 `list`、`pagination`、`loading`、`error`、`filters`、`selectedId`
3. 再锁定业务流程：明确提交、刷新、重试、禁用条件、回滚、状态跳转
4. 先让 AI 交付非 UI 部分：类型、API 封装、page model、store、service、测试
5. 最后再补 UI：布局、弹窗、表格列、表单样式和视觉细节

如果某个前端需求无法先把前四步说清楚，则不应直接开始写完整页面。

### 3.7 根据问题目录新增的前端硬约束

依据 `技术规划\问题` 下的文档，前端计划必须补齐以下行为：

- 登录态
  - 自动刷新 token
  - 401 统一重试
  - refresh 失败后清会话并跳登录页
- 市场页
  - 筛选器和列表使用 `Promise.allSettled`
  - 局部失败时支持降级而非整页崩溃
  - 价格 stale 明确标识
  - 详情页至少支持短轮询或状态订阅
- 下单页
  - 下单失败后保留用户输入
  - 价格变化时展示旧价/新价对比
  - 防止重复提交
- 实例详情页
  - `connect_url` 按钮防抖与请求去重
  - `remaining_seconds` 作为倒计时唯一可信来源
  - 连接失效后有重新连接提示
  - 轮询/SSE/WS 在页面卸载时必须清理
- 卖家接入页
  - 5 分钟轮询超时
  - 指数退避重试
  - 手动刷新与手动同步按钮
- Benchmark 页
  - 输入源严格二选一
  - 上传大小限制和前置校验
  - 结果页显示推荐生成时间与当前状态
- Dashboard
  - 使用统一快照接口或分批加载
  - 清理所有刷新定时器
  - 明确区分空数据与错误状态

---

## 4. 路由与区域规划

新页面仍然分 5 个访问区域，但实现方式改为：

- 统一挂在原项目 `system-vue` 路由树中
- 通过原有菜单体系或模块入口进入
- 不再设计为独立前端站点

## 4.1 Public Area

- `PortalPage`
- `AuthPage`
- `NoPermissionPage`
- `NotFoundPage`
- `ServiceErrorPage`
- `MaintenancePage`

## 4.2 Market Area

- `MarketListPage`
- `ListingDetailPage`
- `RentalOrderListPage`
- `RentalOrderDetailPage`

## 4.3 Benchmark Area

- `BenchmarkSubmitPage`
- `BenchmarkResultPage`

## 4.4 Seller Area

- `SellerWorkbenchPage`
- `ComputeNodeAccessGuidePage`
- `ComputeNodeBootstrapPage`
- `ListingManagePage`

## 4.5 Admin Area

- `AdminDashboardPage`

### 4.6 路由接入方式

建议在原项目中新增：

- `src/router/modules/platform.js`

由该路由模块统一注册新业务页面，例如：

- `/platform`
- `/platform/auth`
- `/platform/market`
- `/platform/market/listings/:listingId`
- `/platform/orders`
- `/platform/orders/:orderId`
- `/platform/seller/workbench`
- `/platform/admin/dashboard`

这样可以做到：

- 不破坏旧路由
- 新旧页面共存
- 后续菜单配置和权限控制更清晰

---

## 5. 页面级实施方案

## 5.1 PortalPage

依据 [01_PortalPage.md](./01_PortalPage.md)，这是统一入口页。

### 实现位置

- `src/views/platform/PortalPage/`
- `src/views/platform/modules/portal/`

### 需要实现

- 平台介绍
- 买家、卖家、benchmark、管理员入口
- 公开导航
- 可选平台概况卡

### 测试方法

- 组件测试：入口按钮渲染和跳转条件
- E2E：未登录进入卖家/管理员入口的跳转行为

## 5.2 AuthPage

依据 [02_AuthPage.md](./02_AuthPage.md)。

### 实现位置

- `src/views/platform/AuthPage/`
- `src/views/platform/modules/auth/`
- `src/store/modules/platform-session.js`

### 需要实现

- 注册
- 登录
- 会话恢复
- 登录成功后读取用户和能力
- 与原项目登录态机制兼容

### 测试方法

- 组件测试：表单校验、错误提示、loading 状态
- E2E：注册、登录成功、登录失败、退出

## 5.3 MarketListPage

依据 [03_MarketListPage.md](./03_MarketListPage.md)。

### 实现位置

- `src/views/platform/MarketListPage/`
- `src/views/platform/modules/market/list/`

### 需要实现

- 首屏列表与筛选器并行加载
- GPU/区域/价格/关键字筛选
- 排序
- cursor 分页

### 测试方法

- 组件测试：筛选器状态、空数据、错误态
- API mock 测试：cursor 翻页与 query 状态同步
- E2E：筛选、排序、进入详情

## 5.4 ListingDetailPage

依据 [04_ListingDetailPage.md](./04_ListingDetailPage.md)。

### 实现位置

- `src/views/platform/ListingDetailPage/`
- `src/views/platform/modules/market/detail/`

### 需要实现

- 节点详情展示
- 租用表单
- 预估费用范围展示
- 下单失败后状态回刷

### 测试方法

- 组件测试：表单校验、价格区间显示、错误回显
- E2E：从详情页下单成功、价格变更、listing 不可租

## 5.5 BenchmarkSubmitPage

依据 [05_BenchmarkSubmitPage.md](./05_BenchmarkSubmitPage.md)。

### 实现位置

- `src/views/platform/BenchmarkSubmitPage/`
- `src/views/platform/modules/benchmark/submit/`

### 需要实现

- `code_archive` / `git_repository` 二选一
- 压缩包上传进度
- `entry_hint`、项目类型等辅助信息
- 提交后跳结果页

### 测试方法

- 组件测试：输入源互斥、文件上传状态、提交按钮状态
- E2E：压缩包提交、git 链接提交、非法输入拦截

## 5.6 BenchmarkResultPage

依据 [06_BenchmarkResultPage.md](./06_BenchmarkResultPage.md)。

### 实现位置

- `src/views/platform/BenchmarkResultPage/`
- `src/views/platform/modules/benchmark/result/`

### 需要实现

- 轮询任务状态
- 成功/失败/超时展示
- 推荐列表展示
- 推荐结果当前状态标注

### 测试方法

- 组件测试：不同 job_status 的 UI 状态
- API mock 测试：轮询停止条件
- E2E：提交后进入结果页，等待成功或失败结果

## 5.7 RentalOrderListPage

依据 [07_RentalOrderListPage.md](./07_RentalOrderListPage.md)。

### 实现位置

- `src/views/platform/RentalOrderListPage/`
- `src/views/platform/modules/orders/list/`

### 需要实现

- 实例列表
- 状态筛选
- `web_entry_status` 展示
- 运行态下周期刷新

### 测试方法

- 组件测试：状态筛选、卡片状态展示
- E2E：进入详情、轮询刷新中的状态变化

## 5.8 RentalOrderDetailPage

依据 [08_RentalOrderDetailPage.md](./08_RentalOrderDetailPage.md)。

### 实现位置

- `src/views/platform/RentalOrderDetailPage/`
- `src/views/platform/modules/orders/detail/`

### 需要实现

- 订单与 deployment 并行加载
- `runtime_status` 与 `web_entry_status` 展示
- 申请短时 `connect_url`
- 主动释放
- 异常事件与退款补偿展示
- `starting/stopping` 与异常处理中轮询

### 测试方法

- 组件测试：连接按钮启用/禁用、倒计时、异常提示条
- E2E：连接、释放、异常后状态更新
- 故障测试：连接 URL 过期、重复点击连接

## 5.9 SellerWorkbenchPage

依据 [09_SellerWorkbenchPage.md](./09_SellerWorkbenchPage.md)。

### 实现位置

- `src/views/platform/SellerWorkbenchPage/`
- `src/views/platform/modules/seller/workbench/`

### 需要实现

- 节点概况
- 上架概况
- 快速入口卡

### 测试方法

- 组件测试：工作台摘要卡和入口跳转
- E2E：卖家登录后进入工作台

## 5.10 ComputeNodeAccessGuidePage

依据 [10_ComputeNodeAccessGuidePage.md](./10_ComputeNodeAccessGuidePage.md)。

### 实现位置

- `src/views/platform/ComputeNodeAccessGuidePage/`
- `src/views/platform/modules/seller/access-guide/`

### 需要实现

- 接入说明
- 环境准备清单
- FAQ
- 开始接入按钮

### 测试方法

- 组件测试：FAQ 展开、按钮跳转

## 5.11 ComputeNodeBootstrapPage

依据 [11_ComputeNodeBootstrapPage.md](./11_ComputeNodeBootstrapPage.md)。

### 实现位置

- `src/views/platform/ComputeNodeBootstrapPage/`
- `src/views/platform/modules/seller/bootstrap/`

### 需要实现

- 生成 bootstrap session
- 展示命令、session id、过期时间
- 复制命令
- 轮询接入状态
- 失败时手动刷新和手动同步

### 测试方法

- 组件测试：命令生成、复制反馈、轮询开始/停止、超时表现
- E2E：生成命令后模拟 session 状态变化

## 5.12 ListingManagePage

依据 [12_ListingManagePage.md](./12_ListingManagePage.md)。

### 实现位置

- `src/views/platform/ListingManagePage/`
- `src/views/platform/modules/seller/listings/`

### 需要实现

- listing 列表
- 基础信息编辑
- 上下架
- 查看关联节点状态

### 测试方法

- 组件测试：编辑表单、发布/下架确认框
- E2E：卖家修改标题、下架、重新上架

## 5.13 AdminDashboardPage

依据 [13_AdminDashboardPage.md](./13_AdminDashboardPage.md)。

### 实现位置

- `src/views/platform/AdminDashboardPage/`
- `src/views/platform/modules/admin-dashboard/`

### 需要实现

- 单 route + 多 widget 分区
- 各区块并行加载
- 失败隔离
- 高频和中低频不同刷新频率
- 节点详情抽屉

### 测试方法

- 组件测试：widget 加载态、空态、错误态
- E2E：管理员登录、打开大盘、查看节点详情抽屉
- 联调测试：overview 和分区接口并行返回时 UI 正常合并

## 5.14 系统页

依据 [14_NoPermissionPage.md](./14_NoPermissionPage.md)、[15_NotFoundPage.md](./15_NotFoundPage.md)、[16_ServiceErrorPage.md](./16_ServiceErrorPage.md)、[17_MaintenancePage.md](./17_MaintenancePage.md)。

### 实现位置

- `src/views/platform/NoPermissionPage/`
- `src/views/platform/NotFoundPage/`
- `src/views/platform/ServiceErrorPage/`
- `src/views/platform/MaintenancePage/`

### 测试方法

- 路由测试：403、404、全局错误边界、维护态切换
- E2E：无权限跳转、错误路由跳转

---

## 6. 状态管理与 API 层规划

## 6.1 全局状态

建议在原项目 store 中集中新增并管理：

- 当前用户
- 当前能力集合
- token 与刷新状态
- 全局维护态
- 页面级错误边界信息

实现位置：

- `src/store/modules/platform-session.js`
- `src/store/modules/platform-app.js`

### 与旧状态的关系

- 旧项目现有用户态模块保留
- 新平台会话模块与旧用户态采用兼容方式逐步收敛
- 禁止在当前阶段完全推翻旧 `store/modules/user.js`

## 6.2 页面模块状态

建议每个业务模块维护局部状态，不要把所有页面状态塞进一个全局 store。

例如：

- `views/platform/modules/market/list/store.js`
- `views/platform/modules/orders/detail/store.js`
- `views/platform/modules/benchmark/result/store.js`

## 6.3 API 封装

建议按业务域拆分：

- `src/api/platform/auth.js`
- `src/api/platform/market.js`
- `src/api/platform/orders.js`
- `src/api/platform/benchmarks.js`
- `src/api/platform/seller.js`
- `src/api/platform/admin.js`

要求：

- 统一错误码解析
- 统一 token 注入与刷新
- 统一 `request_id` 透传
- 与原项目 `utils/request.js` 的拦截器能力保持兼容

### 6.4 请求层实施原则

推荐做法：

1. 在 `platform-frontend` 内独立维护 `src/api/platform/client.js`
2. 新平台请求封装只面向新后端契约，不为旧前端响应格式做兼容分支
3. 如果未来要接旧门户，只在集成层做跳转、嵌入或单点登录，不在主请求层混写双契约

---

## 7. 推荐开发顺序

前端必须按下面顺序推进：

1. `platform-frontend` 基础路由、全局状态、请求骨架
2. `AuthPage`
3. `PortalPage`
4. `MarketListPage`
5. `ListingDetailPage`
6. `RentalOrderListPage`
7. `RentalOrderDetailPage`
8. `SellerWorkbenchPage`
9. `ComputeNodeAccessGuidePage`
10. `ComputeNodeBootstrapPage`
11. `ListingManagePage`
12. `BenchmarkSubmitPage`
13. `BenchmarkResultPage`
14. `AdminDashboardPage`

原因：

- 先让新前端与新后端主流程跑通，比先接旧门户更重要
- 交易主链路优先于 benchmark 和管理员大盘
- 卖家接入是供给侧前置
- 管理员大盘依赖大部分后端聚合接口

---

## 8. 测试实施方案

## 8.1 组件测试

工具建议：

- 优先在 `platform-frontend` 内建立独立单测体系
- 不要求复用旧前端测试工具链
- 测试落点统一保持在新前端工程内

重点覆盖：

- 表单校验
- 加载态、空态、错误态
- 权限守卫
- 页面局部状态切换

测试位置：

- `platform-frontend/src/__tests__/platform/`
- 各模块内部 `__tests__/`

## 8.2 Playwright 联调测试

依据已读测试文档，必须把 `Playwright` 作为前后端联调底线。

重点覆盖：

1. 登录成功 / 失败
2. 市场列表加载与筛选
3. 从详情页下单
4. 查看订单详情和 deployment 状态
5. 卖家生成 bootstrap 命令
6. Benchmark 提交和结果展示
7. 管理员查看 Dashboard
8. 无权限用户看不到管理员页

测试位置：

- `platform-frontend/tests/e2e/platform-auth.spec.ts`
- `platform-frontend/tests/e2e/platform-market-order-flow.spec.ts`
- `platform-frontend/tests/e2e/platform-seller-bootstrap.spec.ts`
- `platform-frontend/tests/e2e/platform-benchmark-flow.spec.ts`
- `platform-frontend/tests/e2e/platform-admin-dashboard.spec.ts`

## 8.3 联调约束

必须做到：

- 不 mock 核心业务接口
- 所有关键按钮加 `data-testid`
- 不使用固定 `waitForTimeout`
- 优先用 API 预置测试数据

### 8.4 Bug 回归前端测试清单

必须长期保留以下 UI / 联调回归：

- token 即将过期时自动刷新，不打断用户操作
- 市场页筛选器成功但列表失败时进入 partial 降级态
- listing 详情页价格 stale、version 冲突、状态突变提示
- 下单超时后重试不会重复创建订单
- 连接按钮快速点击只发起一次请求
- 详情页倒计时基于 `remaining_seconds`，系统时区变化不影响显示
- bootstrap 轮询网络中断后能超时退出并允许手动刷新
- benchmark 提交页阻止同时填写压缩包和 git 仓库
- benchmark 结果页显示推荐生成时间并区分可租/已租/已下架
- dashboard 页面切换后无残留轮询定时器
- dashboard 空数据展示与错误展示严格区分

---

## 9. 当前项目中的 UI 与集成建议

由于当前阶段目标是先跑通新平台逻辑，前端必须采用以下落地方式：

1. 以 `platform-frontend` 作为新平台唯一主前端工程继续开发。
2. 新前端优先直接对接 `platform-backend`，不要求先适配旧门户。
3. 原有 `system-template/system-vue` 暂时维持旧系统壳定位，不作为当前阶段新业务主入口。
4. 如后续需要统一入口，可在后端主流程稳定后再评估菜单跳转、iframe、反向代理或单点登录集成方案。
5. 当前允许新平台前端与旧门户并行存在，优先级是“主逻辑跑通”，不是“先合并入口”。

---

## 10. 当前阶段结论

本目录文档已经把前端页面边界和主路径重新收敛为：

- 新页面继续做
- 但以独立 `platform-frontend` 作为主实现
- 当前阶段不要求新后端与旧前端兼容

实现时最重要的不是先做旧门户集成，而是先保证：

- 新页面和后端模块一一对应
- 新页面在独立前端内形成完整主流程
- 状态展示与后端事实一致
- 异常页和兜底页真实可用
- Playwright 能覆盖主链路联调

后续若要和旧门户整合，应在新平台前后端主链路稳定后，单列一个“门户集成阶段”处理，而不是在当前阶段反向修改后端契约。
