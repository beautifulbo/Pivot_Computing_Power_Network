# ComputeNodeAccessGuidePage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`ComputeNodeAccessGuidePage` 是卖家开始接入节点前的说明与引导页。

## 2. 所属业务流程

- `01 卖家接入 ComputeNode`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 接入说明展示 | 展示 Docker Swarm 接入说明 |
| 环境准备清单 | 展示本地前置条件 |
| 常见失败原因 | 展示接入常见问题 |
| 开始接入 | 进入 `ComputeNodeBootstrapPage` |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开引导页 | 从卖家工作台进入 | 页面加载接入说明和注意事项 | `GET /seller/compute-nodes/access-guide` |
| 查看常见问题 | 展开失败原因和 FAQ | 本地展开说明区，无需额外请求 | 无 |
| 开始接入 | 点击“开始接入” | 路由跳转到 `ComputeNodeBootstrapPage` | 无 |

## 5. 当前待确认点

1. 接入说明是否需要按操作系统区分 Windows / Linux，当前资料还没细化。
