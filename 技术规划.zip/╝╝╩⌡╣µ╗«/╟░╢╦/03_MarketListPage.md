# MarketListPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`MarketListPage` 是买家浏览 `NodeRentalListing` 市场的主入口页。

## 2. 所属业务流程

- `02 买家浏览 NodeRentalListing 市场并查看详情`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 首屏列表加载 | 拉取可见的 `NodeRentalListing` 列表 |
| 筛选器加载 | 加载 GPU、区域、价格等筛选项 |
| 搜索 | 按关键字搜索节点 |
| 排序 | 按价格、更新时间等排序 |
| 列表筛选 | 按 GPU、区域、价格区间、可租状态筛选 |
| 进入详情 | 点击卡片进入 `ListingDetailPage` |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开页面 | 买家从首页进入市场页 | 页面显示骨架屏，并并行请求筛选器和首屏列表 | `GET /market/listings/filters`、`GET /market/listings` |
| 切换筛选条件 | 修改 GPU、区域、价格、关键词等 | 更新 query state，重新请求列表，保留当前筛选上下文 | `GET /market/listings?...` |
| 切换排序 | 选择 `price_asc`、`latest` 等 | 列表进入局部 loading，仅刷新列表区域 | `GET /market/listings?...` |
| 翻页或加载更多 | 点击下一页或滚动加载更多 | 更新分页参数并合并或替换卡片数据 | `GET /market/listings?...` |
| 点击卡片 | 点击某个 `NodeRentalListing` | 路由跳转到 `ListingDetailPage` | 无 |

## 5. 当前待确认点

1. 市场页是否需要公开游客访问，当前资料倾向于允许浏览，但下单需登录。
2. 搜索是否只按标题和摘要搜，还是后续扩展到硬件字段，当前资料未冻结。

## 6. 注意事项

**Bug-02-02：筛选器与列表数据不一致**
- 使用 `Promise.allSettled` 并行加载筛选器和列表
- 筛选器加载失败时禁用筛选功能
- **建议**：列表失败时显示错误提示和重试按钮
