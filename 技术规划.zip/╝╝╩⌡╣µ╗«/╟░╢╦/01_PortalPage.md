# PortalPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`PortalPage` 是平台统一入口页，承担买家入口、卖家入口、Benchmark 入口和管理员入口的导航作用。

## 2. 所属业务流程

- `02 买家浏览 NodeRentalListing 市场并查看详情`
- `05 买家发起 BenchmarkJob 并查看推荐`
- `01 卖家接入 ComputeNode`
- `07 管理员查看平台 Dashboard`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 平台介绍 | 展示平台定位和入口说明 |
| 登录入口 | 跳转到 `AuthPage` |
| 市场入口 | 跳转到 `MarketListPage` |
| Benchmark 入口 | 跳转到 `BenchmarkSubmitPage` |
| 卖家入口 | 跳转到 `SellerWorkbenchPage` |
| 管理员入口 | 跳转到 `AdminDashboardPage` |
| 平台概况卡 | 展示在线节点数、运行中订单数、异常数等摘要 |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 登录入口 | 点击“登录 / 注册” | 路由跳转到 `AuthPage` | 无 |
| 浏览市场 | 点击“浏览算力市场” | 路由跳转到 `MarketListPage` | 无 |
| 发起测算 | 点击“AI 测算” | 路由跳转到 `BenchmarkSubmitPage` | 无 |
| 卖家中心 | 点击“卖家中心” | 已登录则跳 `SellerWorkbenchPage`；未登录则先去 `AuthPage` | 无 |
| 管理员后台 | 点击“管理员后台” | 已登录且具备 `admin` 能力则跳 `AdminDashboardPage`，否则跳 `AuthPage` 或 `NoPermissionPage` | 无 |
| 平台概况卡 | 页面首屏自动加载摘要数据 | 渲染数字卡；失败时区块降级为静态说明 | 当前资料未定义专用接口 |

## 5. 当前待确认点

1. `PortalPage` 的概况卡是否新增公开接口，例如 `GET /portal/summary`。
2. 如果暂不新增接口，首页是否直接去掉实时数字区，只保留静态入口。
