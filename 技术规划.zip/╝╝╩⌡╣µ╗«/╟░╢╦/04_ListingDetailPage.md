# ListingDetailPage

版本：V1.1
日期：2026-03-18

## 1. 页面定位

`ListingDetailPage` 是买家查看单个 `NodeRentalListing` 详情并发起直租的页面，也是 Benchmark 推荐跳转后的最终购买入口。

## 2. 所属业务流程

- `02 买家浏览 NodeRentalListing 市场并查看详情`
- `03 买家直租 NodeRentalListing 并创建 Deployment`
- `05 买家发起 BenchmarkJob 并查看推荐`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 详情展示 | 展示硬件、价格、镜像策略、租用状态 |
| 租用参数填写 | 填写时长、镜像、启动命令、环境变量、端口 |
| 价格提示 | 展示预估费用范围（¥X.XX - ¥X.XX），说明实际按使用时长结算 |
| 发起租用 | 提交创建 `RentalOrder` |
| 状态回刷 | 下单失败后回刷 listing 最新状态 |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开详情 | 从市场页或 Benchmark 结果页点击推荐项 | 页面骨架后加载详情数据 | `GET /market/listings/{listing_id}` |
| 填写租用参数 | 输入时长、镜像、命令等 | 本地表单校验；根据页面价格计算预估冻结金额 | 无 |
| 立即租用 | 点击“立即租用” | 按钮 loading；提交订单；成功后跳 `RentalOrderDetailPage` | `POST /rental-orders` |
| 下单失败后刷新状态 | 收到 `listing_not_rentable`、`price_changed` 等错误 | 页面保留当前输入；局部显示错误；必要时自动回刷详情 | `GET /market/listings/{listing_id}` |
| 进入实例详情 | 下单成功后自动跳转 | 跳转到 `RentalOrderDetailPage`，随后实例详情页自己拉订单和部署状态 | `GET /rental-orders/{order_id}`、`GET /rental-orders/{order_id}/deployment` |

## 5. 当前待确认点

1. 自定义镜像字段是否在第一版对普通买家默认显示，当前后端接口保留了能力，但前端默认展示策略还未完全冻结。

## 6. 价格展示逻辑

### 6.1 展示格式

```
单价：¥10.00/小时
预估费用：¥10.00 - ¥50.00
说明：实际费用按使用时长结算，提前释放可退还差额
```

### 6.2 计算逻辑

```javascript
const unitPrice = listing.current_price_hourly;
const durationMinutes = form.duration_minutes;

// 最小费用（假设立即释放）
const minAmount = (10 / 60) * unitPrice;  // 最少 10 分钟

// 最大费用（租满整个租期）
const maxAmount = (durationMinutes / 60) * unitPrice;

// 展示
const priceText = `¥${minAmount.toFixed(2)} - ¥${maxAmount.toFixed(2)}`;
```

