# SellerWorkbenchPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`SellerWorkbenchPage` 是卖家的主入口页，用于查看节点和上架记录概况，并跳转到接入和管理页面。

## 2. 所属业务流程

- `01 卖家接入 ComputeNode`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 节点概况 | 展示卖家名下 `ComputeNode` 列表或摘要 |
| 上架概况 | 展示卖家名下 `NodeRentalListing` 列表或摘要 |
| 接入入口 | 进入接入引导和执行页 |
| 管理入口 | 进入 `ListingManagePage` |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 打开工作台 | 登录后进入卖家工作台 | 页面并行加载节点和上架记录概况 | `GET /seller/compute-nodes`、`GET /seller/listings` |
| 查看节点卡片 | 浏览已有节点摘要 | 渲染在线状态、运行状态、最近同步时间 | `GET /seller/compute-nodes` |
| 查看上架卡片 | 浏览已有上架记录摘要 | 渲染 listing 状态、平台价格、可租状态 | `GET /seller/listings` |
| 接入新节点 | 点击“接入新节点” | 路由跳转到 `ComputeNodeAccessGuidePage` | 无 |
| 管理上架 | 点击“管理上架”或某条 listing | 路由跳转到 `ListingManagePage` | 无 |

## 5. 当前待确认点

1. 是否需要单独的 `workbench overview` 聚合接口，当前资料可用 `GET /seller/compute-nodes` 与 `GET /seller/listings` 组合渲染。
