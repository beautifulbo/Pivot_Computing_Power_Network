# ComputeNodeBootstrapPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`ComputeNodeBootstrapPage` 是卖家实际完成节点接入的页面，负责生成本地执行命令并轮询接入状态。

## 2. 所属业务流程

- `01 卖家接入 ComputeNode`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 生成接入会话 | 创建一次性 `bootstrap session` |
| 展示本地命令 | 展示复制到终端执行的命令 |
| 接入状态轮询 | 轮询 `session` 当前状态 |
| 接入结果跳转 | 成功后返回卖家工作台或上架管理页 |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 创建接入会话 | 点击“生成接入命令” | 按钮 loading；成功后展示命令、会话 ID 和过期时间 | `POST /seller/compute-nodes/bootstrap-sessions` |
| 复制命令 | 点击复制按钮 | 本地复制到剪贴板，页面提示已复制 | 无 |
| 本地执行命令 | 卖家在本地终端执行命令 | 页面不直接发请求，等待轮询结果；本地脚本会调用平台注册接口 | 前端无直接接口；相关链路包含 `POST /seller/compute-nodes/register-self` |
| 轮询接入状态 | 页面发现当前 session 未结束 | 每 5 到 10 秒轮询一次会话状态 | `GET /seller/compute-nodes/bootstrap-sessions/{session_id}` |
| 接入成功 | 轮询返回 `verified` 或等效成功状态 | 页面显示成功提示，并可自动跳回 `SellerWorkbenchPage` | `GET /seller/compute-nodes/bootstrap-sessions/{session_id}` |
| 接入失败后重试同步 | 页面显示节点已发现但状态未收敛 | 提供“手动重试同步”按钮 | `POST /seller/compute-nodes/{node_id}/sync` |

## 5. 当前待确认点

1. `bootstrap session` 过期后是原地刷新重建还是保留旧命令并提醒失效，当前资料未冻结。

## 6. 注意事项

**Bug-01-05：网络中断后轮询卡死**
- 轮询需设置5分钟超时，避免永久等待
- 网络错误时显示提示并提供手动刷新按钮
- **建议**：实现指数退避重试机制
