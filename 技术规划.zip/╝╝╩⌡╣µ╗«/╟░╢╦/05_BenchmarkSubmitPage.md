# BenchmarkSubmitPage

版本：V1.0  
日期：2026-03-18

## 1. 页面定位

`BenchmarkSubmitPage` 是买家发起 `BenchmarkJob` 的提交页，支持上传完整代码压缩包或填写公开 `git clone` 链接。

## 2. 所属业务流程

- `05 买家发起 BenchmarkJob 并查看推荐`

## 3. 页面功能

| 功能 | 说明 |
|---|---|
| 选择输入方式 | `code_archive` 或 `git_repository` 二选一 |
| 上传压缩包 | 上传完整代码压缩包 |
| 填写 git 信息 | 填写 `git_clone_url` 和可选 `git_ref` |
| 填写辅助说明 | 录入 `entry_hint`、项目类型等提示 |
| 创建任务 | 提交 `BenchmarkJob` |
| 跳结果页 | 成功后跳转 `BenchmarkResultPage` |

## 4. 用户操作明细

| 功能 | 用户操作 | 前端反应 | 后端接口 |
|---|---|---|---|
| 选择压缩包模式 | 切换到 `code_archive` | 显示上传区，隐藏 git 输入区 | 无 |
| 上传压缩包 | 选择 zip 文件并上传 | 上传进度条；成功后保存 `code_archive_token` | `POST /benchmark-jobs/code-archive-uploads` |
| 选择 git 模式 | 切换到 `git_repository` | 显示 `git_clone_url`、`git_ref` 输入区 | 无 |
| 提交任务 | 点击“开始测算” | 按钮 loading；校验只允许一种输入来源；成功后跳转结果页 | `POST /benchmark-jobs` |
| 任务创建成功 | 收到 `job_id` | 路由跳转到 `BenchmarkResultPage` | 无 |

## 5. 当前待确认点

1. `BenchmarkSubmitPage` 是否支持私有仓库，当前资料只覆盖公开仓库。
2. 页面是否允许上传额外运行说明文件，当前资料未定义。
